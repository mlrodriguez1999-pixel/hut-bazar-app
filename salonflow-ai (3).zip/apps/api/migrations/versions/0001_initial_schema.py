"""Initial schema migration for SalonFlow AI

Revision ID: 0001_initial_schema
Revises: 
Create Date: 2026-08-05

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '0001_initial_schema'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # Activar extensión btree_gist
    op.execute('CREATE EXTENSION IF NOT EXISTS "btree_gist";')
    
    # Enum Types
    op.execute("CREATE TYPE appointment_status AS ENUM ('SCHEDULED', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO_SHOW');")
    op.execute("CREATE TYPE conversation_channel AS ENUM ('WHATSAPP', 'WEB', 'INSTAGRAM', 'PHONE');")
    op.execute("CREATE TYPE conversation_status AS ENUM ('ACTIVE', 'ESCALATED', 'CLOSED');")
    op.execute("CREATE TYPE message_role AS ENUM ('USER', 'ASSISTANT', 'SYSTEM');")
    op.execute("CREATE TYPE business_role AS ENUM ('owner', 'manager', 'receptionist', 'staff');")

    # Tables
    op.create_table(
        'businesses',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('slug', sa.String(255), nullable=False, unique=True),
        sa.Column('timezone', sa.String(50), nullable=False, server_default='Europe/Madrid'),
        sa.Column('phone', sa.String(50), nullable=False),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('address', sa.Text(), nullable=False),
        sa.Column('settings', postgresql.JSONB(), server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now())
    )

    op.create_table(
        'business_members',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('business_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('businesses.id', ondelete='CASCADE'), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('full_name', sa.String(255), nullable=False),
        sa.Column('role', sa.Enum('owner', 'manager', 'receptionist', 'staff', name='business_role'), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now())
    )

def downgrade():
    op.drop_table('business_members')
    op.drop_table('businesses')
