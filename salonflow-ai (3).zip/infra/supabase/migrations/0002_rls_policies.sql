-- Migration 0002: Habilitación e Implementación de Políticas Row Level Security (RLS) para Multi-Tenancy
ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_base ENABLE ROW LEVEL SECURITY;
ALTER TABLE faq_entries ENABLE ROW LEVEL SECURITY;

-- Helper Function para obtener el business_id del usuario autenticado
CREATE OR REPLACE FUNCTION current_user_business_id()
RETURNS UUID AS $$
  SELECT business_id FROM business_members WHERE user_id = auth.uid() LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- 1. Businesses Policies
CREATE POLICY "Users can view their own business" ON businesses
  FOR SELECT USING (id = current_user_business_id());

-- 2. Business Members Policies
CREATE POLICY "Users can view members of their business" ON business_members
  FOR SELECT USING (business_id = current_user_business_id());

-- 3. Services Policies
CREATE POLICY "Users can access services of their business" ON services
  FOR ALL USING (business_id = current_user_business_id());

-- 4. Employees Policies
CREATE POLICY "Users can access employees of their business" ON employees
  FOR ALL USING (business_id = current_user_business_id());

-- 5. Customers Policies
CREATE POLICY "Users can access customers of their business" ON customers
  FOR ALL USING (business_id = current_user_business_id());

-- 6. Appointments Policies
CREATE POLICY "Users can access appointments of their business" ON appointments
  FOR ALL USING (business_id = current_user_business_id());

-- 7. Conversations & Messages Policies
CREATE POLICY "Users can access conversations of their business" ON conversations
  FOR ALL USING (business_id = current_user_business_id());

CREATE POLICY "Users can access messages of their conversation" ON messages
  FOR ALL USING (
    conversation_id IN (
      SELECT id FROM conversations WHERE business_id = current_user_business_id()
    )
  );
