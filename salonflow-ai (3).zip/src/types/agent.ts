import { BusinessInfo, CustomerInfo, BookingPayload } from './receptionist';

export type AgentIntent =
  | 'appointment_booking'
  | 'service_inquiry'
  | 'business_hours_inquiry'
  | 'human_handover'
  | 'cancel_booking'
  | 'general_inquiry';

export interface IntentAnalysisResult {
  intent: AgentIntent;
  /** Nivel de confianza entre 0.0 y 1.0 */
  confidence: number;
  reasoning: string;
}

export interface MemorySlotState {
  service?: string;
  date?: string;
  time?: string;
  customer_name?: string;
  customer_phone?: string;
  notes?: string;
}

export interface ConversationTurn {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  intent?: AgentIntent;
  toolExecuted?: string;
}

export interface MemoryState {
  conversation_id: string;
  history: ConversationTurn[];
  customer: CustomerInfo;
  business: BusinessInfo;
  slots: MemorySlotState;
  last_intent?: AgentIntent;
  last_tool_executed?: string;
  handover_requested: boolean;
  created_at: string;
  updated_at: string;
}

export type ToolName =
  | 'check_availability_tool'
  | 'create_booking_tool'
  | 'get_services_catalog_tool'
  | 'get_opening_hours_tool'
  | 'escalate_human_handover_tool'
  | 'cancel_booking_tool'
  | 'none';

export interface ToolDefinition {
  name: ToolName;
  description: string;
  parametersSchema: Record<string, any>;
}

export interface ToolExecutionResult {
  toolName: ToolName;
  success: boolean;
  data: Record<string, any>;
  summary: string;
}

export interface PipelineStepLog {
  stepNumber: number;
  stepName: 'receive_message' | 'identify_intent' | 'consult_memory' | 'decide_tool' | 'execute_tool' | 'update_memory' | 'respond';
  title: string;
  description: string;
  data?: any;
}

export interface AgentProcessInput {
  user_message: string;
  conversation_id?: string;
  history?: Array<{ sender?: string; role?: string; text: string }>;
  persona?: 'barber' | 'chic' | 'default' | string;
  business?: BusinessInfo;
  customer?: CustomerInfo;
}

export interface AgentProcessResponse {
  reply: string;
  detectedIntent: AgentIntent;
  booking?: BookingPayload | null;
  toolExecuted?: ToolExecutionResult | null;
  suggestedActions: string[];
  responseTimeMs: number;
  tokensUsed: {
    promptTokens: number;
    candidatesTokens: number;
    totalTokens: number;
  };
  promptSent: string;
  raw_response: string;
  contextUsed: {
    business: BusinessInfo;
    customer: CustomerInfo;
    memorySlots: MemorySlotState;
  };
  pipelineSteps: PipelineStepLog[];
  memoryState: MemoryState;
}
