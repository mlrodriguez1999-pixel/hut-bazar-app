export interface ServiceItem {
  id?: string;
  name: string;
  price: number;
  duration_minutes?: number;
  category?: string;
  description?: string;
}

export interface BusinessHoursItem {
  day: string; // e.g., 'Lunes', 'Martes', 'Monday', etc.
  open: string; // e.g., '09:00'
  close: string; // e.g., '20:00'
  is_closed?: boolean;
}

export interface BusinessInfo {
  id?: string;
  name: string;
  type?: string; // 'peluqueria' | 'barberia' | 'salon'
  currency?: string;
  address?: string;
  phone?: string;
  services: ServiceItem[];
  opening_hours: BusinessHoursItem[];
  cancellation_policy?: string;
  special_notes?: string;
}

export interface CustomerInfo {
  id?: string;
  name?: string;
  phone?: string;
  email?: string;
  preferred_stylist?: string;
}

export interface ConversationMessage {
  role: 'user' | 'assistant' | 'model';
  text: string;
  timestamp?: string;
}

export interface BookingPayload {
  action: 'create_booking';
  customer_name: string;
  phone: string;
  service: string;
  date: string;
  time: string;
}

export interface GeminiReceptionServiceInput {
  business: BusinessInfo;
  customer: CustomerInfo;
  conversation_history: ConversationMessage[];
  user_message: string;
}

export interface GeminiReceptionServiceResponse {
  reply: string;
  booking?: BookingPayload | null;
  missing_booking_fields?: string[];
  raw_response?: string;
  responseTimeMs?: number;
  promptSent?: string;
  tokensUsed?: {
    promptTokens: number;
    candidatesTokens: number;
    totalTokens: number;
  };
  contextUsed?: {
    business: BusinessInfo;
    customer: CustomerInfo;
  };
}
