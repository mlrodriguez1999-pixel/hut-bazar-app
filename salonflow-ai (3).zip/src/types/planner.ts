import { BusinessInfo } from './receptionist';
import { CustomerMemoryProfile } from './customerMemory';
import { ToolDefinition, ToolName } from './agent';

export interface PlanStep {
  step_number: number;
  action: string;
  description: string;
  tool_to_use?: ToolName;
  params?: Record<string, any>;
  is_completed?: boolean;
}

export interface ExecutionPlan {
  user_intent: string;
  plan_goal: string;
  steps: PlanStep[];
  next_step_index: number;
  reasoning: string;
  created_at: string;
}

export interface PlannerInput {
  user_message: string;
  business: BusinessInfo;
  customer: CustomerMemoryProfile;
  available_tools: ToolDefinition[];
  session_slots?: {
    service?: string;
    date?: string;
    time?: string;
    [key: string]: any;
  };
}
