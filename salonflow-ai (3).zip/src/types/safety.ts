import { BusinessInfo } from './receptionist';
import { ExecutionPlan } from './planner';

export interface SafetyConfig {
  check_unverified_prices: boolean;
  check_unverified_hours: boolean;
  check_fake_bookings: boolean;
  check_fake_promotions: boolean;
  check_medical_advice: boolean;
  check_unverified_availability: boolean;
  fallback_honesty_template: string;
  log_incidents: boolean;
  custom_forbidden_keywords?: string[];
}

export type SafetyRuleId =
  | 'unverified_prices'
  | 'unverified_hours'
  | 'fake_bookings'
  | 'fake_promotions'
  | 'medical_advice'
  | 'unverified_availability'
  | 'custom_forbidden_content';

export interface SafetyViolation {
  rule_id: SafetyRuleId;
  severity: 'warning' | 'critical';
  description: string;
  detected_snippet?: string;
}

export interface SafetyValidationInput {
  user_message?: string;
  proposed_response: string;
  business?: BusinessInfo;
  execution_plan?: ExecutionPlan;
  executed_tool?: string;
  tool_execution_data?: Record<string, any>;
}

export interface SafetyIncidentRecord {
  id: string;
  timestamp: string;
  user_message?: string;
  proposed_response: string;
  violations: SafetyViolation[];
  final_response: string;
  config_snapshot: SafetyConfig;
}

export interface SafetyValidationResult {
  is_safe: boolean;
  original_response: string;
  final_response: string;
  violations: SafetyViolation[];
  incident_logged: boolean;
  incident_record?: SafetyIncidentRecord;
}
