export interface RecentService {
  name: string;
  date: string; // ISO date string or YYYY-MM-DD
  barber?: string;
  price?: number;
}

export interface RecentBooking {
  id: string;
  service: string;
  date: string;
  time: string;
  barber?: string;
  status: 'confirmed' | 'completed' | 'cancelled';
  created_at?: string;
}

export interface CustomerMemoryProfile {
  name: string;                    // Nombre
  phone: string;                   // Teléfono
  recent_services: RecentService[];// Últimos servicios
  recent_bookings: RecentBooking[];// Últimas reservas
  preferences: string[];           // Preferencias (ej: "Agua fría", "Tijera en copa")
  favorite_barber: string;         // Barbero favorito
  observations: string[];          // Observaciones (ej: "Piel sensible", "Llega puntual")
  visit_count: number;             // Número de visitas
  last_interaction: string;        // Última interacción (ISO timestamp)
}

export interface CustomerMemoryUpdate {
  name?: string;
  phone?: string;
  favorite_barber?: string;
  preferences?: string[];
  observations?: string[];
  visit_count?: number;
  last_interaction?: string;
}
