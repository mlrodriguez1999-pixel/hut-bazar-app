import crypto from 'crypto';
import { AgentCore } from '../../services/AgentCore';

/**
 * Handler de Infraestructura: WhatsAppWebhookHandler
 * Recibe, verifica la firma HMAC-SHA256 de Meta y procesa mensajes entrantes de WhatsApp Business API.
 */
export class WhatsAppWebhookHandler {
  private appSecret: string;
  private verifyToken: string;
  private agentCore: AgentCore;

  constructor(agentCore: AgentCore) {
    this.appSecret = process.env.WHATSAPP_APP_SECRET || 'salonflow_wa_secret_key_2026';
    this.verifyToken = process.env.WHATSAPP_VERIFY_TOKEN || 'salonflow_verify_token_2026';
    this.agentCore = agentCore;
  }

  /**
   * Verificación del webhook por Meta (GET request)
   */
  public verifyChallenge(mode?: string, token?: string, challenge?: string): string | null {
    if (mode === 'subscribe' && token === this.verifyToken) {
      return challenge || null;
    }
    return null;
  }

  /**
   * Valida la firma HMAC-SHA256 enviada por Meta en 'x-hub-signature-256'
   */
  public verifySignature(payloadBuffer: Buffer, signatureHeader?: string): boolean {
    if (!signatureHeader) return false;

    const signatureParts = signatureHeader.split('=');
    if (signatureParts.length !== 2 || signatureParts[0] !== 'sha256') return false;

    const expectedSignature = signatureParts[1];
    const actualSignature = crypto
      .createHmac('sha256', this.appSecret)
      .update(payloadBuffer)
      .digest('hex');

    return crypto.timingSafeEqual(Buffer.from(expectedSignature), Buffer.from(actualSignature));
  }

  /**
   * Mapea el payload de Meta WhatsApp API a HandleIncomingMessageCommand
   * y procesa en segundo plano para responder < 200ms a Meta.
   */
  public processIncomingPayloadAsync(payload: any): void {
    setImmediate(async () => {
      try {
        const entry = payload?.entry?.[0];
        const changes = entry?.changes?.[0];
        const value = changes?.value;
        const message = value?.messages?.[0];

        if (!message || message.type !== 'text') {
          return; // Ignorar estados de lectura o multimedia no soportados en MVP
        }

        const fromNumber = message.from; // Número E.164 del cliente
        const messageBody = message.text?.body;
        const contactName = value?.contacts?.[0]?.profile?.name || 'Cliente WhatsApp';

        console.log(`[WhatsApp Webhook] Mensaje recibido de +${fromNumber} (${contactName}): "${messageBody}"`);

        // Procesar con AgentCore
        await this.agentCore.processMessage({
          user_message: messageBody,
          customer: {
            id: `wa_${fromNumber}`,
            name: contactName,
            phone: `+${fromNumber}`,
          },
          business: {
            id: 'biz_salon_flow_01',
            name: 'Peluquería Flow AI',
            services: [
              { id: 'srv-1', name: 'Corte Tradicional', price: 20, duration_minutes: 30 },
            ],
            opening_hours: [
              { day: 'Lunes a Sábado', open: '09:00', close: '19:00' },
            ],
          },
          conversation_id: `conv_wa_${fromNumber}`,
        });

        console.log(`[WhatsApp Webhook] Respuesta procesada con éxito para +${fromNumber}`);
      } catch (err) {
        console.error('[WhatsApp Webhook Error] Error procesando mensaje entrante:', err);
      }
    });
  }
}
