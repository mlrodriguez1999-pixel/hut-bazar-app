import crypto from 'crypto';

export type N8nEventType =
  | 'appointment.booked'
  | 'appointment.cancelled'
  | 'appointment.rescheduled'
  | 'conversation.escalated'
  | 'reminder.due';

export interface N8nWebhookPayload {
  event: N8nEventType;
  timestamp: string;
  businessId: string;
  data: Record<string, any>;
}

/**
 * Handler de Infraestructura: N8nWebhookHandler
 * Despacha eventos entrantes/salientes de n8n firmados con HMAC-SHA256.
 */
export class N8nWebhookHandler {
  private webhookSecret: string;

  constructor() {
    this.webhookSecret = process.env.N8N_WEBHOOK_SECRET || 'salonflow_n8n_secret_key_2026';
  }

  /**
   * Genera o verifica la firma HMAC-SHA256 para eventos n8n
   */
  public verifySignature(rawBody: string, signatureHeader?: string): boolean {
    if (!signatureHeader) return true; // En modo dev permitimos sin firma si no está configurado

    const expectedSignature = crypto
      .createHmac('sha256', this.webhookSecret)
      .update(rawBody)
      .digest('hex');

    return crypto.timingSafeEqual(Buffer.from(signatureHeader), Buffer.from(expectedSignature));
  }

  /**
   * Despacha el evento recibido de n8n al subsistema correspondiente
   */
  public async dispatchEvent(payload: N8nWebhookPayload): Promise<{ handled: boolean; action: string }> {
    console.log(`[n8n Webhook Dispatcher] Evento recibido: ${payload.event} para negocio ${payload.businessId}`);

    switch (payload.event) {
      case 'appointment.booked':
        return { handled: true, action: 'Notificación de reserva enviada por n8n' };

      case 'appointment.cancelled':
        return { handled: true, action: 'Oferta de hueco liberado publicada por n8n' };

      case 'appointment.rescheduled':
        return { handled: true, action: 'Confirmación de re-agendamiento procesada' };

      case 'conversation.escalated':
        return { handled: true, action: 'Alerta enviada al equipo humano' };

      case 'reminder.due':
        return { handled: true, action: 'Recordatorio automático despachado' };

      default:
        return { handled: false, action: `Evento no reconocido: ${payload.event}` };
    }
  }
}
