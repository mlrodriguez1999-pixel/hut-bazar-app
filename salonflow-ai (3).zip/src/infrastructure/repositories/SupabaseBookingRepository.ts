import { createClient } from '@supabase/supabase-js';

export class SupabaseBookingRepository {
  private client;

  constructor() {
    const env = typeof process !== 'undefined' ? process.env : (import.meta as Record<string, any>).env || {};
    const supabaseUrl = env.SUPABASE_URL || env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
    const supabaseKey = env.SUPABASE_SERVICE_ROLE_KEY || env.VITE_SUPABASE_SERVICE_ROLE_KEY || 'placeholder-key';

    this.client = createClient(supabaseUrl, supabaseKey);
  }

  async createAppointment(data: {
    businessId?: string;
    customerName: string;
    customerPhone: string;
    service: string;
    date: string;
    time: string;
  }) {
    const { data: appointment, error } = await this.client
      .from('appointments')
      .insert({
        business_id: data.businessId,
        customer_name: data.customerName,
        customer_phone: data.customerPhone,
        service: data.service,
        appointment_date: data.date,
        appointment_time: data.time,
        status: 'confirmed'
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return appointment;
  }
}
