import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { CleanArchExplorer } from './components/CleanArchExplorer';
import { AIReceptionistSimulator } from './components/AIReceptionistSimulator';
import { SalonDashboard } from './components/SalonDashboard';
import { N8nWorkflowVisualizer } from './components/N8nWorkflowVisualizer';
import { EnvConfigPanel } from './components/EnvConfigPanel';
import { ChatMessage } from './types';
import { Bot, Code2, Server, Database, Workflow, ShieldCheck, Github } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'architecture' | 'simulator' | 'dashboard' | 'n8n' | 'config'>('architecture');
  const [geminiConnected, setGeminiConnected] = useState(false);

  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setGeminiConnected(data.geminiConfigured);
      })
      .catch(() => setGeminiConnected(false));
  }, []);

  const handleSendMessageServer = async (msg: string, history: ChatMessage[], persona: string, conversationId?: string) => {
    const res = await fetch('/api/receptionist/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: msg,
        history: history.map((h) => ({ sender: h.sender, text: h.text })),
        persona,
        salonName: 'Barbería & Peluquería Elegance',
        conversation_id: conversationId,
      }),
    });
    return await res.json();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Global Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} geminiConnected={geminiConnected} />

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {activeTab === 'architecture' && <CleanArchExplorer />}
        {activeTab === 'simulator' && <AIReceptionistSimulator onSendMessageServer={handleSendMessageServer} />}
        {activeTab === 'dashboard' && <SalonDashboard />}
        {activeTab === 'n8n' && <N8nWorkflowVisualizer />}
        {activeTab === 'config' && <EnvConfigPanel />}
      </main>

      {/* Global Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Bot className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-slate-300">SalonFlow AI</span>
            <span>— Arquitectura Profesional & Recepcionista IA para Barberías</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400 font-mono text-[11px]">
            <span>FastAPI</span>
            <span>•</span>
            <span>Next.js 15</span>
            <span>•</span>
            <span>Supabase SQL</span>
            <span>•</span>
            <span>n8n</span>
            <span>•</span>
            <span>Gemini 3.6 Flash</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
