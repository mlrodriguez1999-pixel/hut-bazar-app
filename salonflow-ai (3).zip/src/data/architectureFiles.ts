import { ArchitectureFile } from '../types';

export const architectureFiles: ArchitectureFile[] = [
  // BACKEND CLEAN ARCHITECTURE (FastAPI)
  {
    id: 'backend-main',
    category: 'backend',
    path: 'backend/app/main.py',
    filename: 'main.py',
    language: 'python',
    description: 'Punto de entrada FastAPI con middleware CORS, manejo de excepciones global y routers v1.',
    content: `"""
SalonFlow AI - Backend FastAPI Entry Point
Clean Architecture & Modular Structure
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.api.v1.router import api_router

app = FastAPI(
    title="SalonFlow AI Core Service",
    description="Microservicio de Recepcionista Virtual para Peluquerías y Barberías",
    version="1.0.0",
    docs_url="/docs" if settings.DEBUG else None,
)

# Configuración CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inclusión de rutas v1
app.include_router(api_router, prefix="/api/v1")

@app.get("/health", tags=["Health"])
async def health_check():
    return {
        "status": "healthy",
        "service": "SalonFlow AI FastAPI",
        "version": "1.0.0"
    }
`
  },
  {
    id: 'backend-config',
    category: 'backend',
    path: 'backend/app/config.py',
    filename: 'config.py',
    language: 'python',
    description: 'Configuración global con pydantic-settings para lectura de variables de entorno.',
    content: `from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    PROJECT_NAME: str = "SalonFlow AI"
    DEBUG: bool = False
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "https://app.salonflow.ai"]
    
    # Supabase / Database
    DATABASE_URL: str
    SUPABASE_URL: str
    SUPABASE_KEY: str
    
    # Google AI Studio / Gemini
    GEMINI_API_KEY: str
    GEMINI_MODEL: str = "gemini-3.6-flash"
    
    # n8n Webhook Secret
    N8N_WEBHOOK_SECRET: str
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
`
  },
  {
    id: 'backend-domain-salon',
    category: 'backend',
    path: 'backend/app/domain/entities/salon.py',
    filename: 'salon.py',
    language: 'python',
    description: 'Entidad de Dominio: Salon y reglas de negocio puras.',
    content: `from dataclasses import dataclass
from typing import List, Optional
from datetime import time

@dataclass
class BusinessHours:
    open_time: time
    close_time: time
    days_open: List[str]  # e.g., ["MON", "TUE", "WED", "THU", "FRI", "SAT"]

@dataclass
class Salon:
    id: str
    name: str
    slug: str
    phone: str
    address: str
    business_hours: BusinessHours
    is_active: bool = True
    
    def is_open_at(self, check_time: time, day_name: str) -> bool:
        """Regla de dominio pura: verifica si el salón está abierto"""
        if day_name not in self.business_hours.days_open:
            return False
        return self.business_hours.open_time <= check_time <= self.business_hours.close_time
`
  },
  {
    id: 'backend-domain-appointment',
    category: 'backend',
    path: 'backend/app/domain/entities/appointment.py',
    filename: 'appointment.py',
    language: 'python',
    description: 'Entidad de Dominio: Cita de Peluquería/Barbería.',
    content: `from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional

class AppointmentStatus(str, Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

@dataclass
class Appointment:
    id: str
    salon_id: str
    client_name: str
    client_phone: str
    service_id: str
    stylist_id: Optional[str]
    start_time: datetime
    end_time: datetime
    status: AppointmentStatus = AppointmentStatus.PENDING
    notes: Optional[str] = None
    
    def confirm(self):
        """Regla de negocio: Transición de estado a confirmada"""
        if self.status == AppointmentStatus.CANCELLED:
            raise ValueError("No se puede confirmar una cita cancelada.")
        self.status = AppointmentStatus.CONFIRMED
`
  },
  {
    id: 'backend-use-case',
    category: 'backend',
    path: 'backend/app/use_cases/booking_use_case.py',
    filename: 'booking_use_case.py',
    language: 'python',
    description: 'Caso de Uso: Procesar solicitud de reserva recibida por el recepcionista IA.',
    content: `from datetime import datetime
from app.domain.entities.appointment import Appointment, AppointmentStatus
from app.domain.ports.appointment_repository import AppointmentRepositoryPort
from app.domain.ports.ai_service_port import AIServicePort

class BookingUseCase:
    """
    Caso de Uso siguiendo Clean Architecture:
    Orquesta la validación de disponibilidades, la extracción de intención
    con Gemini AI y el guardado en Supabase.
    """
    def __init__(
        self,
        repo: AppointmentRepositoryPort,
        ai_service: AIServicePort
    ):
        self.repo = repo
        self.ai_service = ai_service

    async def execute(self, salon_id: str, client_message: str, client_phone: str) -> dict:
        # 1. Extraer intención y datos clave usando Gemini AI
        extracted = await self.ai_service.extract_booking_intent(client_message)
        
        if not extracted.get("is_booking_request"):
            # Generar respuesta conversational estándar
            reply = await self.ai_service.generate_receptionist_reply(client_message, salon_id)
            return {"type": "chat", "message": reply}

        # 2. Verificar disponibilidad en el repositorio
        start_time = datetime.fromisoformat(extracted["start_time"])
        is_available = await self.repo.check_availability(
            salon_id=salon_id,
            start_time=start_time,
            service_id=extracted["service_id"]
        )

        if not is_available:
            return {
                "type": "conflict",
                "message": f"Lo siento, el horario {start_time.strftime('%H:%M')} está ocupado. ¿Te sirve 30 min más tarde?"
            }

        # 3. Guardar cita provisional
        appointment = await self.repo.create(
            salon_id=salon_id,
            client_name=extracted.get("client_name", "Cliente WhatsApp"),
            client_phone=client_phone,
            service_id=extracted["service_id"],
            start_time=start_time,
            status=AppointmentStatus.CONFIRMED
        )

        return {
            "type": "booking_confirmed",
            "appointment_id": appointment.id,
            "message": f"¡Cita confirmada! Te esperamos el {start_time.strftime('%d/%m a las %H:%M')}."
        }
`
  },
  {
    id: 'backend-adapter-gemini',
    category: 'backend',
    path: 'backend/app/adapters/gemini_adapter.py',
    filename: 'gemini_adapter.py',
    language: 'python',
    description: 'Adaptador de Infraestructura para Google AI Studio (SDK google-genai Gemini).',
    content: `from google import genai
from app.config import settings
from app.domain.ports.ai_service_port import AIServicePort

class GeminiAIAdapter(AIServicePort):
    def __init__(self):
        self.client = genai.Client(api_key=settings.GEMINI_API_KEY)
        self.model = settings.GEMINI_MODEL

    async def generate_receptionist_reply(self, message: str, salon_id: str) -> str:
        prompt = f"""
        Eres un recepcionista virtual de barbería y peluquería.
        Mensaje del cliente: "{message}"
        Responde amablemente, solicita datos faltantes para agendar cita o aclara precios.
        """
        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt
        )
        return response.text

    async def extract_booking_intent(self, message: str) -> dict:
        # Extracción estructurada con Gemini 3.6 Flash JSON Mode
        response = self.client.models.generate_content(
            model=self.model,
            contents=f"Analiza si el siguiente mensaje es una reserva de cita: '{message}'",
            config={"response_mime_type": "application/json"}
        )
        return response.parsed
`
  },

  // FRONTEND CLEAN ARCHITECTURE (Next.js 15)
  {
    id: 'frontend-layout',
    category: 'frontend',
    path: 'frontend/app/layout.tsx',
    filename: 'layout.tsx',
    language: 'typescript',
    description: 'Root layout de Next.js 15 App Router con metadata, fuentes y temas TailwindCSS.',
    content: `import type { Metadata } from 'next';
import { Inter, Outfit } from 'next/font/google';
import './globals.css';

const outfit = Outfit({ subsets: ['latin'], variable: '--font-outfit' });
const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata: Metadata = {
  title: 'SalonFlow AI - Recepcionista Virtual para Peluquerías',
  description: 'SaaS para automatizar citas y atención al cliente 24/7 en barberías y salones con IA.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className={\`\${outfit.variable} \${inter.variable} antialiased\`}>
      <body className="min-h-screen bg-slate-950 text-slate-100 font-sans">
        {children}
      </body>
    </html>
  );
}
`
  },
  {
    id: 'frontend-page',
    category: 'frontend',
    path: 'frontend/app/page.tsx',
    filename: 'page.tsx',
    language: 'typescript',
    description: 'Página principal Next.js 15 para la landing y acceso al panel de control de barberías.',
    content: `import Link from 'next/link';
import { Bot, CalendarCheck, MessageSquareCode, ShieldCheck, Sparkles } from 'lucide-react';

export default function HomePage() {
  return (
    <main className="max-w-7xl mx-auto px-6 py-16">
      {/* Hero Header */}
      <div className="text-center space-y-6 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-medium">
          <Sparkles className="w-4 h-4" />
          Recepcionista Virtual con IA para Salones y Barberías
        </div>
        <h1 className="text-5xl font-extrabold tracking-tight text-white font-display">
          Multiplica las reservas de tu salón con <span className="text-emerald-400">SalonFlow AI</span>
        </h1>
        <p className="text-slate-400 text-lg">
          Atiende clientes por WhatsApp 24/7, responde dudas de precios, agenda citas sin solapamientos y reduce ausencias automáticamente.
        </p>
        <div className="flex justify-center gap-4 pt-4">
          <Link href="/dashboard" className="px-6 py-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold transition">
            Ir al Dashboard
          </Link>
          <Link href="/simulador" className="px-6 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium border border-slate-700 transition">
            Probar Simulador IA
          </Link>
        </div>
      </div>
    </main>
  );
}
`
  },
  {
    id: 'frontend-hook',
    category: 'frontend',
    path: 'frontend/hooks/use-receptionist.ts',
    filename: 'use-receptionist.ts',
    language: 'typescript',
    description: 'Custom React Hook para manejar el estado de conversación con el recepcionista IA.',
    content: `import { useState } from 'react';

export interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export function useReceptionist(salonId: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async (text: string) => {
    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/v1/receptionist/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, salonId }),
      });

      const data = await res.json();
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return { messages, sendMessage, isLoading };
}
`
  },

  // DATABASE (Supabase PostgreSQL)
  {
    id: 'db-schema',
    category: 'database',
    path: 'supabase/migrations/00001_initial_schema.sql',
    filename: '00001_initial_schema.sql',
    language: 'sql',
    description: 'Esquema PostgreSQL completo para Supabase con Tablas, Índices y Políticas de Seguridad RLS.',
    content: `-- SalonFlow AI - Schema Supabase (PostgreSQL)
-- Estructura de tablas y políticas Row Level Security (RLS)

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Tabla de Salones / Barberías
CREATE TABLE salons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50) NOT NULL,
    address TEXT,
    timezone VARCHAR(50) DEFAULT 'America/Mexico_City',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Tabla de Estilistas / Barberos
CREATE TABLE stylists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    salon_id UUID REFERENCES salons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    specialty VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Tabla de Servicios (Cortes, Barba, Tintes)
CREATE TABLE services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    salon_id UUID REFERENCES salons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 30,
    price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Tabla de Clientes
CREATE TABLE clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    salon_id UUID REFERENCES salons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    email VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(salon_id, phone)
);

-- 5. Tabla de Citas
CREATE TABLE appointments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    salon_id UUID REFERENCES salons(id) ON DELETE CASCADE,
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
    stylist_id UUID REFERENCES stylists(id) ON DELETE SET NULL,
    service_id UUID REFERENCES services(id) ON DELETE CASCADE,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(50) DEFAULT 'confirmed', -- confirmed, cancelled, completed
    created_by_ai BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar Row Level Security (RLS)
ALTER TABLE salons ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Los dueños de salón pueden ver sus datos"
    ON salons FOR SELECT
    USING (auth.uid() IS NOT NULL);
`
  },

  // n8n AUTOMATION
  {
    id: 'n8n-whatsapp',
    category: 'n8n',
    path: 'n8n/workflows/whatsapp_booking_flow.json',
    filename: 'whatsapp_booking_flow.json',
    language: 'json',
    description: 'Flujo n8n JSON para procesar webhooks de WhatsApp, consultar FastAPI/Gemini y responder.',
    content: `{
  "name": "SalonFlow AI - WhatsApp Webhook Workflow",
  "nodes": [
    {
      "parameters": {
        "httpMethod": "POST",
        "path": "whatsapp-incoming",
        "options": {}
      },
      "name": "Webhook WhatsApp Entrada",
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 1,
      "position": [250, 300]
    },
    {
      "parameters": {
        "url": "=http://fastapi-backend:8000/api/v1/receptionist/chat",
        "sendBody": true,
        "specifyBody": "json",
        "jsonBody": "={\\n  \"message\": \"{{ $json.body.entry[0].changes[0].value.messages[0].text.body }}\",\\n  \"client_phone\": \"{{ $json.body.entry[0].changes[0].value.messages[0].from }}\"\\n}"
      },
      "name": "Consultar FastAPI Gemini Engine",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 3,
      "position": [500, 300]
    },
    {
      "parameters": {
        "url": "https://graph.facebook.com/v18.0/WHATSAPP_PHONE_ID/messages",
        "sendHeaders": true,
        "headerParameters": {
          "parameters": [
            {
              "name": "Authorization",
              "value": "=Bearer {{ $env.WHATSAPP_API_TOKEN }}"
            }
          ]
        }
      },
      "name": "Enviar Respuesta WhatsApp",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 3,
      "position": [750, 300]
    }
  ],
  "connections": {
    "Webhook WhatsApp Entrada": {
      "main": [
        [{ "node": "Consultar FastAPI Gemini Engine", "type": "main", "index": 0 }]
      ]
    },
    "Consultar FastAPI Gemini Engine": {
      "main": [
        [{ "node": "Enviar Respuesta WhatsApp", "type": "main", "index": 0 }]
      ]
    }
  }
}`
  },

  // DOCKER & DEVOPS
  {
    id: 'docker-compose',
    category: 'devops',
    path: 'docker-compose.yml',
    filename: 'docker-compose.yml',
    language: 'yaml',
    description: 'Orquestación de servicios en contenedores para desarrollo y despliegue (FastAPI, Next.js, n8n, Redis).',
    content: `version: '3.8'

services:
  # Frontend Next.js 15
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      - NEXT_PUBLIC_SUPABASE_URL=\${NEXT_PUBLIC_SUPABASE_URL}
      - NEXT_PUBLIC_SUPABASE_ANON_KEY=\${NEXT_PUBLIC_SUPABASE_ANON_KEY}
    depends_on:
      - backend

  # Backend FastAPI (Clean Architecture)
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    ports:
      - "8000:8000"
    environment:
      - GEMINI_API_KEY=\${GEMINI_API_KEY}
      - DATABASE_URL=\${DATABASE_URL}
      - SUPABASE_URL=\${SUPABASE_URL}
      - SUPABASE_KEY=\${SUPABASE_SERVICE_ROLE_KEY}

  # Orquestador de Automatizaciones n8n
  n8n:
    image: docker.n8n.io/n8nio/n8n
    ports:
      - "5678:5678"
    environment:
      - N8N_HOST=n8n.salonflow.ai
      - N8N_PORT=5678
      - N8N_PROTOCOL=https
      - NODE_ENV=production
    volumes:
      - n8n_data:/home/node/.n8n

volumes:
  n8n_data:
`
  },
  {
    id: 'dockerfile-backend',
    category: 'devops',
    path: 'docker/Dockerfile.backend',
    filename: 'Dockerfile.backend',
    language: 'dockerfile',
    description: 'Build multi-etapa optimizado para FastAPI con Python 3.11 slim.',
    content: `# Multi-stage Build para FastAPI Backend
FROM python:3.11-slim as builder

WORKDIR /app

ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

RUN apt-get update && apt-get install -y --no-install-recommends gcc libpq-dev

COPY requirements.txt .
RUN pip wheel --no-cache-dir --no-deps --wheel-dir /app/wheels -r requirements.txt

# Runner Stage
FROM python:3.11-slim

WORKDIR /app

COPY --from=builder /app/wheels /wheels
RUN pip install --no-cache /wheels/*

COPY app/ ./app

EXPOSE 8000

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
`
  },
  {
    id: 'github-cicd',
    category: 'devops',
    path: '.github/workflows/ci-cd.yml',
    filename: 'ci-cd.yml',
    language: 'yaml',
    description: 'Pipeline GitHub Actions para testing automático y despliegue continuo en producción.',
    content: `name: SalonFlow AI CI/CD Pipeline

on:
  push:
    branches: [ main, main-staging ]
  pull_request:
    branches: [ main ]

jobs:
  test-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Python 3.11
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install pytest pytest-asyncio
      - name: Run Clean Architecture Domain Tests
        run: pytest backend/tests

  test-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup Node.js 20
        uses: actions/setup-node@v3
        with:
          node-version: '20'
      - name: Install & Lint
        run: |
          cd frontend
          npm ci
          npm run lint
`
  },

  // DOCUMENTATION
  {
    id: 'doc-readme',
    category: 'docs',
    path: 'README.md',
    filename: 'README.md',
    language: 'markdown',
    description: 'Guía oficial de arquitectura, instalación y desarrollo de SalonFlow AI.',
    content: `# SalonFlow AI - Recepcionista Virtual con IA para Salones y Barberías

SalonFlow AI es una plataforma SaaS diseñada para automatizar la atención al cliente, consultas de precios y agendamiento de citas en peluquerías y barberías mediante Inteligencia Artificial (Google AI Studio / Gemini) e integración con WhatsApp y n8n.

## 🏗️ Arquitectura del Sistema (Clean Architecture)

El proyecto está estructurado bajo los principios de **Clean Architecture**:

\`\`\`
salonflow-ai/
├── backend/                  # FastAPI (Python 3.11)
│   ├── app/
│   │   ├── domain/           # Entidades puras y Reglas de Negocio (sin dependencias)
│   │   ├── use_cases/        # Casos de Uso (Agendamiento, Consultas)
│   │   ├── adapters/         # Adaptadores (Gemini SDK, Supabase Repository)
│   │   └── api/              # Controladores y Endpoints FastAPI
├── frontend/                 # Next.js 15 (TypeScript, TailwindCSS)
│   ├── app/                  # App Router
│   ├── components/           # Componentes UI
│   └── hooks/                # Hooks personalizados
├── supabase/                 # Migraciones SQL & RLS Policies
├── n8n/                      # Workflows de Automatización WhatsApp & SMS
├── docker/                   # Dockerfiles & Docker-Compose
└── .github/workflows/        # CI/CD Pipelines
\`\`\`

## 🚀 Inicio Rápido con Docker

\`\`\`bash
# 1. Clonar el repositorio
git clone https://github.com/tu-usuario/salonflow-ai.git
cd salonflow-ai

# 2. Configurar variables de entorno
cp .env.example .env

# 3. Levantar los servicios con Docker Compose
docker-compose up --build -d
\`\`\`

## 🛠️ Tecnologías Utilizadas

- **Frontend:** Next.js 15, React 19, TypeScript, TailwindCSS, Lucide Icons
- **Backend:** FastAPI, Python 3.11, Pydantic v2
- **IA:** Google AI Studio (Gemini 3.6 Flash)
- **Base de Datos:** PostgreSQL (Supabase) con RLS
- **Automatizaciones:** n8n (Webhooks WhatsApp Business API)
- **DevOps:** Docker, GitHub Actions CI/CD
`
  },
  {
    id: 'doc-arch',
    category: 'docs',
    path: 'docs/ARCHITECTURE.md',
    filename: 'ARCHITECTURE.md',
    language: 'markdown',
    description: 'Documentación técnica de la Clean Architecture y separación de capas de SalonFlow AI.',
    content: `# Documentación Técnica: Clean Architecture en SalonFlow AI

## 1. Principios Fundamentales
1. **Independencia de Frameworks:** Las reglas de negocio en \`domain/\` no dependen de FastAPI, Next.js ni Supabase.
2. **Testabilidad:** Los casos de uso (\`use_cases/\`) se prueban unitariamente mediante Mocks de los puertos.
3. **Inversión de Dependencias:** La capa de infraestructura depende del dominio a través de Interfaces (Ports).

## 2. Diagrama de Flujo de Datos

\`\`\`
[ Mensaje Cliente WhatsApp ] 
        │
        ▼
   [ n8n Webhook ] ──▶ [ FastAPI Backend ]
                             │
                             ├──▶ [ Gemini AI Adapter (Extracción de Intención) ]
                             │
                             ├──▶ [ Booking UseCase (Validación de Reglas) ]
                             │
                             └──▶ [ Supabase Repository (Persistencia SQL) ]
\`\`\`
`
  }
];
