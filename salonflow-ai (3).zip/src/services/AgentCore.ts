import { GoogleGenAI } from '@google/genai';
import { BusinessInfo, CustomerInfo, BookingPayload } from '../types/receptionist.js';
import {
  AgentIntent,
  AgentProcessInput,
  AgentProcessResponse,
  MemoryState,
  MemorySlotState,
  PipelineStepLog,
  ToolExecutionResult,
  ToolName,
  ToolDefinition,
} from '../types/agent.js';
import { CustomerMemoryStore, CustomerMemory } from './CustomerMemory.js';
import { Planner } from './Planner.js';
import { SafetyLayer } from './SafetyLayer.js';

// ============================================================================
// 1. IN-MEMORY CONVERSATION MEMORY STORE
// ============================================================================
export class MemoryStore {
  private static instance: MemoryStore;
  private memories: Map<string, MemoryState> = new Map();

  private constructor() {}

  public static getInstance(): MemoryStore {
    if (!MemoryStore.instance) {
      MemoryStore.instance = new MemoryStore();
    }
    return MemoryStore.instance;
  }

  public getOrCreateMemory(
    conversationId: string,
    defaultBusiness: BusinessInfo,
    defaultCustomer: CustomerInfo
  ): MemoryState {
    if (!this.memories.has(conversationId)) {
      const now = new Date().toISOString();
      const newMemory: MemoryState = {
        conversation_id: conversationId,
        history: [],
        business: defaultBusiness,
        customer: defaultCustomer,
        slots: {
          customer_name: defaultCustomer.name,
          customer_phone: defaultCustomer.phone,
        },
        handover_requested: false,
        created_at: now,
        updated_at: now,
      };
      this.memories.set(conversationId, newMemory);
    }
    return this.memories.get(conversationId)!;
  }

  public updateMemory(
    conversationId: string,
    updates: Partial<MemoryState> & { slotsUpdates?: Partial<MemorySlotState> }
  ): MemoryState {
    const memory = this.memories.get(conversationId);
    if (!memory) return this.getOrCreateMemory(conversationId, updates.business!, updates.customer!);

    if (updates.slotsUpdates) {
      memory.slots = { ...memory.slots, ...updates.slotsUpdates };
    }
    if (updates.history) memory.history = updates.history;
    if (updates.business) memory.business = updates.business;
    if (updates.customer) memory.customer = updates.customer;
    if (updates.last_intent) memory.last_intent = updates.last_intent;
    if (updates.last_tool_executed) memory.last_tool_executed = updates.last_tool_executed;
    if (updates.handover_requested !== undefined) memory.handover_requested = updates.handover_requested;

    memory.updated_at = new Date().toISOString();
    this.memories.set(conversationId, memory);
    return memory;
  }

  public clearMemory(conversationId: string): void {
    this.memories.delete(conversationId);
  }
}

// ============================================================================
// 2. TOOL REGISTRY & TOOL EXECUTORS
// ============================================================================
export class ToolRegistry {
  public static getToolDefinitions(): ToolDefinition[] {
    return [
      { name: 'check_availability_tool', description: 'Obtiene disponibilidad de turnos libres para una fecha y servicio.', parametersSchema: {} },
      { name: 'create_booking_tool', description: 'Crea y confirma una reserva de cita en el sistema.', parametersSchema: {} },
      { name: 'get_services_catalog_tool', description: 'Obtiene la lista de servicios, precios y duraciones.', parametersSchema: {} },
      { name: 'get_opening_hours_tool', description: 'Obtiene los horarios oficiales de apertura y cierre.', parametersSchema: {} },
      { name: 'escalate_human_handover_tool', description: 'Escala la atención hacia un recepcionista humano.', parametersSchema: {} },
      { name: 'cancel_booking_tool', description: 'Cancela una reserva o cita existente.', parametersSchema: {} },
    ];
  }

  public static executeTool(
    toolName: ToolName,
    params: {
      message: string;
      memory: MemoryState;
      business: BusinessInfo;
      customer: CustomerInfo;
    }
  ): ToolExecutionResult {
    const { message, memory, business, customer } = params;
    const slots = memory.slots;

    switch (toolName) {
      case 'check_availability_tool': {
        const dateStr = slots.date || 'Hoy/Mañana';
        const serviceStr = slots.service || 'Servicio General';
        const availableSlots = ['10:00 AM', '11:30 AM', '04:00 PM', '05:30 PM'];

        return {
          toolName: 'check_availability_tool',
          success: true,
          data: {
            date: dateStr,
            service: serviceStr,
            availableSlots,
            isAvailable: true,
          },
          summary: `Consulta de disponibilidad para ${serviceStr} el ${dateStr}. Horarios libres: ${availableSlots.join(', ')}.`,
        };
      }

      case 'create_booking_tool': {
        const name = slots.customer_name || customer.name || 'Cliente SalonFlow';
        const phone = slots.customer_phone || customer.phone || '+52 55 0000 0000';
        const service = slots.service || 'Corte de Cabello Tradicional';
        const date = slots.date || 'Mañana';
        const time = slots.time || '16:00';

        const bookingPayload: BookingPayload = {
          action: 'create_booking',
          customer_name: name,
          phone: phone,
          service: service,
          date: date,
          time: time,
        };

        return {
          toolName: 'create_booking_tool',
          success: true,
          data: {
            booking: bookingPayload,
            confirmation_code: `BK-${Math.floor(100000 + Math.random() * 900000)}`,
            status: 'confirmed',
          },
          summary: `Cita confirmada con éxito para ${name} en servicio ${service} el ${date} a las ${time}.`,
        };
      }

      case 'get_services_catalog_tool': {
        const services = business.services || [];
        return {
          toolName: 'get_services_catalog_tool',
          success: true,
          data: {
            currency: business.currency || 'USD',
            servicesCount: services.length,
            services: services.map((s) => ({
              name: s.name,
              price: `${s.price} €`,
              duration: `${s.duration_minutes || 30} min`,
            })),
          },
          summary: `Catálogo consultado: ${services.map((s) => `${s.name} (${s.price} €)`).join(', ')}.`,
        };
      }

      case 'get_opening_hours_tool': {
        const hours = business.opening_hours || [];
        return {
          toolName: 'get_opening_hours_tool',
          success: true,
          data: {
            opening_hours: hours,
          },
          summary: `Horarios consultados: ${hours.map((h) => `${h.day}: ${h.open} - ${h.close}`).join(' | ')}.`,
        };
      }

      case 'escalate_human_handover_tool': {
        const ticketId = `HANDOVER-${Math.floor(1000 + Math.random() * 9000)}`;
        return {
          toolName: 'escalate_human_handover_tool',
          success: true,
          data: {
            ticketId,
            status: 'escalated_to_human_agent',
            customer_phone: customer.phone || 'Sin número registrado',
            escalation_time: new Date().toISOString(),
          },
          summary: `Escalación creada exitosamente Ticket #${ticketId}. Un recepcionista humano tomará la conversación.`,
        };
      }

      case 'cancel_booking_tool': {
        return {
          toolName: 'cancel_booking_tool',
          success: true,
          data: {
            status: 'cancelled',
            message: 'Cita cancelada correctamente.',
          },
          summary: 'Proceso de cancelación de cita ejecutado.',
        };
      }

      default:
        return {
          toolName: 'none',
          success: true,
          data: {},
          summary: 'No se requirió ejecución de Tool externa.',
        };
    }
  }
}

// ============================================================================
// 3. AGENT CORE - CEREBRO CENTRAL DE SALONFLOW AI
// ============================================================================
export class AgentCore {
  private aiClient: GoogleGenAI | null = null;
  private memoryStore: MemoryStore;
  private planner: Planner;
  private safetyLayer: SafetyLayer;

  constructor(safetyConfig?: any) {
    this.memoryStore = MemoryStore.getInstance();
    this.planner = new Planner();
    this.safetyLayer = new SafetyLayer(safetyConfig);
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      this.aiClient = new GoogleGenAI({ apiKey });
    }
  }

  public getSafetyLayer(): SafetyLayer {
    return this.safetyLayer;
  }

  /**
   * Método principal de procesamiento que orquesta el flujo exacto solicitado:
   *
   * Recibir mensaje
   * ↓
   * Identificar intención
   * ↓
   * Consultar memoria
   * ↓
   * Decidir qué Tool utilizar
   * ↓
   * Ejecutar Tool
   * ↓
   * Actualizar memoria
   * ↓
   * Responder
   */
  public async processMessage(input: AgentProcessInput): Promise<AgentProcessResponse> {
    const startTime = Date.now();
    const pipelineSteps: PipelineStepLog[] = [];

    // Default configuration fallback
    const business: BusinessInfo = input.business || {
      name: 'Barbería & Peluquería Elegance',
      currency: 'EUR',
      phone: '+34 912 345 678',
      address: 'Calle Gran Vía 28, Madrid',
      services: [
        { name: 'Corte de Cabello Tradicional', price: 20, duration_minutes: 30 },
        { name: 'Arreglo y Perfilado de Barba', price: 15, duration_minutes: 20 },
        { name: 'Combo VIP Corte + Barba', price: 30, duration_minutes: 50 },
        { name: 'Tinte & Matiz Capilar', price: 45, duration_minutes: 60 },
        { name: 'Peinado & Estilismo', price: 25, duration_minutes: 30 },
      ],
      opening_hours: [
        { day: 'Lunes a Viernes', open: '09:00', close: '20:00', is_closed: false },
        { day: 'Sábado', open: '09:00', close: '18:00', is_closed: false },
        { day: 'Domingo', open: '10:00', close: '15:00', is_closed: false },
      ],
    };

    const customer: CustomerInfo = input.customer || {
      name: 'Javier Guerra',
      phone: '+34 612 345 678',
    };

    const conversationId = input.conversation_id || 'default_session_1';

    // ------------------------------------------------------------------------
    // PASO 1: Recibir mensaje
    // ------------------------------------------------------------------------
    pipelineSteps.push({
      stepNumber: 1,
      stepName: 'receive_message',
      title: 'Paso 1: Recibir Mensaje',
      description: 'Entrada del cliente capturada y procesada por AgentCore.',
      data: {
        user_message: input.user_message,
        conversation_id: conversationId,
        persona: input.persona || 'barber',
      },
    });

    // ------------------------------------------------------------------------
    // PASO 2: Identificar intención
    // ------------------------------------------------------------------------
    const detectedIntent = this.identifyIntent(input.user_message);
    pipelineSteps.push({
      stepNumber: 2,
      stepName: 'identify_intent',
      title: 'Paso 2: Identificar Intención',
      description: `Intención clasificada como: ${detectedIntent}`,
      data: {
        intent: detectedIntent,
        confidence: 0.95,
      },
    });

    // ------------------------------------------------------------------------
    // PASO 3: Consultar memoria
    // ------------------------------------------------------------------------
    const memory = this.memoryStore.getOrCreateMemory(conversationId, business, customer);

    // Extraer slots clave del mensaje del usuario para nutrir la memoria
    const extractedSlotsUpdates = this.extractSlotsFromMessage(input.user_message, business);

    pipelineSteps.push({
      stepNumber: 3,
      stepName: 'consult_memory',
      title: 'Paso 3: Consultar Memoria',
      description: 'Estado previo de slots y conversación recuperado.',
      data: {
        conversation_id: conversationId,
        existing_history_count: memory.history.length,
        current_slots: { ...memory.slots, ...extractedSlotsUpdates },
        last_intent: memory.last_intent,
      },
    });

    // ------------------------------------------------------------------------
    // PASO 4: Decidir qué Tool y Acciones utilizar (Planner)
    // ------------------------------------------------------------------------
    const updatedSlots = { ...memory.slots, ...extractedSlotsUpdates };

    const customerMemStore = CustomerMemoryStore.getInstance();
    const custMem = customerMemStore.getOrCreate(customer.phone || customer.name || 'default', {
      name: customer.name,
      phone: customer.phone,
    });

    const executionPlan = await this.planner.generatePlan({
      user_message: input.user_message,
      business,
      customer: custMem.getProfile(),
      available_tools: ToolRegistry.getToolDefinitions(),
      session_slots: updatedSlots,
    });

    const decidedTool = this.decideTool(detectedIntent, updatedSlots, input.user_message);

    pipelineSteps.push({
      stepNumber: 4,
      stepName: 'decide_tool',
      title: 'Paso 4: Decidir Acciones y Generar Plan (Planner)',
      description: `Plan generado por Planner: [Goal: ${executionPlan.plan_goal}]. Tool principal: ${decidedTool}`,
      data: {
        decidedTool,
        executionPlan,
        reasoning: executionPlan.reasoning || this.getToolReasoning(decidedTool, detectedIntent, updatedSlots),
      },
    });

    // ------------------------------------------------------------------------
    // PASO 5: Ejecutar Tool
    // ------------------------------------------------------------------------
    let toolResult: ToolExecutionResult | null = null;
    if (decidedTool !== 'none') {
      toolResult = ToolRegistry.executeTool(decidedTool, {
        message: input.user_message,
        memory: { ...memory, slots: updatedSlots },
        business,
        customer,
      });
    }

    pipelineSteps.push({
      stepNumber: 5,
      stepName: 'execute_tool',
      title: 'Paso 5: Ejecutar Tool',
      description: decidedTool !== 'none' ? `Tool '${decidedTool}' ejecutada correctamente.` : 'Sin ejecución de Tool necesaria.',
      data: toolResult || { toolName: 'none', success: true, summary: 'N/A' },
    });

    // ------------------------------------------------------------------------
    // PASO 6: Actualizar memoria (MemoryStore & CustomerMemory)
    // ------------------------------------------------------------------------
    const updatedTurnHistory = [
      ...memory.history,
      {
        id: Date.now().toString(),
        role: 'user' as const,
        text: input.user_message,
        timestamp: new Date().toISOString(),
        intent: detectedIntent,
        toolExecuted: decidedTool,
      },
    ];

    const isHandover = detectedIntent === 'human_handover';

    const updatedMemory = this.memoryStore.updateMemory(conversationId, {
      history: updatedTurnHistory,
      slotsUpdates: extractedSlotsUpdates,
      last_intent: detectedIntent,
      last_tool_executed: decidedTool,
      handover_requested: isHandover || memory.handover_requested,
      business,
      customer,
    });

    // Actualizar CustomerMemory (CRM Persistente Optimizado)
    if (decidedTool === 'create_booking_tool' && toolResult?.data?.booking) {
      const bPayload = toolResult.data.booking;
      custMem.recordBooking({
        service: bPayload.service,
        date: bPayload.date,
        time: bPayload.time,
        status: 'confirmed',
      });
      custMem.recordService(bPayload.service);
    } else {
      custMem.updateProfile({
        name: updatedMemory.slots.customer_name || customer.name,
        phone: updatedMemory.slots.customer_phone || customer.phone,
      });
    }

    pipelineSteps.push({
      stepNumber: 6,
      stepName: 'update_memory',
      title: 'Paso 6: Actualizar Memoria',
      description: 'Slots, turno de usuario y perfil CustomerMemory (resumen optimizado) guardados.',
      data: {
        updated_slots: updatedMemory.slots,
        total_turns: updatedTurnHistory.length,
        customer_memory_summary: custMem.getShortSummary(),
        handover_requested: updatedMemory.handover_requested,
      },
    });

    // ------------------------------------------------------------------------
    // PASO 7: Responder (Sintetizar respuesta con Gemini o Fallback)
    // ------------------------------------------------------------------------
    const systemInstruction = this.buildSystemInstruction(
      business,
      customer,
      updatedMemory,
      toolResult,
      input.persona
    );

    const { reply: rawReply, rawResponse, promptSent, tokensUsed } = await this.synthesizeReply(
      systemInstruction,
      input.user_message,
      toolResult,
      business,
      customer,
      updatedMemory
    );

    // ------------------------------------------------------------------------
    // PASO 7.1: Safety Layer Verification
    // ------------------------------------------------------------------------
    const safetyCheck = this.safetyLayer.validateResponse({
      user_message: input.user_message,
      proposed_response: rawReply,
      business,
      execution_plan: executionPlan,
      executed_tool: toolResult?.toolName,
      tool_execution_data: toolResult?.data,
    });

    const finalReply = safetyCheck.final_response;

    // Agregar respuesta del asistente a la memoria
    this.memoryStore.updateMemory(conversationId, {
      history: [
        ...updatedMemory.history,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant' as const,
          text: finalReply,
          timestamp: new Date().toISOString(),
        },
      ],
    });

    const endTime = Date.now();
    const responseTimeMs = endTime - startTime;

    // Extraer booking confirmada de la ejecución de Tool si existe
    const bookingPayload: BookingPayload | null = toolResult?.data?.booking || null;

    // Sugerir acciones rápidas según la intención
    const suggestedActions = this.generateSuggestedActions(detectedIntent, bookingPayload);

    pipelineSteps.push({
      stepNumber: 7,
      stepName: 'respond',
      title: 'Paso 7: Safety Layer & Responder',
      description: `Respuesta final verificada por SafetyLayer (Seguro: ${safetyCheck.is_safe ? 'SÍ' : 'NO - Modificado por seguridad'}).`,
      data: {
        responseTimeMs,
        tokensUsed,
        hasBooking: !!bookingPayload,
        is_safe: safetyCheck.is_safe,
        violations: safetyCheck.violations,
        incident_logged: safetyCheck.incident_logged,
      },
    });

    return {
      reply: finalReply,
      detectedIntent,
      booking: bookingPayload,
      toolExecuted: toolResult,
      suggestedActions,
      responseTimeMs,
      tokensUsed,
      promptSent,
      raw_response: rawResponse,
      contextUsed: {
        business,
        customer,
        memorySlots: updatedMemory.slots,
      },
      pipelineSteps,
      memoryState: updatedMemory,
    };
  }

  // ==========================================================================
  // HELPER INTERNAL METHODS FOR AGENT CORE
  // ==========================================================================

  private identifyIntent(message: string): AgentIntent {
    const text = message.toLowerCase();

    if (/humano|persona|queja|agente|hablar con alguien|gerente/i.test(text)) {
      return 'human_handover';
    }
    if (/cancelar|anular|eliminar cita/i.test(text)) {
      return 'cancel_booking';
    }
    if (/cita|agendar|reservar|turno|corte para|mañana|a las/i.test(text)) {
      return 'appointment_booking';
    }
    if (/precio|cuánto|costo|vale|servicios|catalogo|corte/i.test(text)) {
      return 'service_inquiry';
    }
    if (/horario|abren|cierran|abierto|hora/i.test(text)) {
      return 'business_hours_inquiry';
    }

    return 'general_inquiry';
  }

  private extractSlotsFromMessage(message: string, business: BusinessInfo): Partial<MemorySlotState> {
    const text = message.toLowerCase();
    const updates: Partial<MemorySlotState> = {};

    // Coincidencia con catálogo de servicios
    for (const service of business.services) {
      if (text.includes(service.name.toLowerCase())) {
        updates.service = service.name;
        break;
      }
    }
    if (!updates.service) {
      if (text.includes('barba')) updates.service = 'Arreglo y Perfilado de Barba';
      else if (text.includes('tinte')) updates.service = 'Tinte & Matiz Capilar';
      else if (text.includes('combo')) updates.service = 'Combo VIP Corte + Barba';
      else if (text.includes('corte')) updates.service = 'Corte de Cabello Tradicional';
    }

    // Coincidencia con fechas
    if (text.includes('hoy')) updates.date = 'Hoy';
    else if (text.includes('mañana')) updates.date = 'Mañana';
    else if (text.includes('lunes')) updates.date = 'Próximo Lunes';
    else if (text.includes('sábado') || text.includes('sabado')) updates.date = 'Próximo Sábado';

    // Coincidencia con horas
    const timeMatch = text.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|hrs)?/i);
    if (timeMatch) {
      let hour = parseInt(timeMatch[1], 10);
      const isPm = text.includes('pm') || (hour < 8 && !text.includes('am'));
      if (isPm && hour < 12) hour += 12;
      const hourStr = hour < 10 ? `0${hour}` : `${hour}`;
      updates.time = `${hourStr}:00`;
    }

    return updates;
  }

  private decideTool(intent: AgentIntent, slots: MemorySlotState, message: string): ToolName {
    if (intent === 'human_handover') return 'escalate_human_handover_tool';
    if (intent === 'cancel_booking') return 'cancel_booking_tool';
    if (intent === 'service_inquiry') return 'get_services_catalog_tool';
    if (intent === 'business_hours_inquiry') return 'get_opening_hours_tool';

    if (intent === 'appointment_booking') {
      // Si tenemos servicio, fecha y hora -> Ejecutar creación de reserva
      if (slots.service && slots.date && slots.time) {
        return 'create_booking_tool';
      }
      // Si sólo está preguntando por disponibilidad
      return 'check_availability_tool';
    }

    return 'none';
  }

  private getToolReasoning(tool: ToolName, intent: AgentIntent, slots: MemorySlotState): string {
    switch (tool) {
      case 'create_booking_tool':
        return `Slots completos detectados (${slots.service || 'Servicio'}, ${slots.date || 'Fecha'}, ${slots.time || 'Hora'}). Procediendo a confirmar reserva.`;
      case 'check_availability_tool':
        return `Intención de agendamiento sin slots completos. Verificando horarios disponibles.`;
      case 'get_services_catalog_tool':
        return `Cliente solicita información sobre precios y catálogo de servicios.`;
      case 'get_opening_hours_tool':
        return `Cliente pregunta por los horarios de atención.`;
      case 'escalate_human_handover_tool':
        return `Solicitud explícita de atención humana o escalación.`;
      case 'cancel_booking_tool':
        return `Solicitud de cancelación de cita.`;
      default:
        return `Consulta general atendida directamente por el modelo conversacional.`;
    }
  }

  private buildSystemInstruction(
    business: BusinessInfo,
    customer: CustomerInfo,
    memory: MemoryState,
    toolResult: ToolExecutionResult | null,
    persona?: string
  ): string {
    const servicesText = business.services.map((s) => `- ${s.name}: $${s.price}`).join('\n');
    const hoursText = business.opening_hours.map((h) => `- ${h.day}: ${h.open} - ${h.close}`).join('\n');

    let toneStyle = 'Cálido, profesional y directo.';
    if (persona === 'barber') toneStyle = 'Estilo barbero relajado, amigable con emojis como 💈, ✂️, 👊.';
    if (persona === 'chic') toneStyle = 'Estilo glamuroso, elegante y sofisticado con emojis ✨, 💇‍♀️, 💅.';

    let toolContextPrompt = '';
    if (toolResult) {
      toolContextPrompt = `
RESULTADO DE LA TOOL EJECUTADA (${toolResult.toolName}):
- Estado: ${toolResult.success ? 'Exitoso' : 'Error'}
- Resumen: ${toolResult.summary}
- Datos: ${JSON.stringify(toolResult.data)}
Utiliza este resultado para responder al cliente de manera precisa y amable.
`;
    }

    const customerMemStore = CustomerMemoryStore.getInstance();
    const custMem = customerMemStore.getOrCreate(customer.phone || customer.name || 'default', {
      name: customer.name,
      phone: customer.phone,
      favorite_barber: customer.preferred_stylist,
    });
    const customerMemorySummary = custMem.getShortSummary();

    return `
Eres la recepcionista virtual inteligente de "${business.name}", operada por SalonFlow AI.

ESTILO Y TONO:
${toneStyle}

DATOS OFICIALES DEL NEGOCIO:
Teléfono: ${business.phone || 'No especificado'}
Dirección: ${business.address || 'No especificada'}

CATÁLOGO DE SERVICIOS:
${servicesText}

HORARIOS DE ATENCIÓN:
${hoursText}

${customerMemorySummary}

ESTADO DE MEMORIA / SLOTS ACTUALES DE LA SESIÓN:
${JSON.stringify(memory.slots, null, 2)}

${toolContextPrompt}

REGLAS OBLIGATORIAS DE RESPUESTA:
1. Responde SIEMPRE en español.
2. Si el cliente confirmó una cita (se ejecutó create_booking_tool), felicítalo y dale los detalles.
3. Personaliza la atención utilizando la información de CustomerMemory (barbero favorito, preferencias, historial) si es relevante.
4. Sé conciso y claro (máximo 2 a 3 frases por respuesta). Para optimizar tokens, no repitas transcripciones completas de conversaciones anteriores.
`;
  }

  private async synthesizeReply(
    systemInstruction: string,
    userMessage: string,
    toolResult: ToolExecutionResult | null,
    business: BusinessInfo,
    customer: CustomerInfo,
    memory?: MemoryState
  ): Promise<{
    reply: string;
    rawResponse: string;
    promptSent: string;
    tokensUsed: { promptTokens: number; candidatesTokens: number; totalTokens: number };
  }> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && !this.aiClient) {
      this.aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }

    if (this.aiClient) {
      try {
        const historyMsgs = memory?.history || [];
        const rawContents: Array<{ role: 'user' | 'model'; text: string }> = [];

        for (const msg of historyMsgs.slice(-8)) {
          const text = msg.text?.trim();
          if (!text) continue;
          const role: 'user' | 'model' = msg.role === 'user' ? 'user' : 'model';
          rawContents.push({ role, text });
        }

        if (
          rawContents.length === 0 ||
          rawContents[rawContents.length - 1].role !== 'user' ||
          rawContents[rawContents.length - 1].text !== userMessage
        ) {
          rawContents.push({ role: 'user', text: userMessage });
        }

        // Consolidation for strict role alternation (user, model, user, model...)
        const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];
        for (const item of rawContents) {
          if (contents.length > 0 && contents[contents.length - 1].role === item.role) {
            contents[contents.length - 1].parts[0].text += `\n${item.text}`;
          } else {
            contents.push({
              role: item.role,
              parts: [{ text: item.text }],
            });
          }
        }

        const modelsToTry = ['gemini-3.6-flash', 'gemini-2.5-flash', 'gemini-2.0-flash'];
        for (const modelName of modelsToTry) {
          try {
            const response = await this.aiClient.models.generateContent({
              model: modelName,
              contents,
              config: {
                systemInstruction,
                temperature: 0.5,
              },
            });

            const rawText = response.text || '';
            if (rawText.trim()) {
              const usage = response.usageMetadata;
              const promptTokens = usage?.promptTokenCount || Math.round((systemInstruction.length + userMessage.length) / 4);
              const candidatesTokens = usage?.candidatesTokenCount || Math.round(rawText.length / 4);

              return {
                reply: rawText,
                rawResponse: rawText,
                promptSent: systemInstruction,
                tokensUsed: {
                  promptTokens,
                  candidatesTokens,
                  totalTokens: promptTokens + candidatesTokens,
                },
              };
            }
          } catch (modelErr: any) {
            // Continuar al siguiente modelo en cascada
          }
        }
        console.info('[AgentCore] Servicio Gemini no disponible en ningún modelo. Usando motor conversacional local.');
      } catch (err: any) {
        console.info('[AgentCore] Error en cliente Gemini. Usando motor conversacional local.');
      }
    }

    // Fallback conversacional inteligente según Tool y Slots
    let fallbackText = '';
    const slots = memory?.slots || {};

    if (toolResult?.toolName === 'create_booking_tool') {
      const b = toolResult.data.booking;
      fallbackText = `¡Excelente, ${b.customer_name}! 💈 Cita confirmada con éxito para **${b.service}** el **${b.date}** a las **${b.time}**. Código de confirmación: **${toolResult.data.confirmation_code || 'CONF-100'}**. ¡Te esperamos en ${business.name}!`;
    } else if (toolResult?.toolName === 'check_availability_tool') {
      const availSlots = toolResult.data.availableSlots ? toolResult.data.availableSlots.join(', ') : '10:00 AM, 11:30 AM, 04:00 PM';
      const targetService = slots.service || toolResult.data.service || 'Corte de Cabello Tradicional';
      const targetDate = slots.date || toolResult.data.date || 'Mañana';
      fallbackText = `Para **${targetService}** el **${targetDate}**, tenemos disponibles los siguientes horarios:\n\n• ${availSlots}\n\n¿Cuál de estos horarios prefieres agendar?`;
    } else if (toolResult?.toolName === 'get_services_catalog_tool') {
      fallbackText = `En **${business.name}** te ofrecemos los siguientes servicios y precios:\n\n` + business.services.map((s) => `• **${s.name}**: ${s.price} € (${s.duration_minutes || 30} min)`).join('\n') + `\n\n¿Te gustaría agendar alguno de nuestros servicios hoy?`;
    } else if (toolResult?.toolName === 'get_opening_hours_tool') {
      fallbackText = `Nuestros horarios de atención en **${business.name}** son los siguientes:\n\n` + business.opening_hours.map((h) => `• **${h.day}**: ${h.is_closed ? 'Cerrado' : `${h.open} - ${h.close}`}`).join('\n') + `\n\n¿En qué día y horario te gustaría visitarnos?`;
    } else if (toolResult?.toolName === 'escalate_human_handover_tool') {
      fallbackText = `Entendido. He derivado tu atención a un recepcionista humano en **${business.name}**. Tu folio de atención es el **Ticket #${toolResult.data.ticketId}**. En breve un agente se comunicará contigo.`;
    } else if (toolResult?.toolName === 'cancel_booking_tool') {
      fallbackText = `Con gusto. Tu cita en **${business.name}** ha sido cancelada correctamente. Si deseas agendar una nueva cita en otro momento, aquí estaré para ayudarte.`;
    } else {
      const msgLower = userMessage.toLowerCase();
      if (msgLower.includes('ubic') || msgLower.includes('donde') || msgLower.includes('direcci') || msgLower.includes('donde estan')) {
        fallbackText = `Nos encontramos ubicados en **${business.address || 'Calle Gran Vía 28, Madrid'}**. Nuestro teléfono de contacto es ${business.phone || '+34 912 345 678'}. ¿Te gustaría agendar una cita?`;
      } else if (msgLower.includes('hola') || msgLower.includes('buenas') || msgLower.includes('buenos')) {
        fallbackText = `¡Hola, ${customer.name || 'estimado cliente'}! Bienvenido a **${business.name}**. 💈 ¿En qué puedo ayudarte hoy? Puedes consultar nuestro catálogo de servicios, conocer nuestros horarios o agendar una cita.`;
      } else if (slots.service && !slots.date) {
        fallbackText = `Perfecto, deseas agendar **${slots.service}**. ¿Para qué día te gustaría la cita (por ejemplo: Hoy, Mañana o Sábado)?`;
      } else if (slots.service && slots.date && !slots.time) {
        fallbackText = `Excelente. Para tu cita de **${slots.service}** el **${slots.date}**, ¿en qué horario prefieres venir? (Ejemplo: 10:00, 16:00 o 18:00 hrs).`;
      } else {
        fallbackText = `Con gusto te asisto en **${business.name}**. ¿Te gustaría ver las opciones de cortes y barba, conocer nuestros horarios disponibles o agendar una cita?`;
      }
    }

    const pTokens = Math.round(systemInstruction.length / 4);
    const cTokens = Math.round(fallbackText.length / 4);

    return {
      reply: fallbackText,
      rawResponse: fallbackText,
      promptSent: systemInstruction,
      tokensUsed: {
        promptTokens: pTokens,
        candidatesTokens: cTokens,
        totalTokens: pTokens + cTokens,
      },
    };
  }

  private generateSuggestedActions(intent: AgentIntent, booking: BookingPayload | null): string[] {
    if (booking) return ['Ver Detalles de Cita', 'Cambiar Horario', 'Hablar con Recepcionista'];
    if (intent === 'service_inquiry') return ['Agendar Cita', 'Ver Horarios', 'Hablar con Barbero'];
    if (intent === 'business_hours_inquiry') return ['Ver Servicios', 'Agendar Cita', 'Dirección'];
    if (intent === 'human_handover') return ['Estado de Ticket', 'Cancelar Cita', 'Volver al Bot'];
    return ['Agendar Cita', 'Ver Precios', 'Horarios de Atención'];
  }
}
