import { GoogleGenAI } from '@google/genai';
import { ExecutionPlan, PlannerInput, PlanStep } from '../types/planner.js';
import { ToolName } from '../types/agent.js';

/**
 * Planner - Componente de Planificación de SalonFlow AI.
 * 
 * Recibe:
 * - Mensaje del usuario
 * - Estado del negocio (business)
 * - Estado del cliente (customer memory profile)
 * - Herramientas disponibles (available_tools)
 * 
 * Responsabilidad:
 * - Decidir qué secuencia ordenada de acciones/tools ejecutar.
 * - NO responde directamente al usuario final con chats; SOLO genera el plan de ejecución.
 * - Gemini o AgentCore ejecutarán las acciones del plan.
 */
export class Planner {
  private aiClient: GoogleGenAI | null = null;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      this.aiClient = new GoogleGenAI({ apiKey });
    }
  }

  /**
   * Genera un plan de ejecución estructurado a partir del mensaje y contexto actual.
   */
  public async generatePlan(input: PlannerInput): Promise<ExecutionPlan> {
    const { user_message, business, customer, available_tools, session_slots = {} } = input;
    const text = user_message.toLowerCase();

    // Intent analysis for planning
    const intent = this.detectIntent(text);

    // Rule-based deterministic planning algorithm
    const steps: PlanStep[] = [];
    let goal = '';
    let reasoning = '';

    if (intent === 'appointment_booking') {
      goal = 'Agendar cita en el negocio respetando disponibilidad y slots';
      
      const hasService = !!(session_slots.service || this.containsAny(text, business.services.map(s => s.name.toLowerCase())));
      const hasDate = !!(session_slots.date || text.includes('hoy') || text.includes('mañana') || text.includes('lunes') || text.includes('sábado') || text.includes('sabado'));
      const hasTime = !!(session_slots.time || text.match(/\d{1,2}(:\d{2})?\s*(am|pm|hrs)?/i));

      steps.push({
        step_number: 1,
        action: 'check_availability',
        description: 'Obtener disponibilidad de horarios libres para la fecha seleccionada',
        tool_to_use: 'check_availability_tool',
        params: { date: session_slots.date || 'Mañana', service: session_slots.service || 'Corte de Cabello Tradicional' },
      });

      if (!hasTime || !hasService) {
        steps.push({
          step_number: 2,
          action: 'ask_missing_info',
          description: `Preguntar detalles faltantes (${!hasService ? 'servicio' : ''} ${!hasTime ? 'hora deseada' : ''})`.trim(),
        });
      }

      steps.push({
        step_number: steps.length + 1,
        action: 'create_booking',
        description: `Crear reserva para ${customer.name || 'Cliente'} en ${business.name}`,
        tool_to_use: 'create_booking_tool',
        params: {
          customer_name: customer.name,
          phone: customer.phone,
          service: session_slots.service || 'Corte de Cabello Tradicional',
          date: session_slots.date || 'Mañana',
          time: session_slots.time || '16:00',
        },
      });

      reasoning = `Cliente desea reservar (${hasDate ? 'con fecha' : 'sin fecha definida'}). Plan creado para verificar disponibilidad, completar slots y confirmar reserva.`;

    } else if (intent === 'service_inquiry') {
      goal = 'Informar catálogo de servicios, precios y recomendaciones personalizadas';

      steps.push({
        step_number: 1,
        action: 'get_services_catalog',
        description: 'Consultar catálogo de servicios y tarifas oficiales del negocio',
        tool_to_use: 'get_services_catalog_tool',
      });

      steps.push({
        step_number: 2,
        action: 'recommend_based_on_memory',
        description: `Recomendar servicios considerando barbero favorito (${customer.favorite_barber || 'No asignado'}) y preferencias (${customer.preferences.join(', ') || 'Sin registro'})`,
      });

      reasoning = 'Consulta sobre precios y cortes. Se consulta catálogo y se formulan recomendaciones basadas en el perfil de memoria del cliente.';

    } else if (intent === 'business_hours_inquiry') {
      goal = 'Proporcionar horarios oficiales de atención de la barbería/peluquería';

      steps.push({
        step_number: 1,
        action: 'get_opening_hours',
        description: 'Consultar horarios de apertura y cierre por día de la semana',
        tool_to_use: 'get_opening_hours_tool',
      });

      steps.push({
        step_number: 2,
        action: 'confirm_schedule',
        description: 'Informar al cliente y ofrecer agendar cita en horarios de atención',
      });

      reasoning = 'Consulta de horarios. Se recuperan días hábiles y se ofrece opción de agendamiento directo.';

    } else if (intent === 'human_handover') {
      goal = 'Transferir la atención del cliente a un recepcionista humano';

      steps.push({
        step_number: 1,
        action: 'escalate_human_handover',
        description: 'Crear ticket de escalación y notificar al equipo humano',
        tool_to_use: 'escalate_human_handover_tool',
      });

      steps.push({
        step_number: 2,
        action: 'notify_transfer',
        description: 'Informar al cliente sobre el número de ticket y tiempo estimado de respuesta',
      });

      reasoning = 'El cliente solicitó atención de una persona real. Se genera escalación inmediata.';

    } else if (intent === 'cancel_booking') {
      goal = 'Cancelar la cita o reserva agendada previamente por el cliente';

      steps.push({
        step_number: 1,
        action: 'cancel_booking',
        description: 'Ejecutar cancelación de reserva en el sistema',
        tool_to_use: 'cancel_booking_tool',
      });

      steps.push({
        step_number: 2,
        action: 'confirm_cancellation',
        description: 'Confirmar cancelación y ofrecer reagendamiento futuro',
      });

      reasoning = 'Solicitud de anulación de cita. Se cancela reserva activa.';

    } else {
      goal = 'Atender consulta general del cliente';

      steps.push({
        step_number: 1,
        action: 'analyze_query',
        description: 'Analizar consulta general con la base de conocimiento y contexto de la barbería',
      });

      steps.push({
        step_number: 2,
        action: 'synthesize_response',
        description: 'Generar respuesta amable considerando historial y preferencias',
      });

      reasoning = 'Consulta sin herramientas requeridas. Procesamiento conversacional estándar.';
    }

    const plan: ExecutionPlan = {
      user_intent: intent,
      plan_goal: goal,
      steps,
      next_step_index: 0,
      reasoning,
      created_at: new Date().toISOString(),
    };

    return plan;
  }

  private detectIntent(text: string): string {
    if (/humano|persona|queja|agente|hablar con alguien|gerente/i.test(text)) return 'human_handover';
    if (/cancelar|anular|eliminar cita/i.test(text)) return 'cancel_booking';
    if (/cita|agendar|reservar|turno|corte para|mañana|a las/i.test(text)) return 'appointment_booking';
    if (/precio|cuánto|costo|vale|servicios|catalogo|corte/i.test(text)) return 'service_inquiry';
    if (/horario|abren|cierran|abierto|hora/i.test(text)) return 'business_hours_inquiry';
    return 'general_inquiry';
  }

  private containsAny(text: string, keywords: string[]): boolean {
    return keywords.some(k => text.includes(k));
  }
}
