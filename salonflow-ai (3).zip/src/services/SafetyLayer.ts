import {
  SafetyConfig,
  SafetyIncidentRecord,
  SafetyValidationInput,
  SafetyValidationResult,
  SafetyViolation,
} from '../types/safety.js';

export const DEFAULT_SAFETY_CONFIG: SafetyConfig = {
  check_unverified_prices: true,
  check_unverified_hours: true,
  check_fake_bookings: true,
  check_fake_promotions: true,
  check_medical_advice: true,
  check_unverified_availability: true,
  fallback_honesty_template:
    'Por transparencia y seguridad, no dispongo de la información oficial confirmada para responder a este detalle. Te canalizaré con nuestro equipo de recepción para darte una respuesta 100% precisa.',
  log_incidents: true,
  custom_forbidden_keywords: [],
};

/**
 * SafetyIncidentStore - Almacén global para registrar e inspeccionar incidentes de seguridad.
 */
export class SafetyIncidentStore {
  private static instance: SafetyIncidentStore;
  private incidents: SafetyIncidentRecord[] = [];

  private constructor() {}

  public static getInstance(): SafetyIncidentStore {
    if (!SafetyIncidentStore.instance) {
      SafetyIncidentStore.instance = new SafetyIncidentStore();
    }
    return SafetyIncidentStore.instance;
  }

  public addIncident(record: SafetyIncidentRecord): void {
    this.incidents.push(record);
  }

  public getIncidents(): SafetyIncidentRecord[] {
    return [...this.incidents];
  }

  public clearIncidents(): void {
    this.incidents = [];
  }
}

/**
 * SafetyLayer - Capa de Seguridad y Verificación previa a la entrega de respuesta al cliente.
 * 
 * Comprueba:
 * 1. No inventar precios (no inventar tarifas no registradas en el catálogo).
 * 2. No inventar horarios (no mentir sobre horarios de atención sin consultar).
 * 3. No inventar reservas (no simular confirmación sin haber ejecutado tool de agendamiento).
 * 4. No inventar promociones (no prometer descuentos o promociones ficticias).
 * 5. No dar consejos médicos (rechazar sugerencias de diagnósticos o tratamientos dermatológicos/médicos).
 * 6. No prometer disponibilidad (no garantizar cupo libre sin previa verificación).
 * 
 * Si falta información o hay violación:
 * - Responde de manera honesta.
 * - Registra el incidente.
 * - Es 100% configurable mediante SafetyConfig.
 */
export class SafetyLayer {
  private config: SafetyConfig;

  constructor(customConfig?: Partial<SafetyConfig>) {
    this.config = {
      ...DEFAULT_SAFETY_CONFIG,
      ...customConfig,
    };
  }

  /**
   * Actualiza la configuración de reglas de seguridad en tiempo de ejecución.
   */
  public setConfig(newConfig: Partial<SafetyConfig>): void {
    this.config = {
      ...this.config,
      ...newConfig,
    };
  }

  /**
   * Obtiene la configuración actual.
   */
  public getConfig(): SafetyConfig {
    return { ...this.config };
  }

  /**
   * Valida la respuesta propuesta antes de enviarla al cliente.
   */
  public validateResponse(input: SafetyValidationInput): SafetyValidationResult {
    const violations: SafetyViolation[] = [];
    const text = input.proposed_response;

    // 1. Check: No dar consejos médicos
    if (this.config.check_medical_advice) {
      const medicalViolation = this.checkMedicalAdvice(text);
      if (medicalViolation) violations.push(medicalViolation);
    }

    // 2. Check: No inventar promociones
    if (this.config.check_fake_promotions) {
      const promoViolation = this.checkFakePromotions(text, input);
      if (promoViolation) violations.push(promoViolation);
    }

    // 3. Check: No inventar reservas
    if (this.config.check_fake_bookings) {
      const bookingViolation = this.checkFakeBookings(text, input);
      if (bookingViolation) violations.push(bookingViolation);
    }

    // 4. Check: No inventar precios
    if (this.config.check_unverified_prices) {
      const priceViolation = this.checkUnverifiedPrices(text, input);
      if (priceViolation) violations.push(priceViolation);
    }

    // 5. Check: No inventar horarios
    if (this.config.check_unverified_hours) {
      const hoursViolation = this.checkUnverifiedHours(text, input);
      if (hoursViolation) violations.push(hoursViolation);
    }

    // 6. Check: No prometer disponibilidad
    if (this.config.check_unverified_availability) {
      const availabilityViolation = this.checkUnverifiedAvailability(text, input);
      if (availabilityViolation) violations.push(availabilityViolation);
    }

    // Check custom keywords if configured
    if (this.config.custom_forbidden_keywords && this.config.custom_forbidden_keywords.length > 0) {
      for (const kw of this.config.custom_forbidden_keywords) {
        if (text.toLowerCase().includes(kw.toLowerCase())) {
          violations.push({
            rule_id: 'custom_forbidden_content',
            severity: 'warning',
            description: `Contenido prohibido detectado por palabra clave personalizada: "${kw}"`,
            detected_snippet: kw,
          });
        }
      }
    }

    const isSafe = violations.length === 0;
    let finalResponse = text;
    let incidentLogged = false;
    let incidentRecord: SafetyIncidentRecord | undefined;

    if (!isSafe) {
      // Generar respuesta honesta indicando falta de información o aclaración requerida
      finalResponse = this.generateHonestFallbackResponse(violations, input);

      if (this.config.log_incidents) {
        incidentRecord = {
          id: `INC-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 1000)}`,
          timestamp: new Date().toISOString(),
          user_message: input.user_message,
          proposed_response: input.proposed_response,
          violations,
          final_response: finalResponse,
          config_snapshot: this.getConfig(),
        };

        SafetyIncidentStore.getInstance().addIncident(incidentRecord);
        incidentLogged = true;
      }
    }

    return {
      is_safe: isSafe,
      original_response: text,
      final_response: finalResponse,
      violations,
      incident_logged: incidentLogged,
      incident_record: incidentRecord,
    };
  }

  /**
   * Detección de consejos médicos o diagnósticos
   */
  private checkMedicalAdvice(text: string): SafetyViolation | null {
    const medicalRegex = /(diagnóstico|dermatitis|alopecia|hongo|infección|antibiótico|prescribo|medicamento|enfermedad del cuero|curar la caspa severa|tratamiento médico)/i;
    const match = text.match(medicalRegex);
    if (match) {
      return {
        rule_id: 'medical_advice',
        severity: 'critical',
        description: 'Se detectó intento de proporcionar un consejo médico o diagnóstico dermatológico.',
        detected_snippet: match[0],
      };
    }
    return null;
  }

  /**
   * Detección de promociones o descuentos ficticios sin respaldar
   */
  private checkFakePromotions(text: string, input: SafetyValidationInput): SafetyViolation | null {
    const promoRegex = /(promoción especial|descuento del \d+%|2x1|gratis con tu corte|cupón de regalo|oferta exclusiva de|te regalam)/i;
    const match = text.match(promoRegex);
    if (match) {
      const specialNotes = input.business?.special_notes || '';
      const toolData = JSON.stringify(input.tool_execution_data || {});
      const isAuthorized = specialNotes.toLowerCase().includes(match[0].toLowerCase()) || toolData.toLowerCase().includes(match[0].toLowerCase());

      if (!isAuthorized) {
        return {
          rule_id: 'fake_promotions',
          severity: 'warning',
          description: 'Se detectó una promoción o descuento que no está autorizado en los datos oficiales del negocio.',
          detected_snippet: match[0],
        };
      }
    }
    return null;
  }

  /**
   * Detección de confirmaciones de reserva falsas (sin tool de booking ejecutado)
   */
  private checkFakeBookings(text: string, input: SafetyValidationInput): SafetyViolation | null {
    const bookingConfirmRegex = /(tu cita ha sido confirmada|reserva creada exitosamente|quedaste agendado para|código de reserva bk-|te hemos agendado oficialmente)/i;
    const match = text.match(bookingConfirmRegex);
    if (match) {
      const toolExecuted = input.executed_tool === 'create_booking_tool';
      const hasBookingData = !!(input.tool_execution_data?.booking || input.tool_execution_data?.id || input.tool_execution_data?.status === 'confirmed');

      if (!toolExecuted || !hasBookingData) {
        return {
          rule_id: 'fake_bookings',
          severity: 'critical',
          description: 'Se afirma haber confirmado una reserva sin haber ejecutado la herramienta de agendamiento correspondiente.',
          detected_snippet: match[0],
        };
      }
    }
    return null;
  }

  /**
   * Detección de precios no verificados ni presentes en el catálogo
   */
  private checkUnverifiedPrices(text: string, input: SafetyValidationInput): SafetyViolation | null {
    // Buscar precios en la respuesta como $150, $ 200, 250 pesos, $300.00
    const priceRegex = /\$\s?(\d{2,5})|(\d{2,5})\s?pesos|(\d{2,5})\s?usd|(\d{2,5})\s?mxn/gi;
    const matches = Array.from(text.matchAll(priceRegex));

    if (matches.length > 0) {
      const knownPrices: number[] = [];
      if (input.business?.services) {
        knownPrices.push(...input.business.services.map(s => s.price));
      }
      if (input.tool_execution_data) {
        const strData = JSON.stringify(input.tool_execution_data);
        const extracted = Array.from(strData.matchAll(/"price":\s?(\d+)/gi)).map(m => parseInt(m[1], 10));
        knownPrices.push(...extracted);
      }

      for (const m of matches) {
        const rawNum = m[1] || m[2] || m[3] || m[4];
        if (rawNum) {
          const num = parseInt(rawNum, 10);
          // Si el número encontrado tiene formato de precio pero no coincide con ningún precio conocido del catálogo
          if (num >= 50 && !knownPrices.includes(num)) {
            return {
              rule_id: 'unverified_prices',
              severity: 'warning',
              description: `Se mencionó un precio ($${num}) que no coincide con ninguna tarifa oficial del catálogo registrado.`,
              detected_snippet: m[0],
            };
          }
        }
      }
    }
    return null;
  }

  /**
   * Detección de horarios inventados que contradicen o no figuran en los registros
   */
  private checkUnverifiedHours(text: string, input: SafetyValidationInput): SafetyViolation | null {
    const hoursClaimRegex = /(abrimos a las \d{1,2}|cerramos a las \d{1,2}|atendemos los domingos|abierto las 24 horas|horario de \d{1,2} a \d{1,2})/i;
    const match = text.match(hoursClaimRegex);
    if (match) {
      const hasHoursData = !!(input.business?.opening_hours && input.business.opening_hours.length > 0) || input.executed_tool === 'get_opening_hours_tool';
      if (!hasHoursData) {
        return {
          rule_id: 'unverified_hours',
          severity: 'warning',
          description: 'Se mencionaron horarios específicos de atención sin contar con datos confirmados del establecimiento.',
          detected_snippet: match[0],
        };
      }
    }
    return null;
  }

  /**
   * Detección de promesas de disponibilidad sin verificar
   */
  private checkUnverifiedAvailability(text: string, input: SafetyValidationInput): SafetyViolation | null {
    const availabilityRegex = /(está 100% disponible|te garantizo el lugar|disponibilidad total asegurada|seguro tenemos lugar libre|te prometo que habrá espacio)/i;
    const match = text.match(availabilityRegex);
    if (match) {
      const checkedAvailability = input.executed_tool === 'check_availability_tool' || !!input.tool_execution_data?.available_slots;
      if (!checkedAvailability) {
        return {
          rule_id: 'unverified_availability',
          severity: 'warning',
          description: 'Se prometió disponibilidad total garantizada sin haber ejecutado la verificación previa de horarios.',
          detected_snippet: match[0],
        };
      }
    }
    return null;
  }

  /**
   * Generación de respuesta honesta en caso de detección de incidentes/violaciones
   */
  private generateHonestFallbackResponse(
    violations: SafetyViolation[],
    input: SafetyValidationInput
  ): string {
    const primaryRule = violations[0]?.rule_id;

    if (primaryRule === 'medical_advice') {
      return 'Para el cuidado o tratamiento de afecciones médicas del cuero cabelludo, te sugerimos consultar con un profesional médico especialista. En la barbería estaremos encantados de ofrecerte nuestros servicios de corte y perfilado.';
    }

    if (primaryRule === 'fake_bookings') {
      return 'Disculpa la confusión. Para confirmar tu cita de manera segura, primero necesito recopilar los datos exactos del servicio, fecha y hora antes de registrar la reserva oficialmente.';
    }

    if (primaryRule === 'unverified_prices' || primaryRule === 'unverified_hours' || primaryRule === 'fake_promotions') {
      return `Para brindarte la información más precisa y honesta sobre nuestros precios, promociones u horarios, te sugiero consultar nuestro catálogo actualizado o te comunicaré directamente con nuestro equipo de atención.`;
    }

    if (primaryRule === 'unverified_availability') {
      return 'Déjame verificar primero nuestro calendario de citas para confirmarte exactamente qué horarios libres tenemos disponibles y asegurarte un turno sin contratiempos.';
    }

    return this.config.fallback_honesty_template || 'No dispongo de la información verificada necesaria para responder a este punto con total certeza. Te atenderemos personalmente para resolver tu duda.';
  }
}
