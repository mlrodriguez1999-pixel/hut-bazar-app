import { GoogleGenAI } from '@google/genai';
import {
  BookingPayload,
  BusinessInfo,
  ConversationMessage,
  CustomerInfo,
  GeminiReceptionServiceInput,
  GeminiReceptionServiceResponse,
} from '../types/receptionist';
import { buildSystemInstruction } from '../prompts/receptionPrompt';

export class GeminiReceptionService {
  private defaultModel = 'gemini-3.6-flash';
  private client: GoogleGenAI | null = null;

  constructor(apiKey?: string, modelName?: string) {
    const key = apiKey || process.env.GEMINI_API_KEY;
    if (key) {
      this.client = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
    if (modelName) {
      this.defaultModel = modelName;
    }
  }

  /**
   * Método principal de procesamiento conversacional del Recepcionista IA.
   * Recibe: business, customer, conversation_history, user_message
   */
  async processMessage(input: GeminiReceptionServiceInput): Promise<GeminiReceptionServiceResponse> {
    const startTime = Date.now();
    const { business, customer, conversation_history, user_message } = input;

    // 1. Construir System Instruction dinámicamente sin datos fijos
    const systemInstruction = buildSystemInstruction(business, customer);

    // Si no hay cliente Gemini inicializado o sin API key, usar fallback inteligente
    if (!this.client) {
      const fallback = this.generateFallbackResponse(input);
      return {
        ...fallback,
        responseTimeMs: Date.now() - startTime,
        promptSent: systemInstruction,
        contextUsed: { business, customer },
        tokensUsed: {
          promptTokens: Math.round(systemInstruction.length / 4),
          candidatesTokens: Math.round(fallback.reply.length / 4),
          totalTokens: Math.round((systemInstruction.length + fallback.reply.length) / 4),
        },
      };
    }

    try {
      // 2. Formatear el historial conversacional para el SDK @google/genai
      const contents = (conversation_history || []).map((msg) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }],
      }));

      // Agregar mensaje actual del usuario
      contents.push({
        role: 'user',
        parts: [{ text: user_message }],
      });

      const modelsToTry = Array.from(new Set([this.defaultModel, 'gemini-3.6-flash', 'gemini-2.5-flash', 'gemini-2.0-flash']));
      let response: any = null;

      for (const mName of modelsToTry) {
        try {
          const res = await this.client.models.generateContent({
            model: mName,
            contents,
            config: {
              systemInstruction,
              temperature: 0.3,
            },
          });
          if (res.text?.trim()) {
            response = res;
            break;
          }
        } catch (mErr) {
          // probar siguiente modelo
        }
      }

      if (!response) {
        throw new Error('Sin disponibilidad de cuota en modelos Gemini');
      }

      const endTime = Date.now();
      const rawText = response.text || '';

      // 4. Extraer payload de booking JSON si Gemini incluyó la confirmación
      const bookingPayload = this.extractBookingJson(rawText);

      // Limpiar texto de respuesta para el usuario
      const cleanReply = this.cleanReplyText(rawText);

      // Metadatos de tokens si existen en la respuesta SDK
      const usage = response.usageMetadata;
      const promptTokens = usage?.promptTokenCount || Math.round((systemInstruction.length + user_message.length) / 4);
      const candidatesTokens = usage?.candidatesTokenCount || Math.round(rawText.length / 4);
      const totalTokens = usage?.totalTokenCount || (promptTokens + candidatesTokens);

      return {
        reply: cleanReply,
        booking: bookingPayload,
        raw_response: rawText,
        responseTimeMs: endTime - startTime,
        promptSent: systemInstruction,
        tokensUsed: {
          promptTokens,
          candidatesTokens,
          totalTokens,
        },
        contextUsed: { business, customer },
      };
    } catch (error: any) {
      const errMsg = error?.message || String(error);
      const isQuota = errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED');
      console.warn(`[Gemini Reception] API ${isQuota ? 'cuota agotada (429)' : 'no disponible'}. Activando respuesta fallback.`);
      const fallback = this.generateFallbackResponse(input, error?.message);
      return {
        ...fallback,
        responseTimeMs: Date.now() - startTime,
        promptSent: systemInstruction,
        contextUsed: { business, customer },
        tokensUsed: {
          promptTokens: Math.round(systemInstruction.length / 4),
          candidatesTokens: Math.round(fallback.reply.length / 4),
          totalTokens: Math.round((systemInstruction.length + fallback.reply.length) / 4),
        },
      };
    }
  }

  /**
   * Extrae y valida la estructura de JSON `create_booking` de la respuesta de Gemini
   */
  public extractBookingJson(text: string): BookingPayload | null {
    if (!text) return null;

    try {
      // Regex para buscar bloques ```json ... ``` o {...} con action: "create_booking"
      const jsonMatch = text.match(/```(?:json)?\s*({[\s\S]*?"action"\s*:\s*"create_booking"[\s\S]*?})\s*```/i) ||
                        text.match(/({[\s\S]*?"action"\s*:\s*"create_booking"[\s\S]*?})/i);

      if (jsonMatch && jsonMatch[1]) {
        const parsed = JSON.parse(jsonMatch[1]);
        if (
          parsed.action === 'create_booking' &&
          parsed.customer_name &&
          parsed.phone &&
          parsed.service &&
          parsed.date &&
          parsed.time
        ) {
          return {
            action: 'create_booking',
            customer_name: String(parsed.customer_name).trim(),
            phone: String(parsed.phone).trim(),
            service: String(parsed.service).trim(),
            date: String(parsed.date).trim(),
            time: String(parsed.time).trim(),
          };
        }
      }
    } catch (e) {
      console.warn('No se pudo parsear el JSON de booking de la respuesta:', e);
    }

    return null;
  }

  /**
   * Remueve los bloques de código ```json de la respuesta final que lee el cliente
   */
  private cleanReplyText(text: string): string {
    return text.replace(/```(?:json)?\s*{[\s\S]*?"action"\s*:\s*"create_booking"[\s\S]*?}\s*```/gi, '').trim();
  }

  /**
   * Respuesta simulada de respaldo cuando Gemini API Key no está configurada o hay error
   */
  private generateFallbackResponse(input: GeminiReceptionServiceInput, errorMessage?: string): GeminiReceptionServiceResponse {
    const { business, user_message, customer } = input;
    const msgLower = user_message.toLowerCase();

    // 1. Consulta de precios
    if (msgLower.includes('precio') || msgLower.includes('costo') || msgLower.includes('cuanto cuesta') || msgLower.includes('cuánto')) {
      const servicesList = business.services
        .map((s) => `• ${s.name}: $${s.price} (${s.duration_minutes || 30} min)`)
        .join('\n');
      return {
        reply: `¡Hola! Con gusto te comparto la lista oficial de precios de ${business.name}:\n\n${servicesList}\n\n¿Deseas agendar alguna cita?`,
        booking: null,
      };
    }

    // 2. Consulta de horarios
    if (msgLower.includes('horario') || msgLower.includes('abren') || msgLower.includes('cierran') || msgLower.includes('hora')) {
      const hoursList = business.opening_hours
        .map((h) => `• ${h.day}: ${h.is_closed ? 'Cerrado' : `${h.open} - ${h.close}`}`)
        .join('\n');
      return {
        reply: `Nuestros horarios de atención en ${business.name} son los siguientes:\n\n${hoursList}\n\n¿En qué fecha u hora te gustaría agendar?`,
        booking: null,
      };
    }

    // 3. Detección heurística de reserva completa para pruebas
    const isBooking = msgLower.includes('agendar') || msgLower.includes('cita') || msgLower.includes('reservar');
    if (isBooking) {
      const name = customer.name || 'Javier Guerra';
      const phone = customer.phone || '+525512345678';
      const service = business.services[0]?.name || 'Corte de Cabello';
      
      return {
        reply: `¡Con gusto! He procesado tu solicitud de cita para ${service} en ${business.name}. Quedará agendada.`,
        booking: {
          action: 'create_booking',
          customer_name: name,
          phone: phone,
          service: service,
          date: 'Mañana',
          time: '16:00',
        },
      };
    }

    return {
      reply: `¡Hola! Bienvenido a ${business.name}. Soy la recepcionista virtual. ¿En qué puedo ayudarte hoy? Puedes consultar precios, horarios o agendar una cita.`,
      booking: null,
    };
  }
}
