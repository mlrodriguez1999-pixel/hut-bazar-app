import {
  CustomerMemoryProfile,
  CustomerMemoryUpdate,
  RecentBooking,
  RecentService,
} from '../types/customerMemory.js';

/**
 * CustomerMemory - Almacena y gestiona el perfil CRM inteligente del cliente.
 * 
 * Diseñado específicamente para alimentar el contexto de Gemini con un resumen
 * hiper-optimizado en tokens, evitando transmitir historiales de conversación
 * completos redundantes.
 */
export class CustomerMemory {
  private profile: CustomerMemoryProfile;

  constructor(initialData?: Partial<CustomerMemoryProfile>) {
    const now = new Date().toISOString();
    this.profile = {
      name: initialData?.name || 'Cliente No Registrado',
      phone: initialData?.phone || 'Sin Teléfono',
      recent_services: initialData?.recent_services || [],
      recent_bookings: initialData?.recent_bookings || [],
      preferences: initialData?.preferences || [],
      favorite_barber: initialData?.favorite_barber || 'No especificado',
      observations: initialData?.observations || [],
      visit_count: initialData?.visit_count ?? 0,
      last_interaction: initialData?.last_interaction || now,
    };
  }

  /**
   * Obtiene la copia inmutable del perfil completo.
   */
  public getProfile(): CustomerMemoryProfile {
    return { ...this.profile };
  }

  /**
   * Actualiza datos generales del cliente.
   */
  public updateProfile(updates: CustomerMemoryUpdate): void {
    if (updates.name !== undefined) this.profile.name = updates.name;
    if (updates.phone !== undefined) this.profile.phone = updates.phone;
    if (updates.favorite_barber !== undefined) this.profile.favorite_barber = updates.favorite_barber;
    if (updates.visit_count !== undefined) this.profile.visit_count = updates.visit_count;
    if (updates.last_interaction !== undefined) this.profile.last_interaction = updates.last_interaction;

    if (updates.preferences) {
      this.profile.preferences = Array.from(new Set([...this.profile.preferences, ...updates.preferences]));
    }
    if (updates.observations) {
      this.profile.observations = Array.from(new Set([...this.profile.observations, ...updates.observations]));
    }

    this.profile.last_interaction = new Date().toISOString();
  }

  /**
   * Agrega una preferencia única del cliente.
   */
  public addPreference(preference: string): void {
    const trimmed = preference.trim();
    if (trimmed && !this.profile.preferences.includes(trimmed)) {
      this.profile.preferences.push(trimmed);
      this.profile.last_interaction = new Date().toISOString();
    }
  }

  /**
   * Agrega una observación única del cliente (ej: alergias, notas especiales).
   */
  public addObservation(observation: string): void {
    const trimmed = observation.trim();
    if (trimmed && !this.profile.observations.includes(trimmed)) {
      this.profile.observations.push(trimmed);
      this.profile.last_interaction = new Date().toISOString();
    }
  }

  /**
   * Registra un servicio completado y actualiza la cantidad de visitas e interacción.
   */
  public recordService(serviceName: string, barber?: string, price?: number): void {
    const now = new Date().toISOString().split('T')[0];
    const newService: RecentService = {
      name: serviceName,
      date: now,
      barber: barber || this.profile.favorite_barber,
      price,
    };

    // Guardar solo los últimos 5 servicios para mantener memoria ligera
    this.profile.recent_services = [newService, ...this.profile.recent_services].slice(0, 5);
    this.profile.visit_count += 1;
    if (barber && this.profile.favorite_barber === 'No especificado') {
      this.profile.favorite_barber = barber;
    }
    this.profile.last_interaction = new Date().toISOString();
  }

  /**
   * Registra una nueva reserva (agendada o confirmada).
   */
  public recordBooking(booking: Omit<RecentBooking, 'id'> & { id?: string }): void {
    const newBooking: RecentBooking = {
      id: booking.id || `BK-${Date.now().toString().slice(-6)}`,
      service: booking.service,
      date: booking.date,
      time: booking.time,
      barber: booking.barber || this.profile.favorite_barber,
      status: booking.status || 'confirmed',
      created_at: new Date().toISOString(),
    };

    // Guardar solo las últimas 5 reservas
    this.profile.recent_bookings = [newBooking, ...this.profile.recent_bookings].slice(0, 5);
    this.profile.last_interaction = new Date().toISOString();
  }

  /**
   * Establece o cambia el barbero favorito del cliente.
   */
  public setFavoriteBarber(barberName: string): void {
    this.profile.favorite_barber = barberName.trim();
    this.profile.last_interaction = new Date().toISOString();
  }

  /**
   * Devuelve un resumen ultracompacto y conciso en texto plano para inyectar a Gemini.
   * Optimizado para consumo mínimo de tokens (evita conversaciones completas).
   */
  public getShortSummary(): string {
    const p = this.profile;
    
    // Formatear servicios recientes (máximo los últimos 3 en texto plano breve)
    const recentServicesStr = p.recent_services.length > 0
      ? p.recent_services.slice(0, 3).map(s => `${s.name}${s.barber ? ` (${s.barber})` : ''}`).join(', ')
      : 'Ninguno registrado';

    // Formatear reservas recientes (última reserva más relevante)
    const recentBookingsStr = p.recent_bookings.length > 0
      ? p.recent_bookings.slice(0, 2).map(b => `${b.service} el ${b.date} a las ${b.time} [${b.status}]`).join('; ')
      : 'Sin reservas previas';

    const prefsStr = p.preferences.length > 0 ? p.preferences.join(', ') : 'Ninguna';
    const obsStr = p.observations.length > 0 ? p.observations.join(', ') : 'Ninguna';

    // Formato ultra-conciso de bajo token count (~40-60 tokens total)
    return `[CONTEXTO CLIENTE CRM - MEMORIA OPTIMIZADA POR TOKENS]
- Cliente: ${p.name} | Tel: ${p.phone} | Visitas: ${p.visit_count} | Barbero Fav: ${p.favorite_barber}
- Preferencias: ${prefsStr}
- Observaciones: ${obsStr}
- Últimos Servicios: ${recentServicesStr}
- Últimas Reservas: ${recentBookingsStr}
- Última Interacción: ${p.last_interaction.split('T')[0]}`;
  }
}

/**
 * CustomerMemoryStore - Almacenamiento singleton global de perfiles CustomerMemory
 */
export class CustomerMemoryStore {
  private static instance: CustomerMemoryStore;
  private memories: Map<string, CustomerMemory> = new Map();

  private constructor() {
    // Inicializar cliente demo predeterminado para pruebas
    const demoProfile = new CustomerMemory({
      name: 'Javier Guerra',
      phone: '+52 55 1234 5678',
      favorite_barber: 'Carlos Martínez',
      visit_count: 4,
      preferences: ['Prefiere café sin azúcar', 'Corte degradado con tijera arriba', 'Puntualidad estricta'],
      observations: ['Piel sensible a navaja seca', 'Alergia suave a mentol'],
      recent_services: [
        { name: 'Corte de Cabello Tradicional', date: '2026-07-20', barber: 'Carlos Martínez', price: 250 },
        { name: 'Perfilado de Barba Ritual', date: '2026-07-05', barber: 'Carlos Martínez', price: 150 },
      ],
      recent_bookings: [
        { id: 'BK-882194', service: 'Corte de Cabello Tradicional', date: '2026-07-20', time: '16:00', status: 'completed' }
      ],
    });
    this.memories.set('+52 55 1234 5678', demoProfile);
    this.memories.set('default', demoProfile);
  }

  public static getInstance(): CustomerMemoryStore {
    if (!CustomerMemoryStore.instance) {
      CustomerMemoryStore.instance = new CustomerMemoryStore();
    }
    return CustomerMemoryStore.instance;
  }

  public getOrCreate(phoneOrId: string, initialData?: Partial<CustomerMemoryProfile>): CustomerMemory {
    const key = phoneOrId || 'default';
    if (!this.memories.has(key)) {
      const newMemory = new CustomerMemory({
        phone: phoneOrId,
        ...initialData,
      });
      this.memories.set(key, newMemory);
    }
    return this.memories.get(key)!;
  }

  public get(phoneOrId: string): CustomerMemory | undefined {
    return this.memories.get(phoneOrId) || this.memories.get('default');
  }

  public set(phoneOrId: string, memory: CustomerMemory): void {
    this.memories.set(phoneOrId, memory);
  }

  public clear(): void {
    this.memories.clear();
  }
}
