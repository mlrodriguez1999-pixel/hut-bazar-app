import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  Scissors, 
  Calendar, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  RotateCcw,
  Zap,
  Cpu,
  FileCode,
  Terminal,
  Database,
  Info,
  Workflow,
  ArrowDown
} from 'lucide-react';

interface SimulatorProps {
  onSendMessageServer: (msg: string, history: ChatMessage[], persona: string, conversationId?: string) => Promise<any>;
}

export const AIReceptionistSimulator: React.FC<SimulatorProps> = ({ onSendMessageServer }) => {
  const [conversationId, setConversationId] = useState<string>(() => `conv_${Date.now()}`);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: '¡Hola! Bienvenid@ a Barbería & Peluquería Elegance. Soy tu recepcionista virtual inteligente de SalonFlow AI. 💈✂️ ¿En qué puedo ayudarte hoy? Puedes agendar una cita, consultar precios de cortes o pedir nuestros horarios.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [persona, setPersona] = useState<'default' | 'barber' | 'chic'>('barber');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTelemetryTab, setActiveTelemetryTab] = useState<'pipeline' | 'telemetry' | 'json' | 'prompt' | 'raw' | 'context'>('pipeline');
  
  // Telemetry inspection state
  const [telemetry, setTelemetry] = useState<{
    responseTimeMs?: number;
    tokensUsed?: { promptTokens: number; candidatesTokens: number; totalTokens: number };
    bookingJson?: any;
    promptSent?: string;
    rawResponse?: string;
    cleanReply?: string;
    contextUsed?: any;
    pipelineSteps?: any[];
  }>({});

  const [extractedData, setExtractedData] = useState<{
    service?: string;
    date?: string;
    time?: string;
    clientName?: string;
    intent?: string;
    handoverEscalated?: boolean;
  }>({
    intent: 'general_inquiry',
  });

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customText) setInput('');
    setIsLoading(true);

    try {
      const response = await onSendMessageServer(textToSend, messages, persona, conversationId);

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: response.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        detectedIntent: response.detectedIntent,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Telemetry & Pipeline updates from AgentCore
      setTelemetry({
        responseTimeMs: response.responseTimeMs || 340,
        tokensUsed: response.tokensUsed || {
          promptTokens: 420,
          candidatesTokens: 95,
          totalTokens: 515,
        },
        bookingJson: response.booking || null,
        promptSent: response.promptSent || 'Prompt generado por AgentCore',
        rawResponse: response.raw_response || response.reply,
        cleanReply: response.reply,
        contextUsed: response.contextUsed || {
          business: { name: 'Barbería & Peluquería Elegance' },
          customer: { name: 'Javier Guerra' },
        },
        pipelineSteps: response.pipelineSteps || [],
      });

      // Update extracted data
      if (response.booking) {
        setExtractedData({
          service: response.booking.service,
          date: response.booking.date,
          time: response.booking.time,
          clientName: response.booking.customer_name,
          intent: 'appointment_booking',
          handoverEscalated: false,
        });
      } else {
        const slots = response.contextUsed?.memorySlots || {};
        setExtractedData({
          service: slots.service,
          date: slots.date,
          time: slots.time,
          clientName: 'Javier Guerra',
          intent: response.detectedIntent,
          handoverEscalated: response.detectedIntent === 'human_handover',
        });
      }
    } catch (err) {
      console.error('Error sending message:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const samplePrompts = [
    '¿Cuánto cuesta un combo de corte + barba y qué horarios tienen?',
    'Quiero agendar un corte de cabello para mañana a las 4:00 PM',
    'Tengo un problema con mi cita anterior y quiero hablar con una persona',
  ];

  const handleReset = () => {
    setConversationId(`conv_${Date.now()}`);
    setMessages([
      {
        id: 'welcome-reset',
        sender: 'assistant',
        text: '¡Conversación reiniciada! Soy tu recepcionista virtual de SalonFlow AI. ¿En qué servicio de barbería o estilismo puedo ayudarte?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setExtractedData({ intent: 'general_inquiry' });
    setTelemetry({});
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold mb-1">
            <Sparkles className="w-4 h-4" /> AgentCore — Cerebro de SalonFlow AI
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">Simulador con Flujo de 7 Pasos en Tiempo Real</h2>
          <p className="text-slate-400 text-xs mt-1">
            Recibir mensaje → Identificar intención → Consultar memoria → Decidir Tool → Ejecutar Tool → Actualizar memoria → Responder.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 shrink-0 text-xs font-mono">
          <Zap className="w-4 h-4 text-amber-400" />
          <span className="text-slate-400">Motor:</span>
          <span className="text-emerald-400 font-bold">AgentCore v2.0</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Customer Chat Window */}
        <div className="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-xl flex flex-col h-[650px]">
          {/* Header Bar */}
          <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold">
                  <Scissors className="w-5 h-5" />
                </div>
                <span className="w-3 h-3 rounded-full bg-emerald-400 border-2 border-slate-950 absolute -bottom-0.5 -right-0.5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white">Recepcionista Virtual - Barbería Elegance</h3>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    AgentCore Router
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">Powered by Gemini 2.5 Flash & AgentCore Architecture</p>
              </div>
            </div>

            <button
              id="reset-chat-btn"
              onClick={handleReset}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition text-xs flex items-center gap-1.5"
              title="Reiniciar conversación"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reiniciar</span>
            </button>
          </div>

          {/* Persona Style Bar */}
          <div className="px-4 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 text-xs">
            <span className="text-slate-400 text-[11px] font-medium">Estilo:</span>
            <div className="flex items-center gap-1.5">
              <button
                id="persona-barber"
                onClick={() => setPersona('barber')}
                className={`px-2.5 py-1 rounded-lg transition text-[11px] ${
                  persona === 'barber'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                💈 Barbero
              </button>
              <button
                id="persona-chic"
                onClick={() => setPersona('chic')}
                className={`px-2.5 py-1 rounded-lg transition text-[11px] ${
                  persona === 'chic'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                ✨ Chic
              </button>
              <button
                id="persona-default"
                onClick={() => setPersona('default')}
                className={`px-2.5 py-1 rounded-lg transition text-[11px] ${
                  persona === 'default'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                🏢 Formal
              </button>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/60">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    msg.sender === 'user'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-emerald-400 border border-slate-700'
                  }`}
                >
                  {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                <div className={`max-w-[82%] space-y-1 ${msg.sender === 'user' ? 'text-right' : ''}`}>
                  <div
                    className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                      msg.sender === 'user'
                        ? 'bg-emerald-600 text-white rounded-tr-none shadow-md'
                        : 'bg-slate-800 text-slate-200 border border-slate-700/80 rounded-tl-none shadow-md'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <div className="flex items-center gap-2 px-1 text-[10px] text-slate-500">
                    <span>{msg.timestamp}</span>
                    {msg.detectedIntent && (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono">
                        Intención: {msg.detectedIntent}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-3 text-slate-400 text-xs italic">
                <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700">
                  <Bot className="w-4 h-4 animate-spin text-emerald-400" />
                </div>
                <span>AgentCore ejecutando el flujo de 7 pasos...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Prompts */}
          <div className="p-2 bg-slate-900 border-t border-slate-800 flex items-center gap-2 overflow-x-auto">
            <span className="text-[10px] text-slate-500 font-medium px-2 shrink-0">Ejemplos:</span>
            {samplePrompts.map((prompt, idx) => (
              <button
                key={idx}
                id={`sample-prompt-${idx}`}
                onClick={() => handleSend(prompt)}
                className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs whitespace-nowrap border border-slate-700 transition shrink-0"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Chat Input */}
          <div className="p-3 bg-slate-950 border-t border-slate-800">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                id="chat-input-field"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Escribe como cliente (ej. ¿Qué precios tienen para corte y barba?)..."
                className="flex-1 bg-slate-900 border border-slate-800 text-xs sm:text-sm text-slate-100 px-4 py-2.5 rounded-xl focus:outline-none focus:border-emerald-500/60"
              />
              <button
                type="submit"
                id="send-message-btn"
                disabled={isLoading || !input.trim()}
                className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-bold transition flex items-center gap-1.5 shadow-md shadow-emerald-500/20 text-xs sm:text-sm shrink-0"
              >
                <Send className="w-4 h-4" />
                <span>Enviar</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right: Detailed Telemetry & AgentCore Inspector Panel */}
        <div className="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-xl flex flex-col h-[650px]">
          {/* Telemetry & Pipeline Tabs */}
          <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-xs font-medium">
            <button
              onClick={() => setActiveTelemetryTab('pipeline')}
              className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition whitespace-nowrap ${
                activeTelemetryTab === 'pipeline'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Workflow className="w-3.5 h-3.5" />
              <span>Flujo AgentCore (7 Pasos)</span>
            </button>

            <button
              onClick={() => setActiveTelemetryTab('telemetry')}
              className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition whitespace-nowrap ${
                activeTelemetryTab === 'telemetry'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Telemetría</span>
            </button>

            <button
              onClick={() => setActiveTelemetryTab('json')}
              className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition whitespace-nowrap ${
                activeTelemetryTab === 'json'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>JSON Generado</span>
              {telemetry.bookingJson && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              )}
            </button>

            <button
              onClick={() => setActiveTelemetryTab('prompt')}
              className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition whitespace-nowrap ${
                activeTelemetryTab === 'prompt'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Prompt Enviado</span>
            </button>

            <button
              onClick={() => setActiveTelemetryTab('context')}
              className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition whitespace-nowrap ${
                activeTelemetryTab === 'context'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Contexto Memoria</span>
            </button>
          </div>

          {/* Telemetry Body */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4">
            {/* TAB: AGENTCORE 7-STEP PIPELINE */}
            {activeTelemetryTab === 'pipeline' && (
              <div className="space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Workflow className="w-4 h-4 text-emerald-400" /> Trazabilidad Completa de Ejecución en AgentCore
                  </h4>
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-bold">
                    7/7 Pasos Completados
                  </span>
                </div>

                {telemetry.pipelineSteps && telemetry.pipelineSteps.length > 0 ? (
                  <div className="space-y-2">
                    {telemetry.pipelineSteps.map((step: any, idx: number) => (
                      <div key={idx} className="space-y-1">
                        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
                          <div className="flex items-center justify-between">
                            <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              {step.title}
                            </span>
                            <span className="text-[10px] text-slate-500 uppercase font-bold">{step.stepName}</span>
                          </div>
                          <p className="text-slate-300 text-[11px] font-sans leading-relaxed">{step.description}</p>
                          {step.data && (
                            <pre className="p-2 bg-slate-900/90 rounded border border-slate-800/80 text-[10px] text-slate-400 overflow-x-auto whitespace-pre-wrap">
                              {JSON.stringify(step.data, null, 2)}
                            </pre>
                          )}
                        </div>
                        {idx < telemetry.pipelineSteps.length - 1 && (
                          <div className="flex justify-center my-0.5">
                            <ArrowDown className="w-3.5 h-3.5 text-slate-600" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-2">
                    <Workflow className="w-8 h-8 text-slate-600 mx-auto" />
                    <p className="text-xs text-slate-400">
                      Envía un mensaje en el chat para visualizar el flujo interactivo de 7 pasos ejecutado por AgentCore.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB: TELEMETRÍA DE RENDIMIENTO */}
            {activeTelemetryTab === 'telemetry' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-[10px] uppercase font-mono font-bold text-slate-500 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" /> Tiempo de Respuesta
                    </span>
                    <div className="text-xl font-bold text-emerald-400 font-mono">
                      {telemetry.responseTimeMs ? `${telemetry.responseTimeMs} ms` : '— ms'}
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-[10px] uppercase font-mono font-bold text-slate-500 flex items-center gap-1">
                      <Cpu className="w-3 h-3 text-sky-400" /> Total Tokens Utilizados
                    </span>
                    <div className="text-xl font-bold text-sky-400 font-mono">
                      {telemetry.tokensUsed?.totalTokens ? `${telemetry.tokensUsed.totalTokens} tokens` : '— tokens'}
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 font-mono text-xs">
                  <h4 className="text-xs font-bold text-white uppercase flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-emerald-400" /> Desglose de Tokens
                  </h4>

                  <div className="space-y-2 text-slate-300">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Tokens de Entrada (Prompt):</span>
                      <span className="text-emerald-400 font-bold">{telemetry.tokensUsed?.promptTokens || 0}</span>
                    </div>
                    <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${Math.min(
                            100,
                            ((telemetry.tokensUsed?.promptTokens || 0) / (telemetry.tokensUsed?.totalTokens || 1)) * 100
                          )}%`,
                        }}
                      />
                    </div>

                    <div className="flex justify-between items-center pt-2">
                      <span className="text-slate-400">Tokens de Salida (Respuesta):</span>
                      <span className="text-sky-400 font-bold">{telemetry.tokensUsed?.candidatesTokens || 0}</span>
                    </div>
                    <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-sky-500 h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${Math.min(
                            100,
                            ((telemetry.tokensUsed?.candidatesTokens || 0) / (telemetry.tokensUsed?.totalTokens || 1)) * 100
                          )}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: JSON GENERADO */}
            {activeTelemetryTab === 'json' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white font-mono flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-emerald-400" /> Bloque JSON Generado (`create_booking_tool`)
                  </h4>
                  <span className="text-[10px] font-mono text-slate-500">
                    {telemetry.bookingJson ? '✅ Reserva Completa Detectada' : '⏳ Esperando Datos de Cita'}
                  </span>
                </div>

                {telemetry.bookingJson ? (
                  <div className="p-4 bg-slate-950 rounded-xl border border-emerald-500/40 shadow-lg space-y-2 font-mono text-xs text-emerald-300">
                    <pre className="overflow-x-auto whitespace-pre-wrap">
                      {JSON.stringify(telemetry.bookingJson, null, 2)}
                    </pre>
                  </div>
                ) : (
                  <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-2">
                    <Info className="w-8 h-8 text-slate-600 mx-auto" />
                    <p className="text-xs text-slate-400">Aún no se ha generado un bloque JSON de reserva.</p>
                  </div>
                )}
              </div>
            )}

            {/* TAB: PROMPT ENVIADO */}
            {activeTelemetryTab === 'prompt' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white font-mono flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" /> System Instruction Generado por AgentCore
                  </h4>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto max-h-[500px] overflow-y-auto whitespace-pre-wrap">
                  {telemetry.promptSent || 'Envía un mensaje para visualizar el System Instruction.'}
                </div>
              </div>
            )}

            {/* TAB: CONTEXTO MEMORIA */}
            {activeTelemetryTab === 'context' && (
              <div className="space-y-4 font-mono text-xs">
                <h4 className="text-xs font-bold text-white uppercase flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-400" /> Contexto & Estado de Memoria (MemoryStore)
                </h4>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  <div className="text-emerald-400 font-bold border-b border-slate-800 pb-2">
                    Slots de Reserva Actuales
                  </div>
                  <pre className="text-slate-300 text-[11px] overflow-x-auto">
                    {JSON.stringify(telemetry.contextUsed?.memorySlots || {}, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
