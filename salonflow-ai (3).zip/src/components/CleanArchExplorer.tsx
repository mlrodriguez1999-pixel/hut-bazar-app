import React, { useState } from 'react';
import { architectureFiles } from '../data/architectureFiles';
import { ArchitectureFile, LayerCategory } from '../types';
import { 
  Folder, 
  FileCode, 
  Copy, 
  Check, 
  Search, 
  Download, 
  Layers, 
  Server, 
  Monitor, 
  Database, 
  Workflow, 
  Container, 
  FileText 
} from 'lucide-react';

export const CleanArchExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<ArchitectureFile>(architectureFiles[0]);
  const [activeCategory, setActiveCategory] = useState<LayerCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);

  const categories: { id: LayerCategory | 'all'; label: string; icon: React.ReactNode; color: string }[] = [
    { id: 'all', label: 'Todos los Archivos', icon: <Layers className="w-4 h-4" />, color: 'text-slate-400' },
    { id: 'backend', label: 'FastAPI Backend', icon: <Server className="w-4 h-4" />, color: 'text-sky-400' },
    { id: 'frontend', label: 'Next.js 15 Frontend', icon: <Monitor className="w-4 h-4" />, color: 'text-emerald-400' },
    { id: 'database', label: 'Supabase SQL', icon: <Database className="w-4 h-4" />, color: 'text-amber-400' },
    { id: 'n8n', label: 'Workflows n8n', icon: <Workflow className="w-4 h-4" />, color: 'text-rose-400' },
    { id: 'devops', label: 'Docker & CI/CD', icon: <Container className="w-4 h-4" />, color: 'text-purple-400' },
    { id: 'docs', label: 'Documentación', icon: <FileText className="w-4 h-4" />, color: 'text-cyan-400' },
  ];

  const filteredFiles = architectureFiles.filter((file) => {
    const matchesCategory = activeCategory === 'all' || file.category === activeCategory;
    const matchesSearch = file.path.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          file.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopyContent = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold mb-1">
              <Layers className="w-4 h-4" /> Clean Architecture & Scalable Blueprint
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">Estructura del Proyecto SalonFlow AI</h2>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Base sólida y modular dividida en Dominios, Casos de Uso, Adaptadores (FastAPI), Server Components (Next.js 15), Esquema Supabase (RLS), Workflows n8n y Pipeline CI/CD.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="download-selected-file"
              onClick={handleDownloadFile}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-slate-700 transition"
            >
              <Download className="w-4 h-4 text-emerald-400" /> Descargar {selectedFile.filename}
            </button>
          </div>
        </div>
      </div>

      {/* Layer Category Filters */}
      <div className="flex flex-wrap items-center gap-2 pb-2">
        {categories.map((cat) => (
          <button
            key={cat.id}
            id={`filter-cat-${cat.id}`}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
              activeCategory === cat.id
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-semibold shadow-sm'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <span className={cat.color}>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Main Grid: File Tree Sidebar & Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* File List Tree */}
        <div className="lg:col-span-4 bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-lg flex flex-col h-[650px]">
          {/* Search Box */}
          <div className="p-3 border-b border-slate-800 bg-slate-950/50">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Buscar archivo o capa..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-xs text-slate-200 pl-9 pr-3 py-2 rounded-lg focus:outline-none focus:border-emerald-500/50"
              />
            </div>
          </div>

          {/* List of Files */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1 divide-y divide-slate-800/30">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.id === file.id;
              return (
                <button
                  key={file.id}
                  id={`file-item-${file.id}`}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl transition flex items-start gap-3 ${
                    isSelected
                      ? 'bg-emerald-500/10 border border-emerald-500/30 text-white'
                      : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <FileCode className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className={`text-xs font-mono font-semibold truncate ${isSelected ? 'text-emerald-300' : 'text-slate-200'}`}>
                        {file.filename}
                      </span>
                      <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                        {file.category}
                      </span>
                    </div>
                    <p className="text-[11px] font-mono text-slate-500 truncate mt-0.5">{file.path}</p>
                    <p className="text-[11px] text-slate-400 line-clamp-1 mt-1 font-sans">{file.description}</p>
                  </div>
                </button>
              );
            })}

            {filteredFiles.length === 0 && (
              <div className="p-8 text-center text-slate-500 text-xs">
                No se encontraron archivos para el filtro especificado.
              </div>
            )}
          </div>
        </div>

        {/* Code View Panel */}
        <div className="lg:col-span-8 bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-lg h-[650px] flex flex-col">
          {/* Code Header */}
          <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <Folder className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-mono text-xs font-semibold text-slate-200 truncate">{selectedFile.path}</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{selectedFile.description}</p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                id="copy-code-btn"
                onClick={handleCopyContent}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>{copied ? '¡Copiado!' : 'Copiar Código'}</span>
              </button>
            </div>
          </div>

          {/* Code Editor Frame */}
          <div className="flex-1 overflow-auto bg-slate-950/90 p-4 font-mono text-xs text-slate-300 leading-relaxed">
            <pre className="whitespace-pre font-mono">
              <code>
                {selectedFile.content.split('\n').map((line, idx) => (
                  <div key={idx} className="table-row">
                    <span className="table-cell pr-4 text-right select-none text-slate-600 text-[11px] w-10">
                      {idx + 1}
                    </span>
                    <span className="table-cell">{line || ' '}</span>
                  </div>
                ))}
              </code>
            </pre>
          </div>

          {/* Footer Info Bar */}
          <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between font-mono">
            <span>Lenguaje: {selectedFile.language.toUpperCase()}</span>
            <span>Líneas: {selectedFile.content.split('\n').length}</span>
            <span>Capa: {selectedFile.category}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
