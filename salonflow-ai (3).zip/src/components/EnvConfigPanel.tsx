import React from 'react';
import { Settings, CheckCircle2, ShieldCheck, Key, Server, Database, Container } from 'lucide-react';

export const EnvConfigPanel: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold mb-1">
              <Settings className="w-4 h-4" /> Configuración Rápida & Secrets Panel
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">Variables de Entorno & Credenciales Production-Ready</h2>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Configuración modular lista para desplegar en Docker, Cloud Run o Vercel/Supabase.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Environment File Explorer */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Key className="w-4 h-4 text-emerald-400" /> Plantilla `.env.example`
            </h3>
            <span className="text-[10px] font-mono text-slate-500">Root Directory</span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-slate-300 space-y-2 overflow-x-auto">
            <div><span className="text-slate-500"># Google AI Studio Gemini API Key</span></div>
            <div><span className="text-emerald-400">GEMINI_API_KEY</span>=<span className="text-slate-400">"your-gemini-api-key"</span></div>
            <div className="pt-2"><span className="text-slate-500"># Supabase PostgreSQL Database</span></div>
            <div><span className="text-emerald-400">NEXT_PUBLIC_SUPABASE_URL</span>=<span className="text-slate-400">"https://xxx.supabase.co"</span></div>
            <div><span className="text-emerald-400">NEXT_PUBLIC_SUPABASE_ANON_KEY</span>=<span className="text-slate-400">"eyJhb..."</span></div>
            <div><span className="text-emerald-400">SUPABASE_SERVICE_ROLE_KEY</span>=<span className="text-slate-400">"eyJhb..."</span></div>
            <div><span className="text-emerald-400">DATABASE_URL</span>=<span className="text-slate-400">"postgresql://postgres:pass@db.xxx:5432/postgres"</span></div>
            <div className="pt-2"><span className="text-slate-500"># FastAPI Backend</span></div>
            <div><span className="text-emerald-400">FASTAPI_SECRET_KEY</span>=<span className="text-slate-400">"super-secret-key"</span></div>
            <div className="pt-2"><span className="text-slate-500"># n8n & WhatsApp</span></div>
            <div><span className="text-emerald-400">N8N_WEBHOOK_SECRET</span>=<span className="text-slate-400">"n8n-secret"</span></div>
            <div><span className="text-emerald-400">WHATSAPP_API_TOKEN</span>=<span className="text-slate-400">"EAA..."</span></div>
          </div>
        </div>

        {/* Readiness Checklist */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Checklist de Arquitectura para Producción
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-3">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Clean Architecture Backend (FastAPI)</span>
                Separación estricta de Entidades de Dominio, Casos de Uso e Inyección de Dependencias.
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-3">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Esquema Supabase con RLS</span>
                Tablas `salones`, `estilistas`, `servicios` y `citas` protegidas con políticas de seguridad.
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-3">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Despliegue Multi-Contenedor (Docker)</span>
                Configuración lista con `docker-compose.yml` para levantar Next.js, FastAPI y n8n en 1 comando.
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-3">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Integración Server-Side de Gemini 3.6 Flash</span>
                Llamadas a la API resguardadas en el servidor Express/FastAPI para proteger la API Key.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
