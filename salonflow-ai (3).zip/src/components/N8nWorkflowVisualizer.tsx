import React from 'react';
import { Workflow, ArrowRight, Server, Database, MessageSquare, AlertTriangle, CheckCircle2, Bot } from 'lucide-react';

export const N8nWorkflowVisualizer: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Visualizer Header */}
      <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-400 text-xs font-semibold mb-1">
              <Workflow className="w-4 h-4" /> n8n Automation Engine Pipeline
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">Flujo de Trabajo WhatsApp & Gemini AI</h2>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Diagrama interactivo del pipeline de n8n para conectar la API de WhatsApp Business con el Backend FastAPI, Gemini 3.6 Flash y Supabase PostgreSQL.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-mono font-bold">
              n8n /whatsapp-incoming
            </span>
          </div>
        </div>
      </div>

      {/* Workflow Diagram Grid */}
      <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 shadow-2xl relative overflow-x-auto">
        <div className="min-w-[800px] flex items-center justify-between gap-4 relative">
          {/* Node 1: WhatsApp Webhook */}
          <div className="w-56 bg-slate-900 p-4 rounded-2xl border-2 border-emerald-500/50 shadow-lg relative group">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-3">
              <MessageSquare className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-mono uppercase text-emerald-400 font-bold block">1. Trigger</span>
            <h4 className="text-sm font-bold text-white mt-0.5">WhatsApp Webhook</h4>
            <p className="text-[11px] text-slate-400 mt-1">Recibe mensaje entrante del cliente en tiempo real.</p>
            <div className="mt-3 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-500">
              POST /webhook/whatsapp
            </div>
          </div>

          <ArrowRight className="w-6 h-6 text-slate-600 shrink-0" />

          {/* Node 2: FastAPI Gemini Engine */}
          <div className="w-56 bg-slate-900 p-4 rounded-2xl border-2 border-sky-500/50 shadow-lg relative group">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold mb-3">
              <Bot className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-mono uppercase text-sky-400 font-bold block">2. AI Logic</span>
            <h4 className="text-sm font-bold text-white mt-0.5">FastAPI + Gemini</h4>
            <p className="text-[11px] text-slate-400 mt-1">Extrae intención, servicio, fecha y determina respuesta.</p>
            <div className="mt-3 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-500">
              POST /api/v1/chat
            </div>
          </div>

          <ArrowRight className="w-6 h-6 text-slate-600 shrink-0" />

          {/* Node 3: Supabase Database */}
          <div className="w-56 bg-slate-900 p-4 rounded-2xl border-2 border-amber-500/50 shadow-lg relative group">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold mb-3">
              <Database className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block">3. Data Layer</span>
            <h4 className="text-sm font-bold text-white mt-0.5">Supabase PostgreSQL</h4>
            <p className="text-[11px] text-slate-400 mt-1">Verifica choque de agenda y crea el registro de cita.</p>
            <div className="mt-3 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-500">
              INSERT INTO appointments
            </div>
          </div>

          <ArrowRight className="w-6 h-6 text-slate-600 shrink-0" />

          {/* Node 4: WhatsApp Outgoing Dispatcher */}
          <div className="w-56 bg-slate-900 p-4 rounded-2xl border-2 border-purple-500/50 shadow-lg relative group">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold mb-3">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-mono uppercase text-purple-400 font-bold block">4. Action</span>
            <h4 className="text-sm font-bold text-white mt-0.5">Respuesta WhatsApp</h4>
            <p className="text-[11px] text-slate-400 mt-1">Envía la confirmación formal al teléfono del cliente.</p>
            <div className="mt-3 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-500">
              Graph API v18.0
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
