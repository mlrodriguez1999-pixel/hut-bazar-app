import React, { useState } from 'react';
import { Appointment, Service, Stylist } from '../types';
import { 
  CalendarCheck, 
  Users, 
  DollarSign, 
  Bot, 
  Plus, 
  Check, 
  Clock, 
  Scissors, 
  Phone, 
  Search,
  Filter,
  Sparkles,
  Calendar as CalendarIcon,
  BellRing,
  ShieldCheck,
  UserCheck,
  Building,
  RefreshCw,
  Sliders
} from 'lucide-react';

export const SalonDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'calendar' | 'services' | 'team'>('overview');
  
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: 'apt-1',
      clientName: 'Javier Guerra',
      clientPhone: '+34 612 345 678',
      serviceName: 'Combo VIP Corte + Barba',
      stylistName: 'Carlos Barbero',
      date: 'Hoy, 05 de Agosto',
      time: '04:00 PM',
      status: 'confirmada',
      source: 'WhatsApp AI',
    },
    {
      id: 'apt-2',
      clientName: 'Mateo Fernández',
      clientPhone: '+34 698 765 432',
      serviceName: 'Corte de Cabello Tradicional',
      stylistName: 'Elena Stylist',
      date: 'Hoy, 05 de Agosto',
      time: '05:30 PM',
      status: 'confirmada',
      source: 'WhatsApp AI',
    },
    {
      id: 'apt-3',
      clientName: 'Roberto Alarcón',
      clientPhone: '+34 644 443 333',
      serviceName: 'Tinte & Matiz Capilar',
      stylistName: 'Elena Stylist',
      date: 'Mañana, 06 de Agosto',
      time: '11:00 AM',
      status: 'pendiente',
      source: 'WhatsApp AI',
    },
    {
      id: 'apt-4',
      clientName: 'Sofía Martínez',
      clientPhone: '+34 677 778 888',
      serviceName: 'Peinado & Estilismo Boutique',
      stylistName: 'Marco Barber',
      date: 'Mañana, 06 de Agosto',
      time: '01:00 PM',
      status: 'completada',
      source: 'Web',
    },
  ]);

  const [stylists, setStylists] = useState<Stylist[]>([
    { id: 'st-1', name: 'Carlos Barbero', role: 'Master Barber', specialty: 'Degradados & Barba', avatarUrl: '', isAvailable: true },
    { id: 'st-2', name: 'Elena Stylist', role: 'Colorista Senior', specialty: 'Tintes & Tratamientos', avatarUrl: '', isAvailable: true },
    { id: 'st-3', name: 'Marco Barber', role: 'Barbero Urbano', specialty: 'Diseños & Navaja', avatarUrl: '', isAvailable: false },
  ]);

  const [services, setServices] = useState<Service[]>([
    { id: 'srv-1', name: 'Corte de Cabello Tradicional', category: 'corte', durationMinutes: 30, price: 20, description: 'Corte a tijera o máquina con lavado rápido' },
    { id: 'srv-2', name: 'Arreglo de Barba', category: 'barba', durationMinutes: 20, price: 15, description: 'Perfilado con toalla caliente y bálsamo' },
    { id: 'srv-3', name: 'Combo VIP Corte + Barba', category: 'corte', durationMinutes: 50, price: 30, description: 'Servicio completo con bebida de bienvenida' },
    { id: 'srv-4', name: 'Tinte & Matiz Capilar', category: 'tinte', durationMinutes: 60, price: 45, description: 'Coloración profesional e hidratación' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [isRunningReminders, setIsRunningReminders] = useState(false);
  const [reminderMessage, setReminderMessage] = useState<string | null>(null);

  const triggerRemindersAndNoShows = async () => {
    setIsRunningReminders(true);
    setReminderMessage(null);
    try {
      const res = await fetch('/api/reminders/run', { method: 'POST' });
      const data = await res.json();
      setReminderMessage(`✅ Proceso finalizado: ${data.noShowsMarked} no-shows marcados, ${data.remindersDispatched} recordatorios 24h enviados.`);
    } catch (err) {
      setReminderMessage('⚠️ Error ejecutando la tarea en segundo plano.');
    } finally {
      setIsRunningReminders(false);
    }
  };

  const filteredAppointments = appointments.filter((apt) =>
    apt.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    apt.serviceName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Multi-Tenancy & Subscriptions Banner */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
            <Building className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white">Peluquería Flow AI</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Tenant: biz_salon_flow_01
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
              <UserCheck className="w-3.5 h-3.5 text-slate-500" />
              Autenticado como <strong className="text-slate-200">Javier Guerra (Dueño)</strong> • Rol: Owner (RLS Activo)
            </p>
          </div>
        </div>

        <button
          onClick={triggerRemindersAndNoShows}
          disabled={isRunningReminders}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition shadow-sm disabled:opacity-50"
        >
          <BellRing className={`w-4 h-4 text-emerald-400 ${isRunningReminders ? 'animate-spin' : ''}`} />
          {isRunningReminders ? 'Procesando Recordatorios...' : 'Ejecutar Recordatorios & No-Shows'}
        </button>
      </div>

      {reminderMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded-xl text-xs font-medium animate-fadeIn">
          {reminderMessage}
        </div>
      )}

      {/* Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'overview'
              ? 'bg-emerald-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <CalendarCheck className="w-4 h-4" /> Visión General
        </button>
        <button
          onClick={() => setActiveTab('calendar')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'calendar'
              ? 'bg-emerald-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <CalendarIcon className="w-4 h-4" /> Agenda & Calendario Día
        </button>
        <button
          onClick={() => setActiveTab('services')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'services'
              ? 'bg-emerald-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <Scissors className="w-4 h-4" /> Servicios & Catálogo
        </button>
        <button
          onClick={() => setActiveTab('team')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'team'
              ? 'bg-emerald-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <Users className="w-4 h-4" /> Equipo & Jornadas
        </button>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Citas Agendadas este Mes</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white font-mono">148</span>
            <span className="text-xs text-emerald-400 ml-2 font-medium">+18% vs mes anterior</span>
          </div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Resolución Autónoma IA</span>
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-400">
              <Bot className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white font-mono">94.2%</span>
            <span className="text-xs text-teal-400 ml-2 font-medium">Sin intervención humana</span>
          </div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Ingresos Estimados por IA</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <span className="font-bold text-sm">€</span>
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white font-mono">4.290 €</span>
            <span className="text-xs text-amber-400 ml-2 font-medium">EUR este mes</span>
          </div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Estilistas / Barberos</span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white font-mono">3 / 3</span>
            <span className="text-xs text-purple-400 ml-2 font-medium">Jornadas Materializadas</span>
          </div>
        </div>
      </div>

      {/* TAB CONTENT 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Appointments Table */}
          <div className="lg:col-span-8 bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-xl flex flex-col">
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <CalendarCheck className="w-4 h-4 text-emerald-400" /> Próximas Citas Agendadas por la IA
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">Sincronizado en tiempo real con Supabase PostgreSQL</p>
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Buscar por cliente o servicio..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-slate-900 border border-slate-800 text-xs text-slate-200 pl-8 pr-3 py-1.5 rounded-lg focus:outline-none focus:border-emerald-500/50"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/60 text-slate-400 uppercase font-mono text-[10px] tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Cliente</th>
                    <th className="px-4 py-3">Servicio</th>
                    <th className="px-4 py-3">Estilista</th>
                    <th className="px-4 py-3">Fecha & Hora</th>
                    <th className="px-4 py-3">Origen</th>
                    <th className="px-4 py-3 text-right">Estado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredAppointments.map((apt) => (
                    <tr key={apt.id} className="hover:bg-slate-800/40 transition">
                      <td className="px-4 py-3">
                        <div className="font-semibold text-white">{apt.clientName}</div>
                        <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                          <Phone className="w-3 h-3" /> {apt.clientPhone}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-200">{apt.serviceName}</td>
                      <td className="px-4 py-3 text-slate-400">{apt.stylistName}</td>
                      <td className="px-4 py-3 font-mono">
                        <div className="text-slate-200">{apt.date}</div>
                        <div className="text-emerald-400 font-bold">{apt.time}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          <Sparkles className="w-3 h-3" /> {apt.source}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                            apt.status === 'confirmada'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : apt.status === 'pendiente'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {apt.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Barbers & Stylist Team Roster */}
          <div className="lg:col-span-4 bg-slate-900/90 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" /> Equipo de Barberos & Estilistas
            </h3>

            <div className="space-y-3">
              {stylists.map((st) => (
                <div key={st.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-sm">
                      {st.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">{st.name}</div>
                      <div className="text-[11px] text-slate-400">{st.role} • {st.specialty}</div>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      st.isAvailable ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {st.isAvailable ? 'Disponible' : 'En Cita'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: CALENDAR VIEW */}
      {activeTab === 'calendar' && (
        <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <CalendarIcon className="w-5 h-5 text-emerald-400" /> Vista de Agenda por Profesional (Rejilla de 15 Min)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Garantiza la Invariante #1: Asignación exclusiva con bloqueo de asesoría PostgreSQL.
              </p>
            </div>
            <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
              <span className="text-xs text-emerald-400 font-mono font-bold px-3">05 de Agosto, 2026</span>
            </div>
          </div>

          {/* Time Slots Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stylists.map((st) => (
              <div key={st.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-xs font-bold text-white">{st.name}</span>
                  <span className="text-[10px] font-mono text-slate-400">Jornada: 09:00 - 19:00</span>
                </div>

                <div className="space-y-2">
                  <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-lg flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-emerald-300">Javier Guerra</div>
                      <div className="text-[10px] text-slate-400">Combo VIP Corte + Barba</div>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-400">16:00 - 16:50</span>
                  </div>

                  <div className="p-2 bg-slate-900/60 border border-slate-800/60 rounded-lg text-center text-[11px] text-slate-500">
                    17:00 - 17:15 (Hueco Libre 15m)
                  </div>

                  <div className="p-2.5 bg-teal-500/10 border border-teal-500/30 rounded-lg flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-teal-300">Mateo Fernández</div>
                      <div className="text-[10px] text-slate-400">Corte Tradicional</div>
                    </div>
                    <span className="text-xs font-mono font-bold text-teal-400">17:30 - 18:00</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: SERVICES */}
      {activeTab === 'services' && (
        <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Scissors className="w-5 h-5 text-emerald-400" /> Catálogo de Servicios & Precios
              </h3>
              <p className="text-xs text-slate-400 mt-1">Servicios consultados en tiempo real por el asistente de IA</p>
            </div>
            <button className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs hover:bg-emerald-400 transition">
              <Plus className="w-4 h-4" /> Nuevo Servicio
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {services.map((srv) => (
              <div key={srv.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-start justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white">{srv.name}</h4>
                  <p className="text-[11px] text-slate-400 mt-1">{srv.description}</p>
                  <div className="mt-3 flex items-center gap-3">
                    <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {srv.durationMinutes} min
                    </span>
                    <span className="text-xs font-mono text-amber-400 font-bold flex items-center gap-1">
                      {srv.price} €
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: TEAM & SCHEDULES */}
      {activeTab === 'team' && (
        <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-400" /> Jornadas e Inteligencia por Profesional
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Configuración individual de pausas de almuerzo, horarios semanales y ausencias.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {stylists.map((st) => (
              <div key={st.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-base">
                    {st.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{st.name}</h4>
                    <p className="text-xs text-slate-400">{st.role} • Especialidad: {st.specialty}</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-300">
                  <span className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg">
                    Lun-Vie: 09:00 - 19:00 (Pausa: 14:00-15:00)
                  </span>
                  <span className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg">
                    Sáb: 10:00 - 16:00
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
