import { AgentIntent, ToolName, MemorySlotState } from '../../types/agent';

/**
 * Interface del Resultado de Decisión generado por el Motor de IA
 */
export interface DecisionResult {
  intent: AgentIntent;
  /** Nivel de confianza entre 0.0 y 1.0 */
  confidence: number;
  slots: {
    service?: string;
    date?: string;
    time?: string;
    customer_name?: string;
    customer_phone?: string;
  };
  tool: ToolName;
  reasoning: string;
  nextQuestion?: string;
}

/**
 * Contrato del Servicio de aplicación GeminiDecisionEngine
 */
export interface IGeminiDecisionEngine {
  decide(userMessage: string, currentSlots?: MemorySlotState): Promise<DecisionResult>;
}
