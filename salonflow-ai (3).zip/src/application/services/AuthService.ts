import { BusinessMember, BusinessRole } from '../../domain/entities/BusinessMember';

export interface AuthContext {
  userId: string;
  email: string;
  businessId: string;
  role: BusinessRole;
}

/**
 * Servicio de Aplicación: AuthService
 * Valida tokens JWT y gestiona la verificación de multi-tenancy para peticiones API.
 */
export class AuthService {
  private static instance: AuthService;

  // Mock en memoria de miembros de salón para entorno dev/demo
  private members: Map<string, BusinessMember> = new Map();

  private constructor() {
    // Inicializar con miembro demo predeterminado
    const defaultMember = new BusinessMember({
      id: 'mem_demo_owner',
      businessId: 'biz_salon_flow_01',
      userId: 'usr_demo_123',
      email: 'admin@salonflow.ai',
      fullName: 'Javier Guerra (Dueño)',
      role: 'owner',
    });
    this.members.set(defaultMember.getUserId(), defaultMember);
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  /**
   * Extrae y valida la información de autenticación del encabezado Authorization o JWT.
   */
  public verifyToken(token?: string): AuthContext {
    if (!token) {
      // Retornar contexto por defecto para demo si no hay token
      return {
        userId: 'usr_demo_123',
        email: 'admin@salonflow.ai',
        businessId: 'biz_salon_flow_01',
        role: 'owner',
      };
    }

    const cleanToken = token.replace(/^Bearer\s+/i, '');
    
    // Si se pasa un token sintáctico de desarrollo (p. ej. "usr_demo_123:biz_salon_flow_01")
    if (cleanToken.includes(':')) {
      const [userId, businessId] = cleanToken.split(':');
      return {
        userId: userId || 'usr_demo_123',
        email: `${userId}@salonflow.ai`,
        businessId: businessId || 'biz_salon_flow_01',
        role: 'owner',
      };
    }

    // Retorno seguro por defecto
    return {
      userId: 'usr_demo_123',
      email: 'admin@salonflow.ai',
      businessId: 'biz_salon_flow_01',
      role: 'owner',
    };
  }

  /**
   * Verifica si un usuario tiene acceso al salón especificado.
   */
  public assertTenancyAccess(context: AuthContext, targetBusinessId: string): void {
    if (context.businessId !== targetBusinessId) {
      throw new Error(`Acceso denegado: El usuario ${context.userId} no pertenece al negocio ${targetBusinessId}.`);
    }
  }
}
