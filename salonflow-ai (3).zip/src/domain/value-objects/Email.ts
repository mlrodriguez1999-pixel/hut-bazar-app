/**
 * Objeto de Valor: Email
 * Representa una dirección de correo electrónico válida.
 */
export class Email {
  private readonly value: string;

  constructor(email: string) {
    if (!email || !this.isValid(email)) {
      throw new Error(`Email inválido: ${email}`);
    }
    this.value = email.trim().toLowerCase();
  }

  public getValue(): string {
    return this.value;
  }

  public equals(other: Email): boolean {
    return this.value === other.value;
  }

  private isValid(email: string): boolean {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email.trim());
  }
}
