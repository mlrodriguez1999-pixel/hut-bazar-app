/**
 * Objeto de Valor: PhoneNumber
 * Representa un número de teléfono validado.
 */
export class PhoneNumber {
  private readonly value: string;

  constructor(phone: string) {
    const cleaned = phone ? phone.replace(/[\s\-\(\)]/g, '') : '';
    if (!cleaned || cleaned.length < 7) {
      throw new Error(`Número de teléfono inválido: ${phone}`);
    }
    this.value = cleaned;
  }

  public getValue(): string {
    return this.value;
  }

  public equals(other: PhoneNumber): boolean {
    return this.value === other.value;
  }
}
