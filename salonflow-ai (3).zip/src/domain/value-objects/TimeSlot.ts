/**
 * Objeto de Valor: TimeSlot
 * Representa un intervalo de tiempo inmutable con inicio y fin.
 */
export class TimeSlot {
  private readonly start: Date;
  private readonly end: Date;

  constructor(start: Date, end: Date) {
    if (!(start instanceof Date) || isNaN(start.getTime())) {
      throw new Error('Fecha de inicio inválida.');
    }
    if (!(end instanceof Date) || isNaN(end.getTime())) {
      throw new Error('Fecha de fin inválida.');
    }
    if (end <= start) {
      throw new Error('La fecha de fin debe ser posterior a la fecha de inicio.');
    }
    this.start = new Date(start.getTime());
    this.end = new Date(end.getTime());
  }

  public getStart(): Date {
    return new Date(this.start.getTime());
  }

  public getEnd(): Date {
    return new Date(this.end.getTime());
  }

  public getDurationMinutes(): number {
    return Math.round((this.end.getTime() - this.start.getTime()) / (1000 * 60));
  }

  public overlaps(other: TimeSlot): boolean {
    return this.start < other.end && this.end > other.start;
  }

  public includes(date: Date): boolean {
    return date >= this.start && date <= this.end;
  }

  public equals(other: TimeSlot): boolean {
    return (
      this.start.getTime() === other.start.getTime() &&
      this.end.getTime() === other.end.getTime()
    );
  }
}
