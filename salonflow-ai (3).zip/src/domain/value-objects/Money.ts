/**
 * Objeto de Valor: Money
 * Representa un monto monetario inmutable con moneda.
 */
export class Money {
  private readonly amount: number;
  private readonly currency: string;

  constructor(amount: number, currency: string = 'EUR') {
    if (amount < 0) {
      throw new Error('El monto no puede ser negativo.');
    }
    if (!currency || currency.trim() === '') {
      throw new Error('La moneda debe ser especificada.');
    }
    this.amount = Math.round(amount * 100) / 100;
    this.currency = currency.toUpperCase();
  }

  public getAmount(): number {
    return this.amount;
  }

  public getCurrency(): string {
    return this.currency;
  }

  public add(other: Money): Money {
    this.ensureSameCurrency(other);
    return new Money(this.amount + other.amount, this.currency);
  }

  public subtract(other: Money): Money {
    this.ensureSameCurrency(other);
    const newAmount = this.amount - other.amount;
    if (newAmount < 0) {
      throw new Error('El resultado de la resta no puede ser negativo.');
    }
    return new Money(newAmount, this.currency);
  }

  public applyDiscountPercentage(percentage: number): Money {
    if (percentage < 0 || percentage > 100) {
      throw new Error('El porcentaje de descuento debe estar entre 0 y 100.');
    }
    const discountAmount = this.amount * (percentage / 100);
    return new Money(this.amount - discountAmount, this.currency);
  }

  public equals(other: Money): boolean {
    return this.amount === other.amount && this.currency === other.currency;
  }

  public format(): string {
    return `${this.amount.toFixed(2)} ${this.currency}`;
  }

  private ensureSameCurrency(other: Money): void {
    if (this.currency !== other.currency) {
      throw new Error(`Monedas incompatibles: ${this.currency} vs ${other.currency}`);
    }
  }
}
