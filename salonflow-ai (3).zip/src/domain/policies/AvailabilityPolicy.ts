import { Employee } from '../entities/Employee';
import { Appointment, AppointmentStatus } from '../entities/Appointment';
import { TimeSlot } from '../value-objects/TimeSlot';

export interface AvailabilityPolicyOptions {
  slotGridMinutes?: number; // 15 minutos por defecto
  minimumNoticeMinutes?: number; // 30 minutos de preaviso mínimo por defecto
  bufferMinutesBetweenAppointments?: number; // Margen entre citas (p. ej. 5 min)
}

/**
 * Política de Dominio: AvailabilityPolicy
 * Garantiza la invariante fundamental:
 * "LA AGENDA DE UN PROFESIONAL NUNCA TIENE DOS CITAS VIVAS SOLAPADAS".
 * Aplica rejilla de 15 min, preaviso mínimo y jornadas individuales por profesional.
 */
export class AvailabilityPolicy {
  private slotGridMinutes: number;
  private minimumNoticeMinutes: number;
  private bufferMinutes: number;

  constructor(options: AvailabilityPolicyOptions = {}) {
    this.slotGridMinutes = options.slotGridMinutes ?? 15;
    this.minimumNoticeMinutes = options.minimumNoticeMinutes ?? 30;
    this.bufferMinutes = options.bufferMinutesBetweenAppointments ?? 0;
  }

  /**
   * Calcula los huecos verdaderamente disponibles para un servicio y un profesional en una fecha concreta.
   */
  public getAvailableSlots(params: {
    targetDate: Date;
    serviceDurationMinutes: number;
    employee: Employee;
    existingAppointments: Appointment[];
    now?: Date;
  }): TimeSlot[] {
    const { targetDate, serviceDurationMinutes, employee, existingAppointments, now = new Date() } = params;

    if (!employee.isActive()) return [];

    // 1. Obtener la rejilla de slots según la jornada real del profesional
    const baseSlots = employee.workingHoursToSlots(targetDate, this.slotGridMinutes);
    if (baseSlots.length === 0) return [];

    // 2. Filtrar slots por preaviso mínimo (no reservar en el pasado o dentro de los próximos N minutos)
    const minNoticeTime = new Date(now.getTime() + this.minimumNoticeMinutes * 60 * 1000);

    // 3. Filtrar solo citas vivas (agendadas o confirmadas)
    const activeAppointments = existingAppointments.filter(
      app => app.getEmployeeId() === employee.getId() && (app.getStatus() === AppointmentStatus.PENDING || app.getStatus() === AppointmentStatus.CONFIRMED)
    );

    const availableSlots: TimeSlot[] = [];

    for (let i = 0; i < baseSlots.length; i++) {
      const startSlot = baseSlots[i];

      // Verificar preaviso
      if (startSlot.getStart() < minNoticeTime) continue;

      // Calcular el final potencial para la duración completa del servicio
      const potentialEnd = new Date(startSlot.getStart().getTime() + serviceDurationMinutes * 60 * 1000);
      const potentialSlot = new TimeSlot(startSlot.getStart(), potentialEnd);

      // Verificar si el bloque completo encaja en las horas de trabajo del empleado
      const candidateSlotWithBuffer = new TimeSlot(
        potentialSlot.getStart(),
        new Date(potentialSlot.getEnd().getTime() + this.bufferMinutes * 60 * 1000)
      );

      // Verificar solapamiento con cualquier cita activa
      const hasConflict = activeAppointments.some(app => {
        const appSlot = app.getTimeSlot();
        return candidateSlotWithBuffer.overlaps(appSlot);
      });

      if (!hasConflict) {
        availableSlots.push(potentialSlot);
      }
    }

    return availableSlots;
  }
}
