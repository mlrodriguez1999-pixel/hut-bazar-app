/**
 * Entidad de Dominio: BusinessMember
 * Asocia usuarios autenticados de Supabase Auth con un negocio específico y define sus roles.
 */
export type BusinessRole = 'owner' | 'manager' | 'receptionist' | 'staff';

export class BusinessMember {
  private id: string;
  private businessId: string;
  private userId: string; // ID del usuario en Supabase Auth
  private email: string;
  private fullName: string;
  private role: BusinessRole;
  private createdAt: Date;

  constructor(params: {
    id: string;
    businessId: string;
    userId: string;
    email: string;
    fullName: string;
    role: BusinessRole;
    createdAt?: Date;
  }) {
    if (!params.id) throw new Error('El ID de membresía es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');
    if (!params.userId) throw new Error('El ID de usuario es requerido.');

    this.id = params.id;
    this.businessId = params.businessId;
    this.userId = params.userId;
    this.email = params.email;
    this.fullName = params.fullName;
    this.role = params.role;
    this.createdAt = params.createdAt || new Date();
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getUserId(): string { return this.userId; }
  public getEmail(): string { return this.email; }
  public getFullName(): string { return this.fullName; }
  public getRole(): BusinessRole { return this.role; }
  public getCreatedAt(): Date { return new Date(this.createdAt.getTime()); }

  public isOwnerOrManager(): boolean {
    return this.role === 'owner' || this.role === 'manager';
  }
}
