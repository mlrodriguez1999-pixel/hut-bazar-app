export interface DomainMessage {
  id: string;
  sender: 'customer' | 'assistant' | 'agent';
  content: string;
  timestamp: Date;
  metadata?: Record<string, unknown>;
}

/**
 * Entidad de Dominio: Conversation
 * Representa la conversación y el historial de mensajes de atención con el cliente.
 */
export class Conversation {
  private id: string;
  private businessId: string;
  private customerId: string;
  private channel: 'whatsapp' | 'web' | 'phone';
  private status: 'active' | 'archived';
  private messages: DomainMessage[];
  private lastInteractionAt: Date;

  constructor(params: {
    id: string;
    businessId: string;
    customerId: string;
    channel?: 'whatsapp' | 'web' | 'phone';
    status?: 'active' | 'archived';
    messages?: DomainMessage[];
    lastInteractionAt?: Date;
  }) {
    if (!params.id) throw new Error('El ID de la conversación es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');
    if (!params.customerId) throw new Error('El ID del cliente es requerido.');

    this.id = params.id;
    this.businessId = params.businessId;
    this.customerId = params.customerId;
    this.channel = params.channel || 'whatsapp';
    this.status = params.status || 'active';
    this.messages = params.messages ? [...params.messages] : [];
    this.lastInteractionAt = params.lastInteractionAt || new Date();
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getCustomerId(): string { return this.customerId; }
  public getChannel(): string { return this.channel; }
  public getStatus(): string { return this.status; }
  public getMessages(): DomainMessage[] { return [...this.messages]; }
  public getLastInteractionAt(): Date { return new Date(this.lastInteractionAt.getTime()); }

  public addMessage(sender: 'customer' | 'assistant' | 'agent', content: string, metadata?: Record<string, unknown>): DomainMessage {
    if (!content || !content.trim()) {
      throw new Error('El contenido del mensaje no puede estar vacío.');
    }
    const message: DomainMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      sender,
      content: content.trim(),
      timestamp: new Date(),
      metadata,
    };
    this.messages.push(message);
    this.lastInteractionAt = message.timestamp;
    return message;
  }

  public archive(): void {
    this.status = 'archived';
  }

  public reactivate(): void {
    this.status = 'active';
  }
}
