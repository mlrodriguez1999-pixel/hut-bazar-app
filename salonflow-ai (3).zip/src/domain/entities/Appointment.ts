import { Money } from '../value-objects/Money';
import { TimeSlot } from '../value-objects/TimeSlot';

export enum AppointmentStatus {
  PENDING = 'PENDING',
  CONFIRMED = 'CONFIRMED',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED',
  NO_SHOW = 'NO_SHOW',
}

/**
 * Entidad de Dominio: Appointment (Cita)
 * Agregado principal que modela la reserva de un servicio.
 */
export class Appointment {
  private id: string;
  private businessId: string;
  private customerId: string;
  private employeeId: string;
  private serviceId: string;
  private timeSlot: TimeSlot;
  private status: AppointmentStatus;
  private totalPrice: Money;
  private notes: string;
  private cancellationReason?: string;
  private createdAt: Date;
  private updatedAt: Date;

  constructor(params: {
    id: string;
    businessId: string;
    customerId: string;
    employeeId: string;
    serviceId: string;
    timeSlot: TimeSlot;
    totalPrice: Money;
    status?: AppointmentStatus;
    notes?: string;
    cancellationReason?: string;
    createdAt?: Date;
    updatedAt?: Date;
  }) {
    if (!params.id) throw new Error('El ID de la cita es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');
    if (!params.customerId) throw new Error('El ID del cliente es requerido.');
    if (!params.employeeId) throw new Error('El ID del empleado es requerido.');
    if (!params.serviceId) throw new Error('El ID del servicio es requerido.');

    this.id = params.id;
    this.businessId = params.businessId;
    this.customerId = params.customerId;
    this.employeeId = params.employeeId;
    this.serviceId = params.serviceId;
    this.timeSlot = params.timeSlot;
    this.totalPrice = params.totalPrice;
    this.status = params.status || AppointmentStatus.PENDING;
    this.notes = params.notes || '';
    this.cancellationReason = params.cancellationReason;
    this.createdAt = params.createdAt || new Date();
    this.updatedAt = params.updatedAt || new Date();
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getCustomerId(): string { return this.customerId; }
  public getEmployeeId(): string { return this.employeeId; }
  public getServiceId(): string { return this.serviceId; }
  public getTimeSlot(): TimeSlot { return this.timeSlot; }
  public getStatus(): AppointmentStatus { return this.status; }
  public getTotalPrice(): Money { return this.totalPrice; }
  public getNotes(): string { return this.notes; }
  public getCancellationReason(): string | undefined { return this.cancellationReason; }

  public confirm(): void {
    if (this.status !== AppointmentStatus.PENDING) {
      throw new Error(`No se puede confirmar una cita en estado ${this.status}.`);
    }
    this.status = AppointmentStatus.CONFIRMED;
    this.touch();
  }

  public cancel(reason: string): void {
    if (this.status === AppointmentStatus.COMPLETED || this.status === AppointmentStatus.CANCELLED) {
      throw new Error(`No se puede cancelar una cita en estado ${this.status}.`);
    }
    this.status = AppointmentStatus.CANCELLED;
    this.cancellationReason = reason || 'Sin razón especificada';
    this.touch();
  }

  public complete(): void {
    if (this.status !== AppointmentStatus.CONFIRMED) {
      throw new Error(`Solo se pueden completar citas confirmadas.`);
    }
    this.status = AppointmentStatus.COMPLETED;
    this.touch();
  }

  public markAsNoShow(): void {
    if (this.status !== AppointmentStatus.CONFIRMED) {
      throw new Error(`Solo se pueden marcar como No-Show citas confirmadas.`);
    }
    this.status = AppointmentStatus.NO_SHOW;
    this.touch();
  }

  public reschedule(newSlot: TimeSlot): void {
    if (this.status === AppointmentStatus.CANCELLED || this.status === AppointmentStatus.COMPLETED) {
      throw new Error(`No se puede reprogramar una cita ${this.status}.`);
    }
    this.timeSlot = newSlot;
    this.status = AppointmentStatus.PENDING;
    this.touch();
  }

  private touch(): void {
    this.updatedAt = new Date();
  }
}
