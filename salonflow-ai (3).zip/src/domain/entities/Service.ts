import { Money } from '../value-objects/Money';

/**
 * Entidad de Dominio: Service
 * Representa un servicio ofrecido por el negocio (ej. corte de pelo, tinte).
 */
export class Service {
  private id: string;
  private businessId: string;
  private name: string;
  private description: string;
  private durationMinutes: number;
  private price: Money;
  private category: string;
  private active: boolean;

  constructor(params: {
    id: string;
    businessId: string;
    name: string;
    description: string;
    durationMinutes: number;
    price: Money;
    category: string;
    active?: boolean;
  }) {
    if (!params.id) throw new Error('El ID del servicio es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');
    if (!params.name || params.name.trim() === '') throw new Error('El nombre del servicio es requerido.');
    if (params.durationMinutes <= 0) throw new Error('La duración del servicio debe ser mayor a 0 minutos.');

    this.id = params.id;
    this.businessId = params.businessId;
    this.name = params.name.trim();
    this.description = params.description || '';
    this.durationMinutes = params.durationMinutes;
    this.price = params.price;
    this.category = params.category || 'General';
    this.active = params.active !== undefined ? params.active : true;
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getName(): string { return this.name; }
  public getDescription(): string { return this.description; }
  public getDurationMinutes(): number { return this.durationMinutes; }
  public getPrice(): Money { return this.price; }
  public getCategory(): string { return this.category; }
  public isActive(): boolean { return this.active; }

  public updatePrice(newPrice: Money): void {
    this.price = newPrice;
  }

  public updateDuration(newDurationMinutes: number): void {
    if (newDurationMinutes <= 0) {
      throw new Error('La duración debe ser mayor a 0.');
    }
    this.durationMinutes = newDurationMinutes;
  }

  public activate(): void { this.active = true; }
  public deactivate(): void { this.active = false; }
}
