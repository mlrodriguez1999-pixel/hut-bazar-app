import { FAQ } from './FAQ';

/**
 * Entidad de Dominio: KnowledgeBase
 * Representa la base de conocimientos y políticas del salón.
 */
export class KnowledgeBase {
  private id: string;
  private businessId: string;
  private cancellationPolicy: string;
  private paymentMethods: string[];
  private faqs: Map<string, FAQ>;
  private updatedAt: Date;

  constructor(params: {
    id: string;
    businessId: string;
    cancellationPolicy?: string;
    paymentMethods?: string[];
    faqs?: FAQ[];
    updatedAt?: Date;
  }) {
    if (!params.id) throw new Error('El ID de la base de conocimiento es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');

    this.id = params.id;
    this.businessId = params.businessId;
    this.cancellationPolicy = params.cancellationPolicy || 'Cancelación permitida hasta 24 horas antes sin costo.';
    this.paymentMethods = params.paymentMethods || ['Efectivo', 'Tarjeta de crédito', 'Bizum'];
    this.faqs = new Map<string, FAQ>();
    if (params.faqs) {
      params.faqs.forEach((faq) => this.faqs.set(faq.getId(), faq));
    }
    this.updatedAt = params.updatedAt || new Date();
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getCancellationPolicy(): string { return this.cancellationPolicy; }
  public getPaymentMethods(): string[] { return [...this.paymentMethods]; }
  public getFaqs(): FAQ[] { return Array.from(this.faqs.values()); }
  public getUpdatedAt(): Date { return new Date(this.updatedAt.getTime()); }

  public addFaq(faq: FAQ): void {
    this.faqs.set(faq.getId(), faq);
    this.updatedAt = new Date();
  }

  public removeFaq(faqId: string): void {
    this.faqs.delete(faqId);
    this.updatedAt = new Date();
  }

  public searchFaqs(query: string): FAQ[] {
    return Array.from(this.faqs.values()).filter(
      (faq) => faq.isActive() && faq.matchesKeyword(query)
    );
  }

  public updateCancellationPolicy(policy: string): void {
    if (!policy || !policy.trim()) throw new Error('La política de cancelación no puede estar vacía.');
    this.cancellationPolicy = policy.trim();
    this.updatedAt = new Date();
  }
}
