import { TimeSlot } from '../value-objects/TimeSlot';

export interface WorkSchedule {
  dayOfWeek: number; // 0 = Domingo, 1 = Lunes, ..., 6 = Sábado
  startHour: string; // "09:00"
  endHour: string;   // "18:00"
  breakStart?: string; // "14:00"
  breakEnd?: string;   // "15:00"
}

export interface AbsencePeriod {
  startDate: string; // "YYYY-MM-DD"
  endDate: string;   // "YYYY-MM-DD"
  reason: string;    // "Vacaciones", "Enfermedad", "Permiso"
}

/**
 * Entidad de Dominio: Employee
 * Representa a un estilista o empleado del salón con sus jornadas de trabajo específicas.
 */
export class Employee {
  private id: string;
  private businessId: string;
  private name: string;
  private role: string;
  private specialtyServiceIds: Set<string>;
  private schedules: WorkSchedule[];
  private absences: AbsencePeriod[];
  private active: boolean;

  constructor(params: {
    id: string;
    businessId: string;
    name: string;
    role: string;
    specialtyServiceIds?: string[];
    schedules?: WorkSchedule[];
    absences?: AbsencePeriod[];
    active?: boolean;
  }) {
    if (!params.id) throw new Error('El ID del empleado es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');
    if (!params.name || params.name.trim() === '') throw new Error('El nombre del empleado es requerido.');

    this.id = params.id;
    this.businessId = params.businessId;
    this.name = params.name.trim();
    this.role = params.role || 'Estilista';
    this.specialtyServiceIds = new Set(params.specialtyServiceIds || []);
    this.schedules = params.schedules || [];
    this.absences = params.absences || [];
    this.active = params.active !== undefined ? params.active : true;
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getName(): string { return this.name; }
  public getRole(): string { return this.role; }
  public getSpecialtyServiceIds(): string[] { return Array.from(this.specialtyServiceIds); }
  public getSchedules(): WorkSchedule[] { return [...this.schedules]; }
  public getAbsences(): AbsencePeriod[] { return [...this.absences]; }
  public isActive(): boolean { return this.active; }

  public addSpecialty(serviceId: string): void {
    if (!serviceId) throw new Error('El ID del servicio no puede estar vacío.');
    this.specialtyServiceIds.add(serviceId);
  }

  public removeSpecialty(serviceId: string): void {
    this.specialtyServiceIds.delete(serviceId);
  }

  public canPerformService(serviceId: string): boolean {
    return this.specialtyServiceIds.has(serviceId);
  }

  public addAbsence(absence: AbsencePeriod): void {
    this.absences.push(absence);
  }

  /**
   * Materializa las horas de trabajo semanales del empleado a TimeSlots de la fecha especificada.
   * Excluye pausas/almuerzos y períodos de vacaciones/ausencia.
   */
  public workingHoursToSlots(targetDate: Date, slotDurationMinutes: number = 15): TimeSlot[] {
    if (!this.active) return [];

    const dateStr = targetDate.toISOString().split('T')[0];
    
    // Verificar si el profesional está de vacaciones/ausencia en esa fecha
    const isAbsent = this.absences.some(a => dateStr >= a.startDate && dateStr <= a.endDate);
    if (isAbsent) return [];

    const dayOfWeek = targetDate.getDay();
    const daySchedule = this.schedules.find(s => s.dayOfWeek === dayOfWeek);
    if (!daySchedule) return [];

    const slots: TimeSlot[] = [];
    const [startH, startM] = daySchedule.startHour.split(':').map(Number);
    const [endH, endM] = daySchedule.endHour.split(':').map(Number);

    const shiftStart = new Date(targetDate);
    shiftStart.setHours(startH, startM, 0, 0);

    const shiftEnd = new Date(targetDate);
    shiftEnd.setHours(endH, endM, 0, 0);

    let breakStart: Date | null = null;
    let breakEnd: Date | null = null;

    if (daySchedule.breakStart && daySchedule.breakEnd) {
      const [bStartH, bStartM] = daySchedule.breakStart.split(':').map(Number);
      const [bEndH, bEndM] = daySchedule.breakEnd.split(':').map(Number);

      breakStart = new Date(targetDate);
      breakStart.setHours(bStartH, bStartM, 0, 0);

      breakEnd = new Date(targetDate);
      breakEnd.setHours(bEndH, bEndM, 0, 0);
    }

    let current = new Date(shiftStart);
    while (current.getTime() + slotDurationMinutes * 60 * 1000 <= shiftEnd.getTime()) {
      const slotEnd = new Date(current.getTime() + slotDurationMinutes * 60 * 1000);

      // Verificar si solapa con el descanso del profesional
      const overlapsBreak = breakStart && breakEnd && (
        (current >= breakStart && current < breakEnd) ||
        (slotEnd > breakStart && slotEnd <= breakEnd)
      );

      if (!overlapsBreak) {
        slots.push(new TimeSlot(new Date(current), new Date(slotEnd)));
      }

      current = slotEnd;
    }

    return slots;
  }

  public isAvailableForSchedule(slot: TimeSlot): boolean {
    if (!this.active) return false;
    const day = slot.getStart().getDay();
    const startStr = `${String(slot.getStart().getHours()).padStart(2, '0')}:${String(slot.getStart().getMinutes()).padStart(2, '0')}`;
    const endStr = `${String(slot.getEnd().getHours()).padStart(2, '0')}:${String(slot.getEnd().getMinutes()).padStart(2, '0')}`;

    return this.schedules.some(
      (s) => s.dayOfWeek === day && s.startHour <= startStr && s.endHour >= endStr
    );
  }

  public activate(): void { this.active = true; }
  public deactivate(): void { this.active = false; }
}
