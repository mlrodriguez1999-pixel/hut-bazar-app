import { Email } from '../value-objects/Email';
import { PhoneNumber } from '../value-objects/PhoneNumber';

/**
 * Entidad de Dominio: Customer
 * Representa a un cliente del salón con sus datos de contacto y fidelización.
 */
export class Customer {
  private id: string;
  private businessId: string;
  private fullName: string;
  private phone: PhoneNumber;
  private email: Email;
  private notes: string;
  private tags: Set<string>;
  private loyaltyPoints: number;
  private preferences: Record<string, string>;
  private noShowCount: number;
  private createdAt: Date;

  constructor(params: {
    id: string;
    businessId: string;
    fullName: string;
    phone: PhoneNumber;
    email: Email;
    notes?: string;
    tags?: string[];
    loyaltyPoints?: number;
    preferences?: Record<string, string>;
    noShowCount?: number;
    createdAt?: Date;
  }) {
    if (!params.id) throw new Error('El ID del cliente es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');
    if (!params.fullName || !params.fullName.trim()) throw new Error('El nombre completo es requerido.');

    this.id = params.id;
    this.businessId = params.businessId;
    this.fullName = params.fullName.trim();
    this.phone = params.phone;
    this.email = params.email;
    this.notes = params.notes || '';
    this.tags = new Set(params.tags || []);
    this.loyaltyPoints = params.loyaltyPoints !== undefined ? Math.max(0, params.loyaltyPoints) : 0;
    this.preferences = params.preferences ? { ...params.preferences } : {};
    this.noShowCount = params.noShowCount !== undefined ? Math.max(0, params.noShowCount) : 0;
    this.createdAt = params.createdAt || new Date();
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getFullName(): string { return this.fullName; }
  public getPhone(): PhoneNumber { return this.phone; }
  public getEmail(): Email { return this.email; }
  public getNotes(): string { return this.notes; }
  public getTags(): string[] { return Array.from(this.tags); }
  public getLoyaltyPoints(): number { return this.loyaltyPoints; }
  public getPreferences(): Record<string, string> { return { ...this.preferences }; }
  public getNoShowCount(): number { return this.noShowCount; }
  public getCreatedAt(): Date { return new Date(this.createdAt.getTime()); }

  public registerNoShow(): void {
    this.noShowCount += 1;
    this.addTag('no-show');
  }

  public addLoyaltyPoints(points: number): void {
    if (points <= 0) throw new Error('Los puntos agregados deben ser mayores a 0.');
    this.loyaltyPoints += points;
  }

  public redeemLoyaltyPoints(points: number): void {
    if (points <= 0) throw new Error('Los puntos a canjear deben ser mayores a 0.');
    if (this.loyaltyPoints < points) throw new Error('Puntos de fidelidad insuficientes.');
    this.loyaltyPoints -= points;
  }

  public addTag(tag: string): void {
    if (tag && tag.trim()) this.tags.add(tag.trim().toLowerCase());
  }

  public removeTag(tag: string): void {
    if (tag) this.tags.delete(tag.trim().toLowerCase());
  }

  public updatePreference(key: string, value: string): void {
    if (key && key.trim()) {
      this.preferences[key.trim()] = value;
    }
  }

  public updateNotes(newNotes: string): void {
    this.notes = newNotes || '';
  }
}
