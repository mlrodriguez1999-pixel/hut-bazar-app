/**
 * Entidad de Dominio: FAQ
 * Representa una pregunta frecuente.
 */
export class FAQ {
  private id: string;
  private knowledgeBaseId: string;
  private question: string;
  private answer: string;
  private category: string;
  private keywords: string[];
  private active: boolean;

  constructor(params: {
    id: string;
    knowledgeBaseId: string;
    question: string;
    answer: string;
    category?: string;
    keywords?: string[];
    active?: boolean;
  }) {
    if (!params.id) throw new Error('El ID de la FAQ es requerido.');
    if (!params.knowledgeBaseId) throw new Error('El ID de la base de conocimiento es requerido.');
    if (!params.question || params.question.trim() === '') throw new Error('La pregunta es requerida.');
    if (!params.answer || params.answer.trim() === '') throw new Error('La respuesta es requerida.');

    this.id = params.id;
    this.knowledgeBaseId = params.knowledgeBaseId;
    this.question = params.question.trim();
    this.answer = params.answer.trim();
    this.category = params.category || 'General';
    this.keywords = params.keywords ? params.keywords.map(k => k.toLowerCase()) : [];
    this.active = params.active !== undefined ? params.active : true;
  }

  public getId(): string { return this.id; }
  public getKnowledgeBaseId(): string { return this.knowledgeBaseId; }
  public getQuestion(): string { return this.question; }
  public getAnswer(): string { return this.answer; }
  public getCategory(): string { return this.category; }
  public getKeywords(): string[] { return [...this.keywords]; }
  public isActive(): boolean { return this.active; }

  public updateContent(question: string, answer: string): void {
    if (!question || !question.trim()) throw new Error('La pregunta no puede estar vacía.');
    if (!answer || !answer.trim()) throw new Error('La respuesta no puede estar vacía.');
    this.question = question.trim();
    this.answer = answer.trim();
  }

  public matchesKeyword(term: string): boolean {
    const normalized = term.toLowerCase().trim();
    return (
      this.question.toLowerCase().includes(normalized) ||
      this.answer.toLowerCase().includes(normalized) ||
      this.keywords.some(k => k.includes(normalized))
    );
  }

  public activate(): void { this.active = true; }
  public deactivate(): void { this.active = false; }
}
