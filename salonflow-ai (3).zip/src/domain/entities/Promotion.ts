import { Money } from '../value-objects/Money';

/**
 * Entidad de Dominio: Promotion
 * Representa ofertas o promociones aplicables a servicios.
 */
export class Promotion {
  private id: string;
  private businessId: string;
  private title: string;
  private description: string;
  private discountPercentage: number;
  private startDate: Date;
  private endDate: Date;
  private code: string;
  private applicableServiceIds: Set<string>;
  private active: boolean;

  constructor(params: {
    id: string;
    businessId: string;
    title: string;
    description?: string;
    discountPercentage: number;
    startDate: Date;
    endDate: Date;
    code: string;
    applicableServiceIds?: string[];
    active?: boolean;
  }) {
    if (!params.id) throw new Error('El ID de la promoción es requerido.');
    if (!params.businessId) throw new Error('El ID del negocio es requerido.');
    if (!params.title || !params.title.trim()) throw new Error('El título de la promoción es requerido.');
    if (params.discountPercentage <= 0 || params.discountPercentage > 100) {
      throw new Error('El porcentaje de descuento debe estar entre 1 y 100.');
    }
    if (params.endDate <= params.startDate) {
      throw new Error('La fecha de fin debe ser posterior a la fecha de inicio.');
    }

    this.id = params.id;
    this.businessId = params.businessId;
    this.title = params.title.trim();
    this.description = params.description || '';
    this.discountPercentage = params.discountPercentage;
    this.startDate = new Date(params.startDate.getTime());
    this.endDate = new Date(params.endDate.getTime());
    this.code = params.code.trim().toUpperCase();
    this.applicableServiceIds = new Set(params.applicableServiceIds || []);
    this.active = params.active !== undefined ? params.active : true;
  }

  public getId(): string { return this.id; }
  public getBusinessId(): string { return this.businessId; }
  public getTitle(): string { return this.title; }
  public getDescription(): string { return this.description; }
  public getDiscountPercentage(): number { return this.discountPercentage; }
  public getStartDate(): Date { return new Date(this.startDate.getTime()); }
  public getEndDate(): Date { return new Date(this.endDate.getTime()); }
  public getCode(): string { return this.code; }
  public getApplicableServiceIds(): string[] { return Array.from(this.applicableServiceIds); }
  public isActive(): boolean { return this.active; }

  public isValidAt(date: Date = new Date()): boolean {
    return this.active && date >= this.startDate && date <= this.endDate;
  }

  public appliesToService(serviceId: string): boolean {
    if (this.applicableServiceIds.size === 0) return true; // Aplica a todos si no hay lista restrictiva
    return this.applicableServiceIds.has(serviceId);
  }

  public calculateDiscountedPrice(originalPrice: Money, serviceId?: string): Money {
    if (!this.isValidAt()) {
      throw new Error('La promoción no está activa en la fecha actual.');
    }
    if (serviceId && !this.appliesToService(serviceId)) {
      throw new Error('La promoción no aplica a este servicio.');
    }
    return originalPrice.applyDiscountPercentage(this.discountPercentage);
  }

  public activate(): void { this.active = true; }
  public deactivate(): void { this.active = false; }
}
