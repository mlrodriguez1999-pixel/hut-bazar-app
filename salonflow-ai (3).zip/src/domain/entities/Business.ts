import { Email } from '../value-objects/Email';
import { PhoneNumber } from '../value-objects/PhoneNumber';
import { Service } from './Service';
import { Employee } from './Employee';
import { KnowledgeBase } from './KnowledgeBase';

export interface BusinessOpeningHours {
  dayOfWeek: number; // 0..6
  openTime: string;  // "09:00"
  closeTime: string; // "20:00"
  isOpen: boolean;
}

/**
 * Entidad de Dominio: Business (Agregado Principal del Salón)
 * Representa la empresa/establecimiento y gestiona sus reglas principales.
 */
export class Business {
  private id: string;
  private name: string;
  private address: string;
  private phone: PhoneNumber;
  private email: Email;
  private openingHours: BusinessOpeningHours[];
  private active: boolean;
  private services: Map<string, Service>;
  private employees: Map<string, Employee>;
  private knowledgeBase?: KnowledgeBase;

  constructor(params: {
    id: string;
    name: string;
    address: string;
    phone: PhoneNumber;
    email: Email;
    openingHours?: BusinessOpeningHours[];
    active?: boolean;
    services?: Service[];
    employees?: Employee[];
    knowledgeBase?: KnowledgeBase;
  }) {
    if (!params.id) throw new Error('El ID del negocio es requerido.');
    if (!params.name || !params.name.trim()) throw new Error('El nombre del negocio es requerido.');

    this.id = params.id;
    this.name = params.name.trim();
    this.address = params.address || '';
    this.phone = params.phone;
    this.email = params.email;
    this.openingHours = params.openingHours || [];
    this.active = params.active !== undefined ? params.active : true;
    
    this.services = new Map<string, Service>();
    if (params.services) {
      params.services.forEach(s => this.services.set(s.getId(), s));
    }

    this.employees = new Map<string, Employee>();
    if (params.employees) {
      params.employees.forEach(e => this.employees.set(e.getId(), e));
    }

    this.knowledgeBase = params.knowledgeBase;
  }

  public getId(): string { return this.id; }
  public getName(): string { return this.name; }
  public getAddress(): string { return this.address; }
  public getPhone(): PhoneNumber { return this.phone; }
  public getEmail(): Email { return this.email; }
  public getOpeningHours(): BusinessOpeningHours[] { return [...this.openingHours]; }
  public isActive(): boolean { return this.active; }
  public getServices(): Service[] { return Array.from(this.services.values()); }
  public getEmployees(): Employee[] { return Array.from(this.employees.values()); }
  public getKnowledgeBase(): KnowledgeBase | undefined { return this.knowledgeBase; }

  public addService(service: Service): void {
    this.services.set(service.getId(), service);
  }

  public removeService(serviceId: string): void {
    this.services.delete(serviceId);
  }

  public addEmployee(employee: Employee): void {
    this.employees.set(employee.getId(), employee);
  }

  public removeEmployee(employeeId: string): void {
    this.employees.delete(employeeId);
  }

  public setKnowledgeBase(kb: KnowledgeBase): void {
    this.knowledgeBase = kb;
  }

  public isOpenAt(date: Date): boolean {
    if (!this.active) return false;
    const day = date.getDay();
    const timeStr = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    const schedule = this.openingHours.find(h => h.dayOfWeek === day);
    if (!schedule || !schedule.isOpen) return false;
    return timeStr >= schedule.openTime && timeStr <= schedule.closeTime;
  }

  public activate(): void { this.active = true; }
  public deactivate(): void { this.active = false; }
}
