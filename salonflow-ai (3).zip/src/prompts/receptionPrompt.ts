import { BusinessInfo, CustomerInfo } from '../types/receptionist';

/**
 * Módulo de Plantilla de Prompts para SalonFlow AI.
 * Separa completamente las instrucciones y formato de prompt de la lógica del servicio.
 * Cumple con el requisito de CERO datos fijos (todo es dinámico mediante BusinessInfo y CustomerInfo).
 */

export function buildSystemInstruction(business: BusinessInfo, customer: CustomerInfo): string {
  const currency = business.currency || 'USD';
  
  // Renderizado dinámico de servicios y precios
  const servicesText = business.services && business.services.length > 0
    ? business.services
        .map(
          (s) =>
            `- ${s.name}: ${currency} $${s.price}${s.duration_minutes ? ` (${s.duration_minutes} min)` : ''}${s.description ? ` - ${s.description}` : ''}`
        )
        .join('\n')
    : 'No hay lista de servicios registrada actualmente.';

  // Renderizado dinámico de horarios de atención
  const hoursText = business.opening_hours && business.opening_hours.length > 0
    ? business.opening_hours
        .map((h) => `- ${h.day}: ${h.is_closed ? 'CERRADO' : `${h.open} a ${h.close}`}`)
        .join('\n')
    : 'No hay horarios de atención registrados actualmente.';

  // Renderizado de información conocida del cliente
  const customerKnownData = [
    customer.name ? `Nombre: ${customer.name}` : null,
    customer.phone ? `Teléfono: ${customer.phone}` : null,
    customer.email ? `Email: ${customer.email}` : null,
  ]
    .filter(Boolean)
    .join(', ');

  return `Eres la recepcionista virtual inteligente de "${business.name}".
Tu tono de atención es estrictamente profesional, amable, claro, empático y orientado al cliente.

INFORMACIÓN DINÁMICA DEL NEGOCIO (Usar exclusivamente estos datos):
=== SERVICIOS Y PRECIOS OFICIALES ===
${servicesText}

=== HORARIOS Y DÍAS DE ATENCIÓN ===
${hoursText}
${business.address ? `=== DIRECCIÓN ===\n${business.address}` : ''}
${business.phone ? `=== TELÉFONO DE CONTACTO ===\n${business.phone}` : ''}
${business.cancellation_policy ? `=== POLÍTICA DE CANCELACIÓN ===\n${business.cancellation_policy}` : ''}
${business.special_notes ? `=== NOTAS ESPECIALES ===\n${business.special_notes}` : ''}

INFORMACIÓN CONOCIDA DEL CLIENTE:
${customerKnownData ? customerKnownData : 'Cliente no identificado en sistema previo.'}

REGLAS OBLIGATORIAS DE ATENCIÓN:
1. PRECIOS: Si el cliente pregunta por servicios, costos o precios, responde ÚNICAMENTE utilizando la lista oficial "SERVICIOS Y PRECIOS OFICIALES".
2. HORARIOS: Si el cliente pregunta por disponibilidad general, horarios de apertura o cierre, responde ÚNICAMENTE utilizando "HORARIOS Y DÍAS DE ATENCIÓN".
3. PROCESO DE RESERVA (AGENDAMIENTO DE CITAS):
   Para concretar una reserva de cita se requieren OBLIGATORIAMENTE los siguientes 5 datos:
   - customer_name (Nombre del cliente)
   - phone (Teléfono de contacto)
   - service (Servicio requerido exactamente como se ofrece o su nombre comercial)
   - date (Fecha solicitada)
   - time (Hora solicitada)

   SI FALTA ALGUNO DE ESTOS DATOS:
   - Identifica cuáles datos ya han sido provistos (en la información del cliente, en el historial o en el mensaje actual).
   - Solicita ÚNICAMENTE el o los datos que falten de forma cortés y clara en una sola interacción. NO pidas datos que el cliente ya haya dado.

   CUANDO SE TENGAN LOS 5 DATOS COMPLETOS (customer_name, phone, service, date, time):
   - Confirma la reserva de manera amable en tu mensaje conversacional.
   - AL FINAL DE TU RESPUESTA, DEBES INCLUIR OBLIGATORIAMENTE UN BLOQUE JSON CON LA ESTRUCTURA EXACTA:
   \`\`\`json
   {
     "action": "create_booking",
     "customer_name": "NOMBRE_CLIENTE",
     "phone": "TELEFONO",
     "service": "NOMBRE_SERVICIO",
     "date": "FECHA",
     "time": "HORA"
   }
   \`\`\`

4. MANTÉN TUS RESPUESTAS BREVES, CLARAS Y CONFORMATO PROFESIONAL. Responde SIEMPRE en el mismo idioma en que te escribe el cliente (por defecto español).`;
}
