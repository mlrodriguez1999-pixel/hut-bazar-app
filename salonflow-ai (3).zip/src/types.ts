export type LayerCategory = 'backend' | 'frontend' | 'database' | 'n8n' | 'devops' | 'docs';

export interface ArchitectureFile {
  id: string;
  path: string;
  filename: string;
  category: LayerCategory;
  language: 'typescript' | 'python' | 'sql' | 'json' | 'yaml' | 'markdown' | 'dockerfile';
  description: string;
  content: string;
}

export interface Salon {
  id: string;
  name: string;
  slug: string;
  phone: string;
  address: string;
  city: string;
  rating: number;
  activeStylistsCount: number;
  monthlyBookings: number;
  aiHandoverRate: number;
}

export interface Service {
  id: string;
  name: string;
  category: 'corte' | 'barba' | 'tinte' | 'tratamiento' | 'peinado';
  durationMinutes: number;
  price: number;
  description: string;
}

export interface Stylist {
  id: string;
  name: string;
  role: string;
  specialty: string;
  avatarUrl: string;
  isAvailable: boolean;
}

export interface Appointment {
  id: string;
  clientName: string;
  clientPhone: string;
  serviceName: string;
  stylistName: string;
  date: string;
  time: string;
  status: 'confirmada' | 'pendiente' | 'completada' | 'cancelada';
  source: 'WhatsApp AI' | 'Web' | 'Manual';
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  detectedIntent?: 'appointment_booking' | 'general_inquiry' | 'human_handover' | 'pricing';
  metadata?: {
    service?: string;
    date?: string;
    time?: string;
    clientName?: string;
  };
}

export interface ReceptionistConfig {
  salonName: string;
  persona: 'default' | 'barber' | 'chic';
  customGreeting: string;
  whatsappNumber: string;
  autoConfirmAppointments: boolean;
  handoverOnQueja: boolean;
  currency: string;
}
