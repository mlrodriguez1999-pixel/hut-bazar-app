import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { AgentCore } from "./src/services/AgentCore";
import { AuthService } from "./src/application/services/AuthService";
import { WhatsAppWebhookHandler } from "./src/infrastructure/webhooks/WhatsAppWebhookHandler";
import { N8nWebhookHandler } from "./src/infrastructure/webhooks/N8nWebhookHandler";
import { ReminderAndNoShowService } from "./src/services/ReminderAndNoShowService";
import { AvailabilityPolicy } from "./src/domain/policies/AvailabilityPolicy";
import { Employee } from "./src/domain/entities/Employee";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Instanciar servicios centrales
  const agentCore = new AgentCore();
  const authService = AuthService.getInstance();
  const whatsAppHandler = new WhatsAppWebhookHandler(agentCore);
  const n8nHandler = new N8nWebhookHandler();
  const reminderService = new ReminderAndNoShowService();

  // Iniciar servicio en segundo plano de no-shows y recordatorios
  reminderService.startAutomatedScheduler(300000); // Cada 5 min

  // Health check API
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      service: "SalonFlow AI AgentCore API Gateway",
      version: "2.0.0",
      timestamp: new Date().toISOString(),
      geminiConfigured: !!process.env.GEMINI_API_KEY,
    });
  });

  // 1. AUTENTICACIÓN Y MULTI-TENANCY API
  app.post("/api/auth/login", (req, res) => {
    const { email, password, business_slug } = req.body;
    // Simulación de autenticación de Supabase Auth
    const token = `usr_demo_123:biz_salon_flow_01`;
    const authContext = authService.verifyToken(token);

    return res.json({
      token,
      user: {
        id: authContext.userId,
        email: authContext.email,
        businessId: authContext.businessId,
        role: authContext.role,
        fullName: "Javier Guerra (Dueño)",
      },
    });
  });

  app.get("/api/auth/me", (req, res) => {
    const authHeader = req.headers.authorization;
    const authContext = authService.verifyToken(authHeader);
    return res.json({ user: authContext });
  });

  // 2. DISPONIBILIDAD CON JORNADAS POR PROFESIONAL
  app.get("/api/availability", (req, res) => {
    try {
      const dateStr = (req.query.date as string) || new Date().toISOString().split("T")[0];
      const serviceDuration = Number(req.query.duration) || 30;

      // Empleado demo con su jornada configurada (lunes a sábado 09:00 - 19:00, descanso 14:00 - 15:00)
      const employee = new Employee({
        id: "emp_sofia_01",
        businessId: "biz_salon_flow_01",
        name: "Sofía Martínez",
        role: "Estilista Senior",
        schedules: [
          { dayOfWeek: 1, startHour: "09:00", endHour: "19:00", breakStart: "14:00", breakEnd: "15:00" },
          { dayOfWeek: 2, startHour: "09:00", endHour: "19:00", breakStart: "14:00", breakEnd: "15:00" },
          { dayOfWeek: 3, startHour: "09:00", endHour: "19:00", breakStart: "14:00", breakEnd: "15:00" },
          { dayOfWeek: 4, startHour: "09:00", endHour: "19:00", breakStart: "14:00", breakEnd: "15:00" },
          { dayOfWeek: 5, startHour: "09:00", endHour: "19:00", breakStart: "14:00", breakEnd: "15:00" },
          { dayOfWeek: 6, startHour: "10:00", endHour: "16:00" },
        ],
      });

      const policy = new AvailabilityPolicy({ slotGridMinutes: 15, minimumNoticeMinutes: 30 });
      const targetDate = new Date(`${dateStr}T09:00:00.000Z`);
      const slots = policy.getAvailableSlots({
        targetDate,
        serviceDurationMinutes: serviceDuration,
        employee,
        existingAppointments: [],
      });

      return res.json({
        date: dateStr,
        employee: employee.getName(),
        slots: slots.map((s) => ({
          start: s.getStart().toISOString(),
          end: s.getEnd().toISOString(),
          formatted: `${String(s.getStart().getHours()).padStart(2, "0")}:${String(s.getStart().getMinutes()).padStart(2, "0")}`,
        })),
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // 3. WEBHOOKS REALES: WHATSAPP (META)
  app.get("/api/webhooks/whatsapp", (req, res) => {
    const mode = req.query["hub.mode"] as string;
    const token = req.query["hub.verify_token"] as string;
    const challenge = req.query["hub.challenge"] as string;

    const result = whatsAppHandler.verifyChallenge(mode, token, challenge);
    if (result) {
      return res.status(200).send(result);
    }
    return res.sendStatus(403);
  });

  app.post("/api/webhooks/whatsapp", (req, res) => {
    // Responder 200 OK de inmediato a Meta (< 200ms)
    res.status(200).json({ status: "received" });
    // Procesar en segundo plano de forma asíncrona
    whatsAppHandler.processIncomingPayloadAsync(req.body);
  });

  // 3. WEBHOOKS REALES: N8N
  app.post("/api/webhooks/n8n", async (req, res) => {
    const result = await n8nHandler.dispatchEvent(req.body);
    return res.json(result);
  });

  // AI Virtual Receptionist Endpoint
  app.post("/api/receptionist/chat", async (req, res) => {
    try {
      const { message, history, persona, customer, business, conversation_id } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Message content is required" });
      }

      const response = await agentCore.processMessage({
        user_message: message,
        history,
        persona,
        customer,
        business,
        conversation_id,
      });

      return res.json(response);
    } catch (err: any) {
      console.error("Error in AgentCore router endpoint:", err);
      return res.status(500).json({
        error: "Failed to process message with AgentCore",
        details: err.message,
      });
    }
  });

  // Executar tareas de recordatorio/no-show manuales
  app.post("/api/reminders/run", async (req, res) => {
    const result = await reminderService.runRoutineChecks();
    return res.json(result);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SalonFlow AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
