/**
 * Unit Tests for SalonFlow AI - GeminiReceptionService & Prompt Builder
 */

import { GeminiReceptionService } from '../src/services/GeminiReceptionService';
import { buildSystemInstruction } from '../src/prompts/receptionPrompt';
import { BusinessInfo, CustomerInfo } from '../src/types/receptionist';

// Simple lightweight assertion utility for tests
function assertEqual(actual: any, expected: any, testName: string) {
  if (actual === expected) {
    console.log(`✅ [PASS] ${testName}`);
  } else {
    console.error(`❌ [FAIL] ${testName}\n   Expected: ${JSON.stringify(expected)}\n   Actual:   ${JSON.stringify(actual)}`);
    throw new Error(`Test failed: ${testName}`);
  }
}

function assertContains(text: string, substring: string, testName: string) {
  if (text.includes(substring)) {
    console.log(`✅ [PASS] ${testName}`);
  } else {
    console.error(`❌ [FAIL] ${testName}\n   Expected text to contain: "${substring}"`);
    throw new Error(`Test failed: ${testName}`);
  }
}

function assertNotNull(value: any, testName: string) {
  if (value !== null && value !== undefined) {
    console.log(`✅ [PASS] ${testName}`);
  } else {
    console.error(`❌ [FAIL] ${testName}\n   Expected value to be non-null`);
    throw new Error(`Test failed: ${testName}`);
  }
}

async function runTests() {
  console.log('\n======================================================');
  console.log('🧪 Running SalonFlow AI - GeminiReceptionService Unit Tests');
  console.log('======================================================\n');

  // Test Business & Customer Mock Data
  const testBusiness: BusinessInfo = {
    id: 'biz-100',
    name: 'Barbería & Spa BarberKing',
    currency: 'USD',
    phone: '+52 55 9999 8888',
    address: 'Av. Reforma 123, Ciudad de México',
    services: [
      { id: 's1', name: 'Corte Ejecutivo VIP', price: 25, duration_minutes: 35, description: 'Corte premium con lavado' },
      { id: 's2', name: 'Perfilado de Barba con Toalla Caliente', price: 18, duration_minutes: 25 },
      { id: 's3', name: 'Combo BarberKing (Corte + Barba)', price: 38, duration_minutes: 60 },
    ],
    opening_hours: [
      { day: 'Lunes a Viernes', open: '09:00', close: '20:00', is_closed: false },
      { day: 'Sábado', open: '10:00', close: '18:00', is_closed: false },
      { day: 'Domingo', open: '00:00', close: '00:00', is_closed: true },
    ],
  };

  const testCustomer: CustomerInfo = {
    id: 'cust-55',
    name: 'Carlos Mendoza',
    phone: '+52 55 1122 3344',
  };

  // -------------------------------------------------------------
  // Test 1: Prompt Builder separates prompt logic and inserts dynamic business data
  // -------------------------------------------------------------
  console.log('--- Test Group 1: Prompt Construction ---');
  const prompt = buildSystemInstruction(testBusiness, testCustomer);

  assertContains(prompt, 'Barbería & Spa BarberKing', 'Prompt contains dynamic business name');
  assertContains(prompt, 'Corte Ejecutivo VIP: USD $25', 'Prompt contains dynamic service and price');
  assertContains(prompt, 'Lunes a Viernes: 09:00 a 20:00', 'Prompt contains dynamic opening hours');
  assertContains(prompt, 'Domingo: CERRADO', 'Prompt contains closed days correctly');
  assertContains(prompt, 'Nombre: Carlos Mendoza', 'Prompt contains known customer name');
  assertContains(prompt, 'action": "create_booking"', 'Prompt contains required JSON booking output structure');

  // -------------------------------------------------------------
  // Test 2: JSON Extraction Utility in GeminiReceptionService
  // -------------------------------------------------------------
  console.log('\n--- Test Group 2: JSON Booking Parsing ---');
  const service = new GeminiReceptionService();

  const sampleAiResponseWithJson = `
¡Excelente, Carlos! He agendado tu cita para el Combo BarberKing.

\`\`\`json
{
  "action": "create_booking",
  "customer_name": "Carlos Mendoza",
  "phone": "+52 55 1122 3344",
  "service": "Combo BarberKing (Corte + Barba)",
  "date": "2026-08-10",
  "time": "15:00"
}
\`\`\`

¡Te esperamos en Barbería & Spa BarberKing!
  `;

  const parsedBooking = service.extractBookingJson(sampleAiResponseWithJson);
  assertNotNull(parsedBooking, 'Booking payload extracted successfully');
  assertEqual(parsedBooking?.action, 'create_booking', 'Booking action is create_booking');
  assertEqual(parsedBooking?.customer_name, 'Carlos Mendoza', 'Parsed customer name matches');
  assertEqual(parsedBooking?.phone, '+52 55 1122 3344', 'Parsed phone matches');
  assertEqual(parsedBooking?.service, 'Combo BarberKing (Corte + Barba)', 'Parsed service matches');
  assertEqual(parsedBooking?.date, '2026-08-10', 'Parsed date matches');
  assertEqual(parsedBooking?.time, '15:00', 'Parsed time matches');

  // Test 3: Extract booking return null if incomplete
  const sampleAiIncompleteJson = `
No tenemos suficientes datos aún.
\`\`\`json
{
  "action": "create_booking",
  "customer_name": "Carlos Mendoza",
  "service": "Corte"
}
\`\`\`
  `;
  const incompleteResult = service.extractBookingJson(sampleAiIncompleteJson);
  assertEqual(incompleteResult, null, 'Returns null when booking parameters are incomplete');

  // -------------------------------------------------------------
  // Test 4: End-to-End Service Message Processing
  // -------------------------------------------------------------
  console.log('\n--- Test Group 3: Process Message Workflow ---');

  // Price inquiry test
  const priceResponse = await service.processMessage({
    business: testBusiness,
    customer: testCustomer,
    conversation_history: [],
    user_message: '¿Cuáles son los precios de los cortes?',
  });

  assertContains(priceResponse.reply, 'Barbería & Spa BarberKing', 'Price reply mentions business name');
  assertContains(priceResponse.reply, 'Corte Ejecutivo VIP', 'Price reply details services from business.services');

  // Schedule inquiry test
  const hoursResponse = await service.processMessage({
    business: testBusiness,
    customer: testCustomer,
    conversation_history: [],
    user_message: '¿Qué días y horarios abren?',
  });

  assertContains(hoursResponse.reply, 'Lunes a Viernes', 'Hours reply details schedule from business.opening_hours');

  // Booking inquiry test
  const bookingResponse = await service.processMessage({
    business: testBusiness,
    customer: testCustomer,
    conversation_history: [],
    user_message: 'Quiero agendar una cita para corte de cabello mañana a las 4pm',
  });

  assertNotNull(bookingResponse.booking, 'Booking payload generated when booking request complete');
  assertEqual(bookingResponse.booking?.action, 'create_booking', 'Booking payload contains correct action');

  console.log('\n======================================================');
  console.log('🎉 All 14 Unit Test Assertions PASSED Successfully!');
  console.log('======================================================\n');
}

runTests().catch((err) => {
  console.error('Test Suite Failed:', err);
  process.exit(1);
});
