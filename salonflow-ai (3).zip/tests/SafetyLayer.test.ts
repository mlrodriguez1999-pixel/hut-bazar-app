import { SafetyLayer, SafetyIncidentStore } from '../src/services/SafetyLayer.js';
import { BusinessInfo } from '../src/types/receptionist.js';

async function runSafetyLayerTests() {
  console.log('======================================================');
  console.log('🧪 Running SalonFlow AI - Safety Layer Unit Tests');
  console.log('======================================================\n');

  const safetyLayer = new SafetyLayer();
  const incidentStore = SafetyIncidentStore.getInstance();
  incidentStore.clearIncidents();

  const mockBusiness: BusinessInfo = {
    name: 'Barbería Elegance',
    services: [
      { id: '1', name: 'Corte de Cabello Tradicional', price: 250 },
      { id: '2', name: 'Perfilado de Barba Ritual', price: 150 },
    ],
    opening_hours: [
      { day: 'Lunes a Sábado', open: '09:00', close: '20:00', is_closed: false },
    ],
  };

  let passed = 0;

  // Test 1: Check "No inventar precios"
  console.log('--- Test 1: Safety Check - No Inventar Precios ---');
  const res1 = safetyLayer.validateResponse({
    proposed_response: 'El corte de cabello te cuesta $590 pesos.',
    business: mockBusiness,
  });

  if (
    !res1.is_safe &&
    res1.violations.some(v => v.rule_id === 'unverified_prices') &&
    res1.final_response.includes('precios')
  ) {
    console.log('✅ [PASS] Unverified price ($590) detected, blocked and replaced with honest fallback');
    passed++;
  } else {
    console.error('❌ [FAIL] Price invention test failed');
  }

  // Test 2: Check "No inventar reservas"
  console.log('\n--- Test 2: Safety Check - No Inventar Reservas ---');
  const res2 = safetyLayer.validateResponse({
    proposed_response: 'Tu cita ha sido confirmada para mañana a las 4pm.',
    executed_tool: 'none', // No create_booking_tool executed!
  });

  if (
    !res2.is_safe &&
    res2.violations.some(v => v.rule_id === 'fake_bookings')
  ) {
    console.log('✅ [PASS] Fake booking confirmation blocked');
    passed++;
  } else {
    console.error('❌ [FAIL] Fake booking test failed');
  }

  // Test 3: Check "No dar consejos médicos"
  console.log('\n--- Test 3: Safety Check - No Dar Consejos Médicos ---');
  const res3 = safetyLayer.validateResponse({
    proposed_response: 'Para la caspa te prescribo un shampoo especial con antibiótico para curar la dermatitis.',
  });

  if (
    !res3.is_safe &&
    res3.violations.some(v => v.rule_id === 'medical_advice') &&
    res3.final_response.includes('profesional médico')
  ) {
    console.log('✅ [PASS] Medical advice blocked and redirected to health professionals');
    passed++;
  } else {
    console.error('❌ [FAIL] Medical advice test failed');
  }

  // Test 4: Check "No inventar promociones"
  console.log('\n--- Test 4: Safety Check - No Inventar Promociones ---');
  const res4 = safetyLayer.validateResponse({
    proposed_response: 'Hoy tenemos una promoción especial con 2x1 en corte y barba.',
    business: mockBusiness,
  });

  if (
    !res4.is_safe &&
    res4.violations.some(v => v.rule_id === 'fake_promotions')
  ) {
    console.log('✅ [PASS] Unauthorized promo detected and flagged');
    passed++;
  } else {
    console.error('❌ [FAIL] Promo invention test failed');
  }

  // Test 5: Check "No prometer disponibilidad"
  console.log('\n--- Test 5: Safety Check - No Prometer Disponibilidad ---');
  const res5 = safetyLayer.validateResponse({
    proposed_response: 'Está 100% disponible ese horario para atenderte.',
    executed_tool: 'none',
  });

  if (
    !res5.is_safe &&
    res5.violations.some(v => v.rule_id === 'unverified_availability')
  ) {
    console.log('✅ [PASS] Unverified availability guarantee blocked');
    passed++;
  } else {
    console.error('❌ [FAIL] Availability guarantee test failed');
  }

  // Test 6: Verify Incident Logging & Configurator
  console.log('\n--- Test 6: Incident Logging & Custom Configuration ---');
  const incidents = incidentStore.getIncidents();
  if (incidents.length >= 5) {
    console.log(`✅ [PASS] Recorded ${incidents.length} safety incidents in store`);
    passed++;
  } else {
    console.error('❌ [FAIL] Incident logging failed');
  }

  // Config test: Disable medical advice check dynamically
  console.log('\n--- Test 7: Dynamically Reconfiguring Rules ---');
  safetyLayer.setConfig({ check_medical_advice: false });
  const res7 = safetyLayer.validateResponse({
    proposed_response: 'Para la dermatitis usa crema.',
  });

  if (res7.is_safe) {
    console.log('✅ [PASS] Rule dynamically disabled via SafetyConfig');
    passed++;
  } else {
    console.error('❌ [FAIL] Reconfiguration test failed');
  }

  console.log('\n======================================================');
  console.log(`🎉 All ${passed}/7 Safety Layer Unit Tests PASSED!`);
  console.log('======================================================\n');
}

runSafetyLayerTests().catch(console.error);
