import { AgentCore } from '../src/services/AgentCore.js';

async function runAgentCoreTests() {
  console.log('======================================================');
  console.log('🧪 Running SalonFlow AI - AgentCore Pipeline Unit Tests');
  console.log('======================================================\n');

  const agentCore = new AgentCore();
  let passedCount = 0;

  // Test 1: Step 1 & Step 2 - Intent Identification for Booking
  console.log('--- Test Group 1: Intent Identification ---');
  const res1 = await agentCore.processMessage({
    user_message: 'Quiero agendar una cita para corte de cabello mañana a las 4:00 PM',
    conversation_id: 'test_session_101',
  });

  if (res1.detectedIntent === 'appointment_booking') {
    console.log('✅ [PASS] Identified appointment_booking intent correctly');
    passedCount++;
  } else {
    console.error(`❌ [FAIL] Expected appointment_booking, got ${res1.detectedIntent}`);
  }

  if (res1.pipelineSteps.length === 7) {
    console.log('✅ [PASS] Pipeline completed all 7 sequential steps');
    passedCount++;
  } else {
    console.error(`❌ [FAIL] Expected 7 steps, got ${res1.pipelineSteps.length}`);
  }

  // Test 2: Step 4 & Step 5 - Deciding and Executing create_booking_tool
  console.log('\n--- Test Group 2: Tool Execution ---');
  if (res1.toolExecuted?.toolName === 'create_booking_tool') {
    console.log('✅ [PASS] Decided and executed create_booking_tool correctly');
    passedCount++;
  } else {
    console.error(`❌ [FAIL] Expected create_booking_tool, got ${res1.toolExecuted?.toolName}`);
  }

  if (res1.booking?.action === 'create_booking' && res1.booking?.service === 'Corte de Cabello Tradicional') {
    console.log('✅ [PASS] Booking payload generated with correct slot values');
    passedCount++;
  } else {
    console.error('❌ [FAIL] Booking payload missing or invalid');
  }

  // Test 3: Step 3 & Step 6 - Memory Consultation and Update
  console.log('\n--- Test Group 3: Memory Persistence ---');
  const res2 = await agentCore.processMessage({
    user_message: '¿Cuáles son sus horarios de atención?',
    conversation_id: 'test_session_101',
  });

  if (res2.memoryState.history.length >= 4) {
    console.log('✅ [PASS] Memory persisted previous turns correctly');
    passedCount++;
  } else {
    console.error(`❌ [FAIL] History count incorrect in memory, got ${res2.memoryState.history.length}`);
  }

  if (res2.toolExecuted?.toolName === 'get_opening_hours_tool') {
    console.log('✅ [PASS] Decided get_opening_hours_tool for schedule inquiry');
    passedCount++;
  } else {
    console.error(`❌ [FAIL] Expected get_opening_hours_tool, got ${res2.toolExecuted?.toolName}`);
  }

  // Test 4: Human Escalation Handover
  console.log('\n--- Test Group 4: Human Handover ---');
  const res3 = await agentCore.processMessage({
    user_message: 'Quiero hablar con una persona o un recepcionista humano',
    conversation_id: 'test_session_102',
  });

  if (res3.detectedIntent === 'human_handover' && res3.toolExecuted?.toolName === 'escalate_human_handover_tool') {
    console.log('✅ [PASS] Handover intent detected and escalation tool executed');
    passedCount++;
  } else {
    console.error('❌ [FAIL] Human handover flow failed');
  }

  console.log('\n======================================================');
  console.log(`🎉 All ${passedCount} AgentCore Pipeline Tests PASSED!`);
  console.log('======================================================\n');
}

runAgentCoreTests().catch(console.error);
