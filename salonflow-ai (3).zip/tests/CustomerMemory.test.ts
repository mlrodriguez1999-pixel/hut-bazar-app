import { CustomerMemory, CustomerMemoryStore } from '../src/services/CustomerMemory.js';

async function runCustomerMemoryTests() {
  console.log('======================================================');
  console.log('🧪 Running SalonFlow AI - CustomerMemory Unit Tests');
  console.log('======================================================\n');

  let passed = 0;

  // Test 1: Initialization with all required attributes
  console.log('--- Test 1: CustomerMemory Profile Data Structure ---');
  const memory = new CustomerMemory({
    name: 'Ana Sofía Lopez',
    phone: '+52 55 9876 5432',
    favorite_barber: 'Mateo (Estilista Senior)',
    visit_count: 3,
    preferences: ['Agua tibia para el lavado', 'Té de manzanilla'],
    observations: ['Cuero cabelludo delicado', 'Prefiere poco ruido'],
    recent_services: [
      { name: 'Balayage & Peinado', date: '2026-06-15', barber: 'Mateo' }
    ],
    recent_bookings: [
      { id: 'BK-100200', service: 'Balayage & Peinado', date: '2026-06-15', time: '11:00', status: 'completed' }
    ]
  });

  const profile = memory.getProfile();
  if (
    profile.name === 'Ana Sofía Lopez' &&
    profile.phone === '+52 55 9876 5432' &&
    profile.favorite_barber === 'Mateo (Estilista Senior)' &&
    profile.visit_count === 3 &&
    profile.preferences.length === 2 &&
    profile.observations.length === 2 &&
    profile.recent_services.length === 1 &&
    profile.recent_bookings.length === 1
  ) {
    console.log('✅ [PASS] All 9 attributes correctly stored in profile');
    passed++;
  } else {
    console.error('❌ [FAIL] Missing or invalid attributes in CustomerMemory profile');
  }

  // Test 2: Adding preferences & observations dynamically
  console.log('\n--- Test 2: Dynamic Updates (Preferences & Observations) ---');
  memory.addPreference('Corte desfilado en puntas');
  memory.addObservation('Alergia a desinfectantes con amonio');
  memory.setFavoriteBarber('Roberto');

  const updatedProfile = memory.getProfile();
  if (
    updatedProfile.preferences.includes('Corte desfilado en puntas') &&
    updatedProfile.observations.includes('Alergia a desinfectantes con amonio') &&
    updatedProfile.favorite_barber === 'Roberto'
  ) {
    console.log('✅ [PASS] Dynamic updates applied successfully');
    passed++;
  } else {
    console.error('❌ [FAIL] Dynamic update failed');
  }

  // Test 3: Recording service & booking
  console.log('\n--- Test 3: Recording Visits & Bookings ---');
  memory.recordService('Tinte Completo + Tratamiento', 'Roberto', 450);
  memory.recordBooking({
    service: 'Mantenimiento de Tinte',
    date: '2026-08-15',
    time: '15:00',
    barber: 'Roberto',
    status: 'confirmed',
  });

  const visitProfile = memory.getProfile();
  if (
    visitProfile.visit_count === 4 &&
    visitProfile.recent_services[0].name === 'Tinte Completo + Tratamiento' &&
    visitProfile.recent_bookings[0].service === 'Mantenimiento de Tinte'
  ) {
    console.log('✅ [PASS] Service visit and booking recorded');
    passed++;
  } else {
    console.error('❌ [FAIL] Recording visit or booking failed');
  }

  // Test 4: Generating Token-Optimized Short Summary for Gemini Context
  console.log('\n--- Test 4: Token-Optimized Short Summary Generation ---');
  const summary = memory.getShortSummary();
  console.log('Resumen generado para Gemini:\n' + summary);

  if (
    summary.includes('Ana Sofía Lopez') &&
    summary.includes('Roberto') &&
    summary.includes('Visitas: 4') &&
    summary.includes('Corte desfilado en puntas') &&
    summary.includes('Alergia a desinfectantes con amonio') &&
    !summary.includes('CONVERSATION_TURN') // Ensure full conversation turns are NOT included
  ) {
    console.log('✅ [PASS] Short summary contains all relevant CRM facts and is token-optimized');
    passed++;
  } else {
    console.error('❌ [FAIL] Short summary incomplete or invalid');
  }

  // Test 5: CustomerMemoryStore singleton
  console.log('\n--- Test 5: CustomerMemoryStore Global Management ---');
  const store = CustomerMemoryStore.getInstance();
  const customer1 = store.getOrCreate('+52 55 1111 2222', { name: 'Carlos Ruiz' });
  customer1.addPreference('Sin platica durante el corte');

  const retrieved = store.get('+52 55 1111 2222');
  if (retrieved && retrieved.getProfile().name === 'Carlos Ruiz' && retrieved.getProfile().preferences.includes('Sin platica durante el corte')) {
    console.log('✅ [PASS] CustomerMemoryStore correctly retrieved and maintained customer memory');
    passed++;
  } else {
    console.error('❌ [FAIL] CustomerMemoryStore lookup failed');
  }

  console.log('\n======================================================');
  console.log(`🎉 All ${passed}/5 CustomerMemory Unit Tests PASSED!`);
  console.log('======================================================\n');
}

runCustomerMemoryTests().catch(console.error);
