import { assert } from 'console';
import {
  Money,
  TimeSlot,
  Email,
  PhoneNumber,
  Business,
  Employee,
  Service,
  Appointment,
  AppointmentStatus,
  Customer,
  Conversation,
  KnowledgeBase,
  FAQ,
  Promotion,
} from '../src/domain/index.js';

async function runDomainTests() {
  console.log('======================================================');
  console.log('🧪 Running Domain Model Unit Tests (DDD & SOLID)');
  console.log('======================================================\n');

  let passed = 0;
  let failed = 0;

  function test(name: string, fn: () => void) {
    try {
      fn();
      console.log(`  ✅ PASS: ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  ❌ FAIL: ${name} - ${err.message}`);
      failed++;
    }
  }

  test('Money Value Object validates non-negative amounts and currency matching', () => {
    const m1 = new Money(50, 'EUR');
    const m2 = new Money(20, 'EUR');
    if (m1.add(m2).getAmount() !== 70) throw new Error('Add amount mismatch');
    if (m1.subtract(m2).getAmount() !== 30) throw new Error('Subtract amount mismatch');
    if (m1.applyDiscountPercentage(10).getAmount() !== 45) throw new Error('Discount calculation mismatch');
    
    let threw = false;
    try { new Money(-10); } catch { threw = true; }
    if (!threw) throw new Error('Negative money did not throw error');
  });

  test('TimeSlot Value Object handles durations and overlaps correctly', () => {
    const start = new Date('2026-08-10T10:00:00Z');
    const end = new Date('2026-08-10T11:00:00Z');
    const slot1 = new TimeSlot(start, end);
    if (slot1.getDurationMinutes() !== 60) throw new Error('Duration calculation mismatch');

    const slot2 = new TimeSlot(
      new Date('2026-08-10T10:30:00Z'),
      new Date('2026-08-10T11:30:00Z')
    );
    if (!slot1.overlaps(slot2)) throw new Error('Overlap detection failed');
  });

  test('Email & PhoneNumber Value Objects enforce format invariants', () => {
    const email = new Email('test@salon.com');
    if (email.getValue() !== 'test@salon.com') throw new Error('Email value mismatch');
    
    let threwEmail = false;
    try { new Email('invalid-email'); } catch { threwEmail = true; }
    if (!threwEmail) throw new Error('Invalid email did not throw error');

    const phone = new PhoneNumber('+34 600 123 456');
    if (phone.getValue() !== '+34600123456') throw new Error('Phone number value mismatch');
  });

  test('Business aggregate manages services and availability', () => {
    const biz = new Business({
      id: 'biz_1',
      name: 'Salón Elegance',
      address: 'Calle Gran Vía 10',
      phone: new PhoneNumber('+34600123456'),
      email: new Email('info@elegance.com'),
      openingHours: [
        { dayOfWeek: 1, openTime: '09:00', closeTime: '20:00', isOpen: true },
      ],
    });

    const s1 = new Service({
      id: 'srv_1',
      businessId: 'biz_1',
      name: 'Corte de Pelo',
      description: 'Corte moderno con lavado',
      durationMinutes: 45,
      price: new Money(25, 'EUR'),
      category: 'Peluquería',
    });

    biz.addService(s1);
    if (biz.getServices().length !== 1) throw new Error('Service addition failed');
  });

  test('Appointment enforces valid status transitions', () => {
    const appt = new Appointment({
      id: 'app_1',
      businessId: 'biz_1',
      customerId: 'cust_1',
      employeeId: 'emp_1',
      serviceId: 'srv_1',
      timeSlot: new TimeSlot(
        new Date('2026-08-10T10:00:00Z'),
        new Date('2026-08-10T11:00:00Z')
      ),
      totalPrice: new Money(25, 'EUR'),
    });

    if (appt.getStatus() !== AppointmentStatus.PENDING) throw new Error('Initial status must be PENDING');
    appt.confirm();
    if (appt.getStatus() !== AppointmentStatus.CONFIRMED) throw new Error('Status after confirm must be CONFIRMED');

    appt.complete();
    if (appt.getStatus() !== AppointmentStatus.COMPLETED) throw new Error('Status after complete must be COMPLETED');

    let threwCancel = false;
    try { appt.cancel('Razón tardía'); } catch { threwCancel = true; }
    if (!threwCancel) throw new Error('Cancel completed appointment did not throw error');
  });

  test('Customer manages loyalty points and tags', () => {
    const cust = new Customer({
      id: 'cust_1',
      businessId: 'biz_1',
      fullName: 'María García',
      phone: new PhoneNumber('+34611223344'),
      email: new Email('maria@example.com'),
    });

    cust.addLoyaltyPoints(100);
    if (cust.getLoyaltyPoints() !== 100) throw new Error('Loyalty points addition failed');

    cust.redeemLoyaltyPoints(40);
    if (cust.getLoyaltyPoints() !== 60) throw new Error('Loyalty points redemption failed');

    let threwRedeem = false;
    try { cust.redeemLoyaltyPoints(100); } catch { threwRedeem = true; }
    if (!threwRedeem) throw new Error('Over-redeeming loyalty points did not throw error');
  });

  test('Promotion calculates discounts accurately during active period', () => {
    const promo = new Promotion({
      id: 'prom_1',
      businessId: 'biz_1',
      title: 'Descuento Verano',
      discountPercentage: 20,
      startDate: new Date('2026-01-01'),
      endDate: new Date('2026-12-31'),
      code: 'VERANO20',
    });

    const originalPrice = new Money(100, 'EUR');
    const discounted = promo.calculateDiscountedPrice(originalPrice);
    if (discounted.getAmount() !== 80) throw new Error('Discount price calculation failed');
  });

  console.log(`\nDomain Test Summary: ${passed} Passed, ${failed} Failed\n`);
  if (failed > 0) process.exit(1);
}

runDomainTests();
