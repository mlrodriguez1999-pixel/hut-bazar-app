import { Planner } from '../src/services/Planner.js';
import { CustomerMemory } from '../src/services/CustomerMemory.js';
import { BusinessInfo } from '../src/types/receptionist.js';
import { ToolDefinition } from '../src/types/agent.js';

async function runPlannerTests() {
  console.log('======================================================');
  console.log('🧪 Running SalonFlow AI - Planner Component Unit Tests');
  console.log('======================================================\n');

  const planner = new Planner();

  const mockBusiness: BusinessInfo = {
    name: 'Barbería Elegance',
    address: 'Av. Insurgentes Sur 450, CDMX',
    phone: '+52 55 1234 5678',
    opening_hours: [
      { day: 'Lunes a Sábado', open: '09:00', close: '20:00', is_closed: false }
    ],
    services: [
      { id: '1', name: 'Corte de Cabello Tradicional', price: 250, duration_minutes: 40 },
      { id: '2', name: 'Perfilado de Barba Ritual', price: 150, duration_minutes: 30 },
    ],
  };

  const mockCustomerMemory = new CustomerMemory({
    name: 'Javier Guerra',
    phone: '+52 55 9999 8888',
    favorite_barber: 'Carlos Martínez',
    preferences: ['Agua fría', 'Tijera arriba'],
  });

  const availableTools: ToolDefinition[] = [
    { name: 'check_availability_tool', description: 'Obtiene disponibilidad de citas', parametersSchema: {} },
    { name: 'create_booking_tool', description: 'Crea reserva de cita', parametersSchema: {} },
    { name: 'get_services_catalog_tool', description: 'Consulta el catálogo de servicios', parametersSchema: {} },
    { name: 'get_opening_hours_tool', description: 'Consulta los horarios de atención', parametersSchema: {} },
    { name: 'escalate_human_handover_tool', description: 'Escala atencion a humano', parametersSchema: {} },
  ];

  let passed = 0;

  // Test 1: Plan generation for booking ("Quiero reservar mañana")
  console.log('--- Test 1: Booking Plan Generation ("Quiero reservar mañana") ---');
  const plan1 = await planner.generatePlan({
    user_message: 'Quiero reservar mañana',
    business: mockBusiness,
    customer: mockCustomerMemory.getProfile(),
    available_tools: availableTools,
  });

  console.log('Plan Generado:', JSON.stringify(plan1, null, 2));

  if (
    plan1.user_intent === 'appointment_booking' &&
    plan1.steps.length >= 2 &&
    plan1.steps[0].tool_to_use === 'check_availability_tool' &&
    plan1.steps.some(s => s.action === 'create_booking' || s.tool_to_use === 'create_booking_tool')
  ) {
    console.log('✅ [PASS] Booking plan generated with correct step hierarchy (1. Obtener disponibilidad, 2. Preguntar hora/crear reserva)');
    passed++;
  } else {
    console.error('❌ [FAIL] Booking plan generation invalid');
  }

  // Test 2: Plan generation for service catalog inquiry
  console.log('\n--- Test 2: Service Catalog Inquiry Plan ---');
  const plan2 = await planner.generatePlan({
    user_message: '¿Cuáles son los precios de corte de cabello y barba?',
    business: mockBusiness,
    customer: mockCustomerMemory.getProfile(),
    available_tools: availableTools,
  });

  if (
    plan2.user_intent === 'service_inquiry' &&
    plan2.steps[0].tool_to_use === 'get_services_catalog_tool' &&
    plan2.steps.length >= 2
  ) {
    console.log('✅ [PASS] Service inquiry plan generated successfully');
    passed++;
  } else {
    console.error('❌ [FAIL] Service inquiry plan invalid');
  }

  // Test 3: Plan generation for human handover
  console.log('\n--- Test 3: Human Handover Escalation Plan ---');
  const plan3 = await planner.generatePlan({
    user_message: 'Quiero hablar con una persona o recepcionista humano',
    business: mockBusiness,
    customer: mockCustomerMemory.getProfile(),
    available_tools: availableTools,
  });

  if (
    plan3.user_intent === 'human_handover' &&
    plan3.steps[0].tool_to_use === 'escalate_human_handover_tool'
  ) {
    console.log('✅ [PASS] Human handover plan generated successfully');
    passed++;
  } else {
    console.error('❌ [FAIL] Human handover plan invalid');
  }

  // Test 4: Verifying Planner outputs ONLY plan (no conversational direct response)
  console.log('\n--- Test 4: Verification that Planner outputs NO direct user response ---');
  if (
    typeof plan1 === 'object' &&
    Array.isArray(plan1.steps) &&
    !('reply' in plan1) &&
    !('user_response' in plan1)
  ) {
    console.log('✅ [PASS] Planner returns strictly an ExecutionPlan structure without direct user response');
    passed++;
  } else {
    console.error('❌ [FAIL] Planner output contains direct user response or invalid format');
  }

  console.log('\n======================================================');
  console.log(`🎉 All ${passed}/4 Planner Unit Tests PASSED!`);
  console.log('======================================================\n');
}

runPlannerTests().catch(console.error);
